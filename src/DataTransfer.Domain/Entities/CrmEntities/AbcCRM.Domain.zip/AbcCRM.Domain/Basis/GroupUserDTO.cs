﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbcCRM.Domain.Basis
{
    /// <summary>
    /// 组员管理
    /// </summary>
    [NPoco.TableName("Basis_GroupUser")]
    [NPoco.PrimaryKey("GroupU_ID", AutoIncrement = true)]
    public class GroupUserDTO
    {
        /// <summary>
        /// 主键
        /// </summary>
        public int GroupU_ID { get; set; }

        /// <summary>
        /// 用户ID
        /// </summary>
        public int GroupU_UserID { get; set; }

        /// <summary>
        /// 用户中文名
        /// </summary>
        [NPoco.Ignore]
        public string GroupU_UserName { get; set; }

        /// <summary>
        /// 小组ID
        /// </summary>
        public int GroupU_GroupID { get; set; }

        /// <summary>
        /// 小组名称
        /// </summary>
        [NPoco.Ignore]
        public string GroupU_GroupName { get; set; }

        /// <summary>
        /// 组长标识
        /// </summary>
        public int GroupU_IsLeader { get; set; }

        public int? GroupU_CreatedBy { get; set; }

        public DateTime? GroupU_CreatedDate { get; set; }

        public int? GroupU_UpdatedBy { get; set; }

        public DateTime? GroupU_UpdatedDate { get; set; }

        /// <summary>
        /// 删除标志位
        /// </summary>
        public int GroupU_Deleted { get; set; }
    }
}
