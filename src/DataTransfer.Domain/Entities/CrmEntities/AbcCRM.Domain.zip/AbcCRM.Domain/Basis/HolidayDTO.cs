﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbcCRM.Domain.Basis
{
    /// <summary>
    /// 节假日管理
    /// </summary>
    [NPoco.TableName("Basis_Holiday")]
    [NPoco.PrimaryKey("Holi_ID", AutoIncrement = false)]
    public class HolidayDTO
    {
        /// <summary>
        /// 主键
        /// </summary>
        public int Holi_ID { get; set; }

        /// <summary>
        /// 节假日
        /// </summary>
        public DateTime Holi_Date { get; set; }
    }
}
