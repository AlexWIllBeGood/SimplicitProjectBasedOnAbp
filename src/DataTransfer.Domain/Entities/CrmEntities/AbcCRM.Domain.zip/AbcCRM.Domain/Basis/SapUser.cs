﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbcCRM.Domain
{

    //  "EmployeeID": 37437,
    //  "EmployeeCode": "00037437",
    //  "userName": "andy_cfj",
    //  "ChineseName": "陈凤娟",
    //  "EnglishName": "andy",
    //  "Birthday": "11/30/1989 00:00:00",
    //  "Sex": 8,
    //  "StartWorkDate": "",
    //  "JoinInDate": "06/19/2017 00:00:00",
    //  "CompanyEmail": "andy_cfj@meten.com",
    //  "MobilePhone": "13866706657",
    //  "QQ": "",
    //  "PersonalEmail": "278107136@qq.com",
    //  "LiveAddress": "",
    //  "StructureID": 52400288,
    //  "StrPosition": "",
    //  "JobTitleID": "00100217",
    //  "JobTitleName": "课程顾问",
    //  "IsPartTime": "离职人员",
    //  "PassWord": "!!22qq",
    //  "IsDisable": 1,
    //  "PositionName": "试用级课程顾问",
    //  "ManageBranchs": "",
    //  "IdCard": "340103198911301525",
    //  "ManageAreas": "",
    //  "BranchId": 52400286

    /// <summary>
    /// Sap用户信息
    /// </summary>
    public class SapUser
    {
        /// <summary>
        /// 员工ID
        /// </summary>
        public int? EmployeeID { get; set; }

        /// <summary>
        /// 员工代码
        /// </summary>
        public string EmployeeCode { get; set; }

        /// <summary>
        /// 用户名(alvin_wzw)
        /// </summary>
        public string UserName { get; set; }

        /// <summary>
        /// 中文名(FirstName)
        /// </summary>
        public string ChineseName { get; set; }

        /// <summary>
        /// 英文名(LastName)
        /// </summary>
        public string EnglishName { get; set; }

        /// <summary>
        /// 生日
        /// </summary>
        public DateTime? Birthday { get; set; }

        /// <summary>
        /// 性别 2：女 1：男
        /// </summary>
        public int? Sex { get; set; }

        /// <summary>
        /// 开始工作时间
        /// </summary>
        public DateTime? StartWorkDate { get; set; }

        /// <summary>
        /// 入职时间
        /// </summary>
        public DateTime? JoinInDate { get; set; }

        /// <summary>
        /// 公司邮箱
        /// </summary>
        public string CompanyEmail { get; set; }

        /// <summary>
        /// 手机
        /// </summary>
        public string MobilePhone { get; set; }

        /// <summary>
        /// QQ
        /// </summary>
        public string QQ { get; set; }

        /// <summary>
        /// 个人邮箱
        /// </summary>
        public string PersonalEmail { get; set; }

        /// <summary>
        /// 住址
        /// </summary>
        public string LiveAddress { get; set; }

        /// <summary>
        /// 架构Id
        /// </summary>
        public int? StructureID { get; set; }

        /// <summary>
        /// 岗位名称
        /// </summary>
        public string StrPosition { get; set; }

        /// <summary>
        /// 职位ID
        /// </summary>
        public string JobTitleID { get; set; }
        /// <summary>
        /// 职位名称
        /// </summary>
        public string JobTitleName { get; set; }

        /// <summary>
        /// 是否兼职(是否离职)
        /// </summary>
        public string IsPartTime { get; set; }

        /// <summary>
        /// 密码
        /// </summary>
        public string Password { get; set; }

        /// <summary>
        /// 是否离职 0:在职
        /// </summary>
        public int? IsDisable { get; set; }

        /// <summary>
        /// 岗位名称（如：试用级课程顾问）
        /// </summary>
        public string PositionName { get; set; }

        /// <summary>
        /// 管理区域Id
        /// </summary>
        public string ManageBranchs { get; set; }

        /// <summary>
        /// 身份证(340103198911301525)
        /// </summary>
        public string IdCard { get; set; }

        /// <summary>
        /// BranchId(52400286)
        /// </summary>
        public int? BranchID { get; set; }

        /// <summary>
        /// 组织架构全路径
        /// </summary>
        [NPoco.Ignore]
        public string HrPath { get; set; }

        /// <summary>
        /// 部门完整路径
        /// </summary>
        public string DeptFullName { get; set; }
    }
}
