﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbcCRM.Domain
{
    /// <summary>
    /// 部门管理
    /// </summary>
    [NPoco.TableName("Basis_Dept")]
    [NPoco.PrimaryKey("Dept_ID", AutoIncrement = true)]
    public class DeptDTO
    {
        /// <summary>
        /// 部门主管
        /// </summary>
        public int Dept_ID { get; set; }

        /// <summary>
        /// SAP架构ID
        /// </summary>
        public int Dept_SapID { get; set; }

        /// <summary>
        /// SAP架构父ID
        /// </summary>
        public int Dept_SapPID { get; set; }

        /// <summary>
        /// 完整路径
        /// </summary>
        public string Dept_FullName { get; set; }

        /// <summary>
        /// 父ID
        /// </summary>
        public int? Dept_ParentID { get; set; }

        /// <summary>
        /// 部门名称
        /// </summary>
        public string Dept_Name { get; set; }

        /// <summary>
        /// 部门树编号
        /// </summary>
        public string Dept_Code { get; set; }

        /// <summary>
        /// 部门类型
        /// </summary>
        public int Dept_Type { get; set; }

        /// <summary>
        /// 创建人
        /// </summary>
        public int? Dept_CreatedBy { get; set; }

        /// <summary>
        /// 创建时间
        /// </summary>
        public DateTime? Dept_CreatedDate { get; set; }

        /// <summary>
        ///  更新人
        /// </summary>
        public int? Dept_UpdatedBy { get; set; }

        /// <summary>
        /// 更新时间
        /// </summary>
        public DateTime? Dept_UpdatedDate { get; set; }

        /// <summary>
        /// 深度
        /// </summary>
        public int Dept_Depth { get; set; }

        /// <summary>
        /// 删除状态
        /// </summary>
        public int Dept_Deleted { get; set; }

        /// <summary>
        /// CRM中心ID
        /// </summary>
        public int Dept_BranchID { get; set; }

        /// <summary>
        /// 所属区域
        /// </summary>
        [NPoco.Ignore]
        public string Dept_Branch_Name { get; set; }

        /// <summary>
        /// 创建人
        /// </summary>
        [NPoco.Ignore]
        public string Dept_CreatedBy_Name { get; set; }

        /// <summary>
        /// 更新人
        /// </summary>
        [NPoco.Ignore]
        public string Dept_UpdatedBy_Name { get; set; }

        /// <summary>
        /// 父节点
        /// </summary>
        [NPoco.Ignore]
        public string Dept_ParentName { get; set; }

    }
}
