﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbcCRM.Domain
{
    /// <summary>
    /// Sap架构
    /// </summary>
    public class SapDept
    {
        //"StructureID": 52400692,
        //"PStructureID": 1239,
        //"StructureCode": 52400692,
        //"NodeType": "D",
        //"NodeCode": "52400692",
        //"NodeName": "运营支持部",
        //"IsDisable": 0,
        //"FullName": "深圳市美联国际教育科技有/总部/教育运营管理中心/青少产品线/运营支持部"

        /// <summary>
        /// 架构ID
        /// </summary>
        public int StructureID { get; set; }

        /// <summary>
        /// 架构父ID
        /// </summary>
        public int PStructureID { get; set; }

        /// <summary>
        /// 架构编码
        /// </summary>
        public int StructureCode { get; set; }

        /// <summary>
        /// 区域/中心Id
        /// </summary>
        public int BranchID { get; set; }

        /// <summary>
        /// 架构类别(R,D)
        /// </summary>
        public string NodeType { get; set; }

        /// <summary>
        /// 架构编码
        /// </summary>
        public string NodeCode { get; set; }

        /// <summary>
        /// 部门名称（深圳市美联国际教育科技有）
        /// </summary>
        public string NodeName { get; set; }

        /// <summary>
        /// 是否禁用 0：正常 1：禁用
        /// </summary>
        public int IsDisable { get; set; }

        /// <summary>
        /// 架构全路径
        /// </summary>
        public string FullName { get; set; }
    }
}
