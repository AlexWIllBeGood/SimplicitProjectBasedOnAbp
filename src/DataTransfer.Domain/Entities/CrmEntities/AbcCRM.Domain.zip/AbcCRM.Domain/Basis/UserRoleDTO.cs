﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbcCRM.Domain
{
    /// <summary>
    /// 用户角色
    /// </summary>
    [NPoco.TableName("Basis_UserRole")]
    [NPoco.PrimaryKey("Urol_ID", AutoIncrement = true)]
    public class UserRoleDTO
    {
        /// <summary>
        /// 主增主键
        /// </summary>
        public int Urol_ID { get; set; }

        /// <summary>
        /// 用户ID
        /// </summary>
        public int Urol_UserID { get; set; }

        /// <summary>
        /// 角色ID
        /// </summary>
        public int Urol_RoleCodeID { get; set; }

        /// <summary>
        /// 角色代码
        /// </summary>
        public string Urol_RoleCode { get; set; }

        /// <summary>
        /// 角色名称
        /// </summary>
        [NPoco.Ignore]
        public string Urol_RoleName { get; set; }

        /// <summary>
        /// 部门
        /// </summary>
        public int? Urol_Depa { get; set; }

        /// <summary>
        /// 部门名称
        /// </summary>
        [NPoco.Ignore]
        public string Urol_DepaName { get; set; }

        /// <summary>
        /// 中心
        /// </summary>
        public int? Urol_Secterr { get; set; }

        /// <summary>
        /// 中心名称
        /// </summary>
        [NPoco.Ignore]
        public string Urol_SecterrName { get; set; }

        /// <summary>
        /// 名称
        /// </summary>
        public string Urol_Name { get; set; }

        /// <summary>
        /// 状态 0 默认角色 1自定义角色 Sap自动创建
        /// </summary>
        public int Urol_Status { get; set; }

        /// <summary>
        /// 创建人
        /// </summary>
        public int? Urol_CreatedBy { get; set; }

        /// <summary>
        /// 创建时间
        /// </summary>
        public DateTime? Urol_CreatedDate { get; set; }

        /// <summary>
        /// 修改人
        /// </summary>
        public int? Urol_UpdatedBy { get; set; }

        /// <summary>
        /// 修改时间
        /// </summary>
        public DateTime? Urol_UpdatedDate { get; set; }

        /// <summary>
        /// 删除状态
        /// </summary>
        public int Urol_Deleted { get; set; }
    }

    [NPoco.TableName("VUserRole")]
    [NPoco.PrimaryKey("Urol_ID", AutoIncrement = true)]
    public class VUserRole : UserRoleDTO
    {
        public string User_Logon { get; set; }

        public string Role_Name { get; set; }

        public string Bran_Name { get; set; }
    }
}
