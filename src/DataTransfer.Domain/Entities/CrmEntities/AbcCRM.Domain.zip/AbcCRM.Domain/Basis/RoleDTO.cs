﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbcCRM.Domain
{
    /// <summary>
    /// 角色表
    /// </summary>
    [NPoco.TableName("Basis_Role")]
    [NPoco.PrimaryKey("Role_ID", AutoIncrement = true)]
    public class RoleDTO
    {
        /// <summary>
        /// 主键
        /// </summary>
        public int Role_ID { get; set; }

        /// <summary>
        /// 名称
        /// </summary>
        public string Role_Name { get; set; }

        private string role_Code;
        /// <summary>
        /// 编码
        /// </summary>
        public string Role_Code
        {
            get { return role_Code.Trim().ToUpper(); }
            set { role_Code = value; }
        }

        /// <summary>
        /// 部门
        /// </summary>
        public int Role_Depa { get; set; }

        /// <summary>
        /// 部门名称
        /// </summary>
        [NPoco.Ignore]
        public string Role_DepaName { get; set; }

        /// <summary>
        /// 删除标志
        /// </summary>
        public int Role_Deleted { get; set; }

        /// <summary>
        ///  创建人
        /// </summary>
        public int Role_CreatedBy { get; set; }

        /// <summary>
        /// 创建时间
        /// </summary>
        public DateTime Role_CreatedDate { get; set; }

        /// <summary>
        /// 更新人
        /// </summary>
        public int? Role_UpdatedBy { get; set; }

        /// <summary>
        /// 更新时间
        /// </summary>
        public DateTime? Role_UpdatedDate { get; set; }
    }
}
