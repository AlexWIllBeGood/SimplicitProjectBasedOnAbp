﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbcCRM.Domain.Basis
{
    /// <summary>
    /// 小组管理
    /// </summary>
    [NPoco.TableName("Basis_Group")]
    [NPoco.PrimaryKey("Group_ID", AutoIncrement = true)]
    public class GroupDTO
    {
        /// <summary>
        /// 主键ID
        /// </summary>
        public int Group_ID { get; set; }

        /// <summary>
        /// 中心ID
        /// </summary>
        public int Group_BranID { get; set; }

        /// <summary>
        /// 中心名称
        /// </summary>
        [NPoco.Ignore]
        public string Group_BranName { get; set; }

        /// <summary>
        /// 小组编码
        /// </summary>
        public string Group_Code { get; set; }

        /// <summary>
        /// 小组名称
        /// </summary>
        public string Group_Name { get; set; }

        /// <summary>
        /// 备注
        /// </summary>
        public string Group_Remark { get; set; }

        /// <summary>
        /// 小组类型（预留）
        /// </summary>
        public int Group_Type { get; set; }

        /// <summary>
        /// 创建人
        /// </summary>
        public int? Group_CreatedBy { get; set; }

        /// <summary>
        /// 创建时间
        /// </summary>
        public DateTime? Group_CreatedDate { get; set; }

        /// <summary>
        /// 更新人
        /// </summary>
        public int? Group_UpdatedBy { get; set; }

        /// <summary>
        /// 更新时间
        /// </summary>
        public DateTime? Group_UpdatedDate { get; set; }

        /// <summary>
        /// 删除标志
        /// </summary>
        public int Group_Deleted { get; set; }

        /// <summary>
        /// 创建名
        /// </summary>
        [NPoco.Ignore]
        public string Group_CreatedBy_Name { get; set; }

        /// <summary>
        /// 更新名
        /// </summary>
        [NPoco.Ignore]
        public string Group_UpdatedBy_Name { get; set; }
    }
}
