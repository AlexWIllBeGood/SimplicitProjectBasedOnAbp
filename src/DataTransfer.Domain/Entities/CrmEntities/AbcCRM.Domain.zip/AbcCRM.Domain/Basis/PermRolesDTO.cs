﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbcCRM.Domain
{
    /// <summary>
    /// 角色权限表
    /// </summary>
    [NPoco.TableName("Basis_PermRole")]
    [NPoco.PrimaryKey("Rope_ID", AutoIncrement = true)]
    public class PermRoleDTO
    {
        /// <summary>
        /// 用户ID
        /// </summary>
        public int Rope_ID { get; set; }

        /// <summary>
        /// 角色ID
        /// </summary>
        public int Rope_RoleID { get; set; }

        /// <summary>
        /// 角色ID
        /// </summary>
        public string Rope_RoleCode { get; set; }

        /// <summary>
        /// 权限ID
        /// </summary>
        public int Rope_PermID { get; set; }

        /// <summary>
        /// 权限代码
        /// </summary>
        public string Rope_PermCode { get; set; }

        /// <summary>
        /// 状态
        /// </summary>
        public int Rope_Status { get; set; }

        /// <summary>
        /// 删除状态
        /// </summary>
        public int Rope_Deleted { get; set; }

        /// <summary>
        /// 创建人
        /// </summary>
        public int Rope_CreatedBy { get; set; }

        /// <summary>
        /// 创建时间
        /// </summary>
        public DateTime Rope_CreatedDate { get; set; }

        /// <summary>
        /// 修改人
        /// </summary>
        public int? Rope_UpdatedBy { get; set; }

        /// <summary>
        /// 修改时间
        /// </summary>
        public DateTime? Rope_UpdatedDate { get; set; }
    }

    /// <summary>
    /// 角色权限表
    /// </summary>
    [NPoco.TableName("Basis_PermRole")]
    [NPoco.PrimaryKey("Rope_ID", AutoIncrement = true)]
    public class PermRoleShowDTO : PermRoleDTO
    {
        /// <summary>
        /// 角色信息
        /// </summary>
        [NPoco.Ignore]
        public RoleDTO RoleInfo { get; set; }
    }
}
