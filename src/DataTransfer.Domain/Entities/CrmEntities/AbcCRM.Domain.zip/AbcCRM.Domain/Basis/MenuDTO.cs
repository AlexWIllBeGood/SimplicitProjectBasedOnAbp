﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbcCRM.Domain
{
    /// <summary>
    /// 菜单管理
    /// </summary>
    [NPoco.TableName("Basis_Menu")]
    [NPoco.PrimaryKey("menu_id", AutoIncrement = true)]
    public class MenuDTO
    {
        /// <summary>
        /// 菜单主键
        /// </summary>
        public int Menu_ID { get; set; }

        /// <summary>
        /// 父级
        /// </summary>
        public int Menu_Parent_ID { get; set; }

        /// <summary>
        /// 父级名称
        /// </summary>
        [NPoco.Ignore]
        public string Menu_Parent_Name { get; set; }

        /// <summary>
        /// 名称
        /// </summary>
        public string Menu_Name { get; set; }

        /// <summary>
        /// 角色
        /// </summary>
        public string Menu_Role_Code { get; set; }

        /// <summary>
        /// Controller
        /// </summary>
        public string Menu_Controller { get; set; }

        /// <summary>
        /// Action
        /// </summary>
        public string Menu_Action { get; set; }

        /// <summary>
        /// 图标
        /// </summary>
        public string Menu_Icon { get; set; }

        /// <summary>
        /// 删除标记
        /// </summary>
        public int Menu_Deleted { get; set; }

        /// <summary>
        /// 排序
        /// </summary>
        public int Menu_Sort { get; set; }

        /// <summary>
        /// 角色列表
        /// </summary>
        [NPoco.Ignore]
        public List<string> RoleCodes => Menu_Role_Code?.Split(',').ToList() ?? new List<string>();

        /// <summary>
        /// 子菜单
        /// </summary>
        [NPoco.Ignore]
        public IEnumerable<MenuDTO> Childs { get; set; }
    }
}
