﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbcCRM.Domain
{
    /// <summary>
    /// 权限
    /// </summary>
    [NPoco.TableName("Basis_Perm")]
    [NPoco.PrimaryKey("Perm_ID", AutoIncrement = true)]
    public class PermDTO
    {
        /// <summary>
        /// ID
        /// </summary>
        public int Perm_ID { get; set; }

        /// <summary>
        /// 权限名
        /// </summary>
        public string Perm_Name { get; set; }

        /// <summary>
        /// 权限Code
        /// </summary>
        public string Perm_Code { get; set; }

        /// <summary>
        /// 权限描述
        /// </summary>
        public string Perm_Remark { get; set; }

        /// <summary>
        /// 状态
        /// </summary>
        public int Perm_Status { get; set; }

        /// <summary>
        /// 删除状态
        /// </summary>
        public int Perm_Deleted { get; set; }

        /// <summary>
        /// 创建人
        /// </summary>
        public int Perm_CreatedBy { get; set; }

        /// <summary>
        /// 创建时间
        /// </summary>
        public DateTime Perm_CreatedDate { get; set; }

        /// <summary>
        /// 更新人
        /// </summary>
        public int? Perm_UpdatedBy { get; set; }

        /// <summary>
        /// 更新时间
        /// </summary>
        public DateTime? Perm_UpdatedDate { get; set; }
    }

    /// <summary>
    /// 角色权限
    /// </summary>
    [NPoco.TableName("Basis_Perm")]
    [NPoco.PrimaryKey("Perm_ID", AutoIncrement = true)]
    public class PermShowDTO : PermDTO
    {
        /// <summary>
        /// 权限
        /// </summary>
        [NPoco.Ignore]
        public List<PermRoleShowDTO> RolePermissions { get; set; }

        /// <summary>
        /// 角色ID
        /// </summary>
        [NPoco.Ignore]
        public List<int> RoleCodeIds { get; set; }
    }
}
