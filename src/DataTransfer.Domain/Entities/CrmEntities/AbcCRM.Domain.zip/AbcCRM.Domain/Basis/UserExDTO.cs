﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//namespace AbcCRM.Domain.Basis
//{
//    public class UserExDTO : UserDTO
//    {
//        /// <summary>
//        /// 角色码
//        /// </summary>
//        public string Urol_RoleCode { get; set; }
//    }
//}
