﻿using MetenWF;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbcCRM.Domain
{
    /// <summary>
    /// 工作流展示模型
    /// </summary>
    public class WorkflowShow: WorkflowInstance
    {
        /// <summary>
        /// 工作流
        /// </summary>
        public string Wf_Name { get; set; }

        /// <summary>
        /// 当前状态名称
        /// </summary>
        [NPoco.Ignore]
        public string Iw_Status_Name { get; set; }

        /// <summary>
        /// 中心名称
        /// </summary>
        [NPoco.Ignore]
        public string Iw_Secterr1_Name { get; set; }

        /// <summary>
        /// 当前节点名称
        /// </summary>
        [NPoco.Ignore]
        public string Iw_ActInst_Name { get; set; }
    }

    /// <summary>
    /// 待办工作流展示模型
    /// </summary>
    public class WorkflowTodoShow : WorkflowShow
    {
        /// <summary>
        /// 当前节点ID
        /// </summary>
        public int Ia_ID { get; set; }

        /// <summary>
        /// 当前节点名称
        /// </summary>
        public string Ia_Name { get; set; }

        /// <summary>
        /// 来件时间
        /// </summary>
        public DateTime Ia_InDate { get; set; }
    }
}
