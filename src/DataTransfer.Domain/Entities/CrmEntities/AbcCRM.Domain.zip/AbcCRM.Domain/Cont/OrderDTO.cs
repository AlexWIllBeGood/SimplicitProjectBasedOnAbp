﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbcCRM.Domain
{
    /// <summary>
    /// 订单
    /// </summary>
    [NPoco.TableName("Orders")]
    [NPoco.PrimaryKey("Orde_ID", AutoIncrement = true)]
    public class OrderDTO
    {
        /// <summary>
        /// 主键
        /// </summary>
        public int Orde_ID { get; set; }

        /// <summary>
        /// 试听记录ID
        /// </summary>
        public int? Orde_DerdID { get; set; }

        /// <summary>
        /// 订单号
        /// </summary>
        public string Orde_Number { get; set; }

        /// <summary>
        /// 班级源数据
        /// </summary>
        public int? Orde_ClassSource { get; set; }

        /// <summary>
        /// 关联lead
        /// </summary>
        public int Orde_LeadID { get; set; }

        /// <summary>
        /// 订单类型：订金，合同
        /// </summary>
        public string Orde_Type { get; set; }

        [NPoco.Ignore]
        public string Orde_Type_Name { get; set; }
        /// <summary>
        /// 订金类型 （0：正常订金，1：老系统订金）
        /// </summary>
        public int Orde_DepositType { get; set; }
        [NPoco.Ignore]
        public string Orde_DepositType_Name { get; set; }
        /// <summary>
        /// 订单签订类型：0新签，1续费，2转班
        /// </summary>
        public int Orde_SignType { get; set; }

        [NPoco.Ignore]
        public string Orde_SignType_Name { get; set; }

        /// <summary>
        /// 订单状态：0待收，1已收启动,2待退定金，3已退定金，4退费完结，-1定金转学费中，-2审批中
        /// </summary>
        public string Orde_Status { get; set; }

        [NPoco.Ignore]
        public string Orde_Status_Name { get; set; }
        /// <summary>
        /// 立刻说订单同步状态 0:待同步,1:已同步创建，2：已同步启动，3：已同步冻结 4：退费完结 -1:立刻说创建
        /// </summary>
        public int Orde_SyncStatus { get; set; }
        [NPoco.Ignore]
        public string Orde_SyncStatus_Name { get; set; }
        /// <summary>
        /// 搭售捆绑关系
        /// </summary>
        public string Orde_BundleSale { get; set; }

        /// <summary>
        /// 客户选择的开课时间
        /// </summary>
        public DateTime? Orde_BeginDate { get; set; }

        /// <summary>
        /// 订单金额
        /// </summary>
        public decimal Orde_Amount { get; set; }

        /// <summary>
        /// 应收金额
        /// </summary>
        public decimal Orde_AccountReceivable { get; set; }

        /// <summary>
        /// 实收金额
        /// </summary>
        public decimal Orde_CashReceived { get; set; }

        /// <summary>
        /// 启动时间
        /// </summary>
        public DateTime? Orde_SignUpDate { get; set; }

        /// <summary>
        /// 所属中心
        /// </summary>
        public int Orde_Branch { get; set; }
        [NPoco.Ignore]
        public string Orde_Branch_Name { get; set; }
        /// <summary>
        /// 所属中心SAPID
        /// </summary>
        [NPoco.Ignore]
        public int Orde_Branch_SapID { get; set; }

        /// <summary>
        /// 签单CC
        /// </summary>
        public int Orde_OrderCC { get; set; }

        /// <summary>
        /// 签单CC名称
        /// </summary>
        [NPoco.Ignore]
        public string Orde_OrderCC_Name { get; set; }

        /// <summary>
        /// 当前CC
        /// </summary>
        public int Orde_Sales { get; set; }

        /// <summary>
        /// 当前CC名称
        /// </summary>
        [NPoco.Ignore]
        public string Orde_Sales_Name { get; set; }

        /// <summary>
        /// 当前CC账号
        /// </summary>
        [NPoco.Ignore]
        public string Orde_Sales_OAName { get; set; }

        /// <summary>
        /// 服务SA
        /// </summary>
        public int Orde_Sa { get; set; }

        [NPoco.Ignore]
        public string Orde_Sa_Name { get; set; }

        /// <summary>
        /// 产品大类
        /// </summary>
        public int Orde_ProductType { get; set; }

        [NPoco.Ignore]
        /// <summary>
        /// 产品级别（临时存取）
        /// </summary>
        public string Orde_ProductLevels { get; set; }

        /// <summary>
        /// 产品大类名称
        /// </summary>
        [NPoco.Ignore]
        public string Orde_ProductType_Name { get; set; }

        /// <summary>
        /// 创建人
        /// </summary>
        public int Orde_CreatedBy { get; set; }

        [NPoco.Ignore]
        public string Orde_CreatedBy_Name { get; set; }

        public DateTime? Orde_CreatedDate { get; set; }

        public int Orde_UpdatedBy { get; set; }

        [NPoco.Ignore]
        public string Orde_UpdatedBy_Name { get; set; }

        public DateTime? Orde_UpdatedDate { get; set; }

        public int Orde_Deleted { get; set; }

        /// <summary>
        /// 购买的产品列表
        /// </summary>
        [NPoco.Ignore]
        public List<SalesProPrice> SaleProList { get; set; }

        [NPoco.Ignore]
        public List<ContractShow> ContList { get; set; }

        /// <summary>
        /// 备注
        /// </summary>
        public string Orde_Remark { get; set; }

        /// <summary>
        /// 折扣率
        /// </summary>
        public decimal? Orde_DiscountRate { get; set; }

        /// <summary>
        /// 折扣类型
        /// </summary>
        public int? Orde_DiscountRateType { get; set; }

        /// <summary>
        /// 满减
        /// </summary>
        public decimal Orde_DiscountAmount { get; set; }

        /// <summary>
        /// 满减类型
        /// </summary>
        public int? Orde_DiscountAmountType { get; set; }

        /// <summary>
        /// 折扣申请ID
        /// </summary>
        public int? Orde_DiscountApplyID { get; set; }

        /// <summary>
        /// 订金ID（订金转学费）
        /// </summary>
        public string Orde_Deposit { get; set; }

        /// <summary>
        /// 代金券赠送设置ID（不满足时值为-1）
        /// </summary>
        public string Orde_VoucherSetIDs { get; set; }

        /// <summary>
        /// 订金ID list
        /// </summary>
        [NPoco.Ignore]
        public List<int> Deposits
        {
            get { return string.IsNullOrEmpty(Orde_Deposit) ? new List<int>() : Common.CommonHelper.JsonDeserialize<List<int>>(Orde_Deposit); }
            set { Orde_Deposit = Common.CommonHelper.JsonSerialize(value); }
        }

        /// <summary>
        /// 转班记录
        /// </summary>
        [NPoco.Ignore]
        public List<ClassStudentTransferLog> TransferLog { get; set; } = new List<ClassStudentTransferLog>();
        /// <summary>
        /// 搭售立刻说产品列表
        /// </summary>
        public string Orde_LKSPros { get; set; }
        /// <summary>
        /// 搭售立刻说产品列表
        /// </summary>
        [NPoco.Ignore]
        public List<LksProDTO> LksPros{ get; set; }

        /// <summary>
        /// 是否使用POS收款流程(包括微信、支付宝)
        /// </summary>
        public bool Orde_IsPos { get; set; }

        /// <summary>
        /// 微信OpenID
        /// </summary>
        [NPoco.Ignore]
        public string WechatOpenID { get; set; }
    }

    /// <summary>
    /// 搭售订单
    /// </summary>
    public class OrderMultiple
    {
        /// <summary>
        /// 主订单
        /// </summary>
        public OrderDTO order { get; set; }
        /// <summary>
        /// 搭售订单
        /// </summary>
        public List<OrderDTO> orderList { get; set; }

    }

    /// <summary>
    /// 搭售立刻说产品
    /// </summary>
    public class LksProDTO
    {
        /// <summary>
        /// 产品名称
        /// </summary>
        public string ProductName { get; set; }
        /// <summary>
        /// 产品Code
        /// </summary>
        public string ProductNo { get; set; }
        /// <summary>
        /// 数量
        /// </summary>
        public int Quantity { get; set; }
    }

    [NPoco.TableName("VOrder")]
    [NPoco.PrimaryKey("Orde_ID", AutoIncrement = true)]
    public class OrderShow : OrderDTO
    {
        public string Lead_Name { get; set; }

        public string Lead_Mobile { get; set; }

        /// <summary>
        /// 判断当前登录用户是否该记录销售或管理员
        /// </summary>
        [NPoco.Ignore]
        public bool IsSelf { get; set; }

        /// <summary>
        /// 已收金额（包含收款中和审批中）（不包含收款中的线上支付）
        /// </summary>
        [NPoco.Ignore]
        public decimal Orde_PosCashReceived { get; set; }

        /// <summary>
        /// POS未收金额
        /// </summary>
        [NPoco.Ignore]
        public decimal Orde_PosUnCollected { get; set; }

        /// <summary>
        /// 收款列表
        /// </summary>
        [NPoco.Ignore]
        public List<AccountRecordDTO> Orde_PosPayments { get; set; }
    }
}
