﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbcCRM.Domain
{
    /// <summary>
    /// 收银表
    /// </summary>
    [NPoco.TableName("AccountRecord")]
    [NPoco.PrimaryKey("acrd_Id", AutoIncrement = true)]
    public class AccountRecordDTO
    {
        /// <summary>
        /// 自增ID
        /// </summary>
        public int Acrd_ID { get; set; }

        /// <summary>
        /// 对应收款/退款ID
        /// </summary>
        public int Acrd_OldID { get; set; }

        /// <summary>
        /// 收银区域
        /// </summary>
        public int Acrd_Branch { get; set; }

        [NPoco.Ignore]
        public string Acrd_Branch_Name { get; set; }

        /// <summary>
        /// 合同
        /// </summary>
        public int Acrd_ContractID { get; set; }

        /// <summary>
        /// 客户
        /// </summary>
        public int Acrd_LeadID { get; set; }

        /// <summary>
        /// 收退款（0收款，1退款）
        /// </summary>
        public int Acrd_Type { get; set; }

        [NPoco.Ignore]
        public string Acrd_Type_Name { get; set; }

        /// <summary>
        /// 合同类型，1为订金，2为正式
        /// </summary>
        public int Acrd_ContType { get; set; }

        /// <summary>
        /// 收退款类型（1定金，2定金转学费，3学费，4餐费，5保险费，6VIP补卡费,7转班，8老定金,9老定金转学费）
        /// </summary>
        public int Acrd_CollectType { get; set; }

        [NPoco.Ignore]
        public string Acrd_CollectType_Name { get; set; }

        /// <summary>
        /// 收款方式 POS机（UnionPayA、UnionPay_wechat、UnionPay_wechat_s、UnionPay_ali、UnionPay_ali_s） 线上支付（wechat、alipay）
        /// </summary>
        public string Acrd_Way { get; set; }

        /// <summary>
        /// 收款方式（现金、刷卡、扫码等）（关联表AccountWay）
        /// </summary>
        public int Acrd_CollectWay { get; set; }

        /// <summary>
        /// 老系统导入的收费类型
        /// </summary>
        public string Acrd_OldAccountWay { get; set; }

        [NPoco.Ignore]
        public string Acrd_CollectWay_Name { get; set; }

        /// <summary>
        /// 收款来源：1、POS机 2、线上支付
        /// </summary>
        public int Acrd_CollectWayType { get; set; }

        [NPoco.Ignore]
        public string Acrd_CollectWayType_Name { get; set; }

        /// <summary>
        /// 收款状态 -4取消支付，-3收款失败，-2收款中，-1收款审批中，0已生效
        /// </summary>
        public int Acrd_Status { get; set; }

        [NPoco.Ignore]
        public string Acrd_Status_Name { get; set; }

        /// <summary>
        /// Guid
        /// </summary>
        public string Acrd_Guid { get; set; }

        /// <summary>
        /// POS机设备号
        /// </summary>
        public string Acrd_PosNum { get; set; }

        /// <summary>
        /// POS机商户号
        /// </summary>
        public string Acrd_MerchantId { get; set; }

        /// <summary>
        /// POS机返回值
        /// </summary>
        public string Acrd_Res { get; set; }

        /// <summary>
        /// 金额
        /// </summary>
        public decimal Acrd_Amount { get; set; }

        public decimal Acrd_Fee { get; set; }

        public string Acrd_Receipt { get; set; }

        public DateTime? Acrd_CollectDate { get; set; }

        public string Acrd_Remark { get; set; }

        public int? Acrd_CreatedBy { get; set; }

        [NPoco.Ignore]
        public string Acrd_CreatedBy_Name { get; set; }

        public DateTime? Acrd_CreatedDate { get; set; }

        public int? Acrd_UpdatedBy { get; set; }

        [NPoco.Ignore]
        public string Acrd_UpdatedBy_Name { get; set; }

        public DateTime? Acrd_UpdatedDate { get; set; }

        /// <summary>
        /// 删除标志位
        /// </summary>
        public int Acrd_Deleted { get; set; }

        /// <summary>
        /// 商户订单号
        /// </summary>
        public string Acrd_Cmborder { get; set; }

        public string Acrd_Bank { get; set; }

        public string Acrd_BankUser { get; set; }

        public string Acrd_BankAccount { get; set; }

        public int Acrd_OrderID { get; set; }
        /// <summary>
        /// 同步修改业绩
        /// </summary>
        [NPoco.Ignore]
        public int IsSyncRes { get; set; }
        /// <summary>
        /// 本月修改收退款
        /// </summary>
        [NPoco.Ignore]
        public bool IsUpdateMonth { get; set; }
        /// <summary>
        /// 本月修改收退款
        /// </summary>
        [NPoco.Ignore]
        public bool IsUpdateDay { get; set; }
        /// <summary>
        /// 无时间限制修改收退款
        /// </summary>
        [NPoco.Ignore]
        public bool IsUpdate { get; set; }
        /// <summary>
        /// 系统收退款类型，不开放编辑
        /// </summary>
        [NPoco.Ignore]
        public bool IsCollectType { get; set; }
        /// <summary>
        /// 审核按钮
        /// </summary>
        [NPoco.Ignore]
        public bool IsReview { get; set; }

        /// <summary>
        /// 收据号
        /// </summary>
        public string Acrd_ReceiptNumber { get; set; }
    }

    /// <summary>
    /// 收退款明细
    /// </summary>
    [NPoco.TableName("VAccountShow")]
    public class AccountRecordShow : AccountRecordDTO
    {
        public string Orde_Number { get; set; }

        public int Orde_ID { get; set; }

        public int Orde_Sales { get; set; }

        public int Orde_Branch { get; set; }

        [NPoco.Ignore]
        public string Orde_Sales_Name { get; set; }

        public int Orde_Status { get; set; }

        [NPoco.Ignore]
        public string Orde_Status_Name { get; set; }

        ///// <summary>
        ///// 客户选择的开课时间
        ///// </summary>
        //public DateTime? Orde_BeginDate { get; set; }

        /// <summary>
        /// 订单启动时间
        /// </summary>
        public DateTime? Orde_SignUpDate { get; set; }

        /// <summary>
        /// 客户
        /// </summary>
        public int Lead_LeadID { get; set; }

        public int Lead_Gender { get; set; }

        public string Lead_Name { get; set; }
    }

    /// <summary>
    /// 收款方式
    /// </summary>
    [NPoco.TableName("AccountWay")]
    [NPoco.PrimaryKey("acwy_Id", AutoIncrement = true)]
    public class AccountWayDTO
    {
        public int Acwy_ID { get; set; }

        public string Acwy_Name { get; set; }

        /// <summary>
        /// 父级为0
        /// </summary>
        public int Acwy_ParentID { get; set; }

        public int Acwy_Depth { get; set; }

        /// <summary>
        /// 费率
        /// </summary>
        public decimal Acwy_Rate { get; set; }

        public decimal Acwy_Max { get; set; }

        public decimal Acwy_Min { get; set; }

        /// <summary>
        /// 状态 0启用1禁用
        /// </summary>
        public int Acwy_Status { get; set; }

        public int? Acwy_CreatedBy { get; set; }

        public DateTime? Acwy_CreatedDate { get; set; }

        public int? Acwy_UpdatedBy { get; set; }

        public DateTime? Acwy_UpdatedDate { get; set; }

        public int Acwy_Deleted { get; set; }


        [NPoco.Ignore]
        public string Acwy_Title { get; set; }

        [NPoco.Ignore]
        public string Acwy_ParentType { get; set; }

        [NPoco.Ignore]
        public string Acwy_Status_Name { get; set; }

        [NPoco.Ignore]
        public string Acwy_CreatedBy_Name { get; set; }

        [NPoco.Ignore]
        public string Acwy_UpdatedBy_Name { get; set; }
    }
}
