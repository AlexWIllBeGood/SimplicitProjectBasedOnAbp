﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbcCRM.Domain
{
    /// <summary>
    /// 立刻说Demo
    /// </summary>
    [NPoco.TableName("Lks_DemoRecord")]
    [NPoco.PrimaryKey("Ldrd_ID", AutoIncrement = true)]
    public class LksDemoDTO
    {
        /// <summary>
        /// 主键自增ID
        /// </summary>
        public int Ldrd_ID { get; set; }
        /// <summary>
        /// leadID
        /// </summary>
        public int Ldrd_LeadID { get; set; }
        /// <summary>
        /// DEMO所属CC
        /// </summary>
        public int? Ldrd_Sales { get; set; }
        /// <summary>
        /// DEMO所属中心
        /// </summary>
        public int Ldrd_BranchID { get; set; }
        /// <summary>
        /// 关联的机会ID
        /// </summary>
        public int Ldrd_OppoID { get; set; }
        /// <summary>
        /// 第三方Demo编码(DemoId)
        /// </summary>
        public string Ldrd_DemoCode { get; set; }
        /// <summary>
        /// Demo课堂编码
        /// </summary>
        public string Ldrd_DemoArrangeCode { get; set; }
        /// <summary>
        /// 请求人
        /// </summary>
        public string Ldrd_RequestName { get; set; }
        /// <summary>
        /// 请求时间
        /// </summary>
        public DateTime? Ldrd_RequestTime { get; set; }
        /// <summary>
        /// 请求备注
        /// </summary>
        public string Ldrd_RequestRemark { get; set; }
        /// <summary>
        /// 学员编号(手机号)
        /// </summary>
        public string Ldrd_StudentNo { get; set; }
        /// <summary>
        /// Demo状态
        /// </summary>
        public string Ldrd_State { get; set; }
        /// <summary>
        /// 上课时间
        /// </summary>
        public DateTime? Ldrd_ClassTime { get; set; }
        /// <summary>
        /// 上课主题
        /// </summary>
        public string Ldrd_Topic { get; set; }
        /// <summary>
        /// 课件名称
        /// </summary>
        public string Ldrd_Title { get; set; }
        /// <summary>
        /// 教师类型
        /// </summary>
        public string Ldrd_TeachingObject { get; set; }
        /// <summary>
        /// 教师产线
        /// </summary>
        public string Ldrd_TeacherProductLine { get; set; }
        /// <summary>
        /// 教师姓名
        /// </summary>
        public string Ldrd_TeacherName { get; set; }
        /// <summary>
        /// Demo备注
        /// </summary>
        public string Ldrd_Remarks { get; set; }
        /// <summary>
        /// 学员出席状态
        /// </summary>
        public string Ldrd_StudentAttendance { get; set; }
        /// <summary>
        /// 老师出席状态
        /// </summary>
        public string Ldrd_TeacherAttendance { get; set; }
        /// <summary>
        /// Demo创建时间
        /// </summary>
        public DateTime? Ldrd_CreateTime { get; set; }
        /// <summary>
        /// Demo修改时间
        /// </summary>
        public DateTime? Ldrd_UpdateTime { get; set; }
        /// <summary>
        /// Demo修改人
        /// </summary>
        public string Ldrd_UpdateName { get; set; }
        /// <summary>
        /// Demo操作人类型
        /// </summary>
        public string Ldrd_OperatorNameType { get; set; }
        /// <summary>
        /// 系统创建时间
        /// </summary>
        public DateTime Ldrd_CreatedDate { get; set; }
        /// <summary>
        /// 系统更新人
        /// </summary>
        public int Ldrd_UpdatedBy { get; set; }

        /// <summary>
        /// 系统更新时间
        /// </summary>
        public DateTime Ldrd_UpdatedDate { get; set; }
        /// <summary>
        /// 标记删除位
        /// </summary>
        public int Ldrd_Deleted { get; set; }
        /// <summary>
        /// 取消Demo原因
        /// </summary>
        public string Ldrd_CancelReason { get; set; }
        
    }

    /// <summary>
    /// Demo视图
    /// </summary>
    [NPoco.TableName("VDemoRecord")]
    public class VLksDemo:LksDemoDTO
    {
        /// <summary>
        /// 客户姓名
        /// </summary>
        public string Lead_Name { get; set; }
        /// <summary>
        /// 客户手机号
        /// </summary>
        public string Lead_Mobile { get; set; }
        /// <summary>
        /// 机会CCID
        /// </summary>
        public int Oppo_CC { get; set; }
        /// <summary>
        /// 机会CC姓名
        /// </summary>
        [NPoco.Ignore]
        public string Oppo_CC_Name { get; set; }
        /// <summary>
        /// DemoCC姓名
        /// </summary>
        [NPoco.Ignore]
        public string Ldrd_Sales_Name { get; set; }
        /// <summary>
        /// Demo中心
        /// </summary>
        [NPoco.Ignore]
        public string Ldrd_Branch_Name { get; set; }
        
    }
}
