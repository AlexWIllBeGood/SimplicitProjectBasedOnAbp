﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbcCRM.Domain
{
    /// <summary>
    /// 业绩
    /// </summary>
    [NPoco.TableName("Results")]
    [NPoco.PrimaryKey("resu_ResultsID", AutoIncrement = true)]
    public class ResultsDTO
    {
        /// <summary>
        /// 主键ID
        /// </summary>
        public int Resu_ResultsID { get; set; }

        /// <summary>
        /// 业绩分配时间
        /// </summary>
        public DateTime Resu_DistDate { get; set; }

        /// <summary>
        /// 业绩分配人
        /// </summary>
        public int Resu_CreatedBy { get; set; }

        /// <summary>
        /// 创建时间
        /// </summary>
        public DateTime Resu_CreatedDate { get; set; }

        /// <summary>
        /// 修改人
        /// </summary>
        public int? Resu_UpdatedBy { get; set; }

        /// <summary>
        /// 修改时间
        /// </summary>
        public DateTime? Resu_UpdatedDate { get; set; }

        /// <summary>
        /// 业绩类型：1新增业绩，2扣除业绩
        /// </summary>
        public int Resu_Type { get; set; }

        /// <summary>
        /// 业绩归属 1市场/2RR教学
        /// </summary>
        public int Resu_BelongTo { get; set; }

        /// <summary>
        /// 业绩中心
        /// </summary>
        public int Resu_Branch { get; set; }

        /// <summary>
        /// 业绩CC
        /// </summary>
        public int Resu_Sales { get; set; }

        /// <summary>
        /// 业绩SA
        /// </summary>
        public int Resu_SA { get; set; }

        /// <summary>
        /// 客户
        /// </summary>
        public int Resu_LeadID { get; set; }

        /// <summary>
        /// 客户合同
        /// </summary>
        public int Resu_ContractID { get; set; }

        /// <summary>
        /// 业绩金额
        /// </summary>
        public decimal Resu_Amount { get; set; }

        /// <summary>
        /// 是否显示修改
        /// </summary>
        [NPoco.Ignore]
        public bool IsUpdate { get; set; }

        /// <summary>
        /// 管理员权限
        /// </summary>
        [NPoco.Ignore]
        public bool IsSuperEdit { get; set; }

        /// <summary>
        /// 删除标志位
        /// </summary>
        public int Resu_Deleted { get; set; }

        /// <summary>
        /// 对应扣减业绩ID
        /// </summary>
        public int Resu_OldResultsID { get; set; }

        /// <summary>
        /// 订单
        /// </summary>
        public int Resu_OrderID { get; set; }

        /// <summary>
        /// SA名称
        /// </summary>
        [NPoco.Ignore]
        public string Resu_SA_Name { get; set; }

        ///// <summary>
        ///// 客户家庭
        ///// </summary>
        //public int Resu_FamilyID { get; set; }

        //[NPoco.Ignore]
        //public string Resu_Family_Name { get; set; }

        [NPoco.Ignore]
        public string Resu_Sales_Name { get; set; }

        [NPoco.Ignore]
        public string Resu_Branch_Name { get; set; }

        [NPoco.Ignore]
        public string Resu_Type_Name { get; set; }

        [NPoco.Ignore]
        public string Resu_CreatedBy_Name { get; set; }

        [NPoco.Ignore]
        public string Resu_UpdatedBy_Name { get; set; }

        [NPoco.Ignore]
        public string Resu_BelongTo_Name { get; set; }

        /// <summary>
        /// 业绩备注
        /// </summary>
        public string Resu_Remark { get; set; }
    }

    [NPoco.TableName("VResults")]
    public class ResultsShow : ResultsDTO
    {
        public int Orde_Id { get; set; }

        public int Orde_Status { get; set; }

        [NPoco.Ignore]
        public string Orde_Status_Name { get; set; }

        /// <summary>
        /// 订单号
        /// </summary>
        public string Orde_Number { get; set; }
        public int Orde_ProductType { get; set; }

        /// <summary>
        /// 客户名称
        /// </summary>
        public string Lead_Name { get; set; }

        /// <summary>
        /// 客户ID
        /// </summary>
        public int Lead_LeadID { get; set; }
    }
}
