﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbcCRM.Domain
{
    /// <summary>
    /// 业绩修改记录表
    /// </summary>
    [NPoco.TableName("ResultsLog")]
    [NPoco.PrimaryKey("Resl_ID", AutoIncrement = true)]
    public class ResultLogDTO
    {
        /// <summary>
        /// 主键自增ID
        /// </summary>
        public int Resl_ID{ get; set; }
        /// <summary>
        /// 修改前
        /// </summary>
        public string Resl_Before { get; set; }
        [NPoco.Ignore]
        public ResultsContDTO Before { get; set; }
        /// <summary>
        /// 修改后
        /// </summary>
        public string Resl_After { get; set; }
        [NPoco.Ignore]
        public ResultsContDTO After { get; set; }
        /// <summary>
        /// 业绩ID
        /// </summary>
        public int Resl_ResultID { get; set; }
       
        /// <summary>
        /// 创建人
        /// </summary>
        public int Resl_CreatedBy { get; set; }
        [NPoco.Ignore]
        public string Resl_CreatedBy_Name { get; set; }
        /// <summary>
        /// 创建时间
        /// </summary>
        public DateTime Resl_CreatedDate { get; set; }
    }
}
