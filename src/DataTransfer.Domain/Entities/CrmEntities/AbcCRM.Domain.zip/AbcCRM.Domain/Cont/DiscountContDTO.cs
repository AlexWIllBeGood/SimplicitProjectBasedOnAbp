﻿using AbcCRM.Common;
using AbcCRM.Domain.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbcCRM.Domain
{
    /// <summary>
    /// 合同使用折扣明细
    /// </summary>
    [NPoco.TableName("DiscountCont")]
    [NPoco.PrimaryKey("Dist_ID", AutoIncrement = true)]
    public class DiscountContDTO
    {
        /// <summary>
        /// 主键ID
        /// </summary>
        public int Dist_ID { get; set; }

        /// <summary>
        /// 学员ID
        /// </summary>
        public int Dist_LeadID { get; set; }

        /// <summary>
        /// 订单ID
        /// </summary>
        public int Dist_OrderID { get; set; }

        /// <summary>
        /// 合同ID
        /// </summary>
        public int Dist_ContID { get; set; }

        /// <summary>
        /// 合同
        /// </summary>
        [NPoco.Ignore]
        public ContractDTO Contract { get; set; }

        /// <summary>
        /// 优惠金额
        /// </summary>
        public decimal? Dist_Amount { get; set; }

        /// <summary>
        /// 优惠折扣
        /// </summary>
        public decimal? Dist_Rate { get; set; }

        /// <summary>
        /// 折扣类型ID
        /// </summary>
        public int? Dist_DiscID { get; set; }

        /// <summary>
        /// 申请ID/代金券ID
        /// </summary>
        public int? Dist_DisuID { get; set; }

        /// <summary>
        /// 折扣名称
        /// </summary>
        public string Dist_DiscName { get; set; }

        /// <summary>
        /// 代金券编号
        /// </summary>
        public string Dist_DisuNumber { get; set; }

        /// <summary>
        /// 折扣方式（0折扣率，1优惠金额，2满减金额）
        /// </summary>
        public int Dist_Way { get; set; }

        /// <summary>
        /// 折扣方式（0折扣率，1优惠金额，2满减金额）
        /// </summary>
        [NPoco.Ignore]
        public string Dist_Way_Name { get; set; }

        /// <summary>
        /// 原满减金额
        /// </summary>
        public decimal? Dist_FullAmount { get; set; }

        /// <summary>
        /// 原优惠金额
        /// </summary>
        public decimal? Dist_DiscountAmount { get; set; }

        /// <summary>
        /// 同享折扣方式（0折扣率，1优惠金额，2满减金额）
        /// </summary>
        public string Dist_ShareWay { get; set; }

        /// <summary>
        /// 备注
        /// </summary>
        public string Dist_Remark { get; set; }

        public int? Dist_CreatedBy { get; set; }

        public DateTime Dist_CreatedDate { get; set; }

        public int? Dist_UpdatedBy { get; set; }

        public DateTime Dist_UpdatedDate { get; set; }

        public int Dist_Deleted { get; set; }
    }
}
