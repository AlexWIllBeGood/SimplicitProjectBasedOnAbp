﻿using AbcCRM.Common;
using AbcCRM.Domain.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbcCRM.Domain
{
    /// <summary>
    /// 折扣申请使用详情
    /// </summary>
    [NPoco.TableName("DiscountUse")]
    [NPoco.PrimaryKey("Disu_ID", AutoIncrement = true)]
    public class DiscountUseDTO
    {
        /// <summary>
        /// 主键
        /// </summary>
        public int Disu_ID { get; set; }

        /// <summary>
        /// 折扣类型
        /// </summary>
        public int Disu_Discount { get; set; }

        /// <summary>
        /// 关联Lead
        /// </summary>
        public int Disu_LeadID { get; set; }

        /// <summary>
        /// 申请折扣使用中心
        /// </summary>
        public int Disu_Branch { get; set; }

        /// <summary>
        /// 申请原因
        /// </summary>
        public string Disu_Desc { get; set; }

        /// <summary>
        /// 申请中心
        /// </summary>
        [NPoco.Ignore]
        public string Disu_BranchName { get; set; }

        /// <summary>
        /// 关联订单
        /// </summary>
        public int Disu_OrderID { get; set; }

        /// <summary>
        /// 0审核中，1待使用,2使用中，3已使用,4已转赠,-1驳回，-2作废
        /// </summary>
        public int Disu_Status { get; set; }

        /// <summary>
        /// 状态
        /// </summary>
        [NPoco.Ignore]
        public string Disu_Status_Name { get; set; }

        /// <summary>
        /// 优惠折扣
        /// </summary>
        public decimal Disu_Rate { get; set; }

        /// <summary>
        /// 满减金额
        /// </summary>
        public decimal Disu_FullAmount { get; set; }

        /// <summary>
        /// 优惠金额
        /// </summary>
        public decimal Disu_Amount { get; set; }

        /// <summary>
        /// 关联流程ID
        /// </summary>
        public int Disu_WorkflowID { get; set; }

        public int? Disu_CreatedBy { get; set; }

        [NPoco.Ignore]
        public string Disu_CreatedBy_Name { get; set; }

        public DateTime? Disu_CreatedDate { get; set; }

        public int? Disu_UpdatedBy { get; set; }

        [NPoco.Ignore]
        public string Disu_UpdatedBy_Name { get; set; }

        public DateTime? Disu_UpdatedDate { get; set; }

        /// <summary>
        /// 删除标志
        /// </summary>
        public int Disu_Deleted { get; set; }

        /// <summary>
        /// 券号
        /// </summary>
        public string Disu_Number { get; set; }

        /// <summary>
        /// 失效日期
        /// </summary>
        public DateTime? Disu_ExpirationDate { get; set; }

        /// <summary>
        /// 代金券来源订单
        /// </summary>
        public int Disu_FromOrderID { get; set; }

        /// <summary>
        /// 代金券来源规则
        /// </summary>
        public int Disu_FromVoucherID { get; set; }

        /// <summary>
        /// 代金券转赠用户
        /// </summary>
        [NPoco.Ignore]
        public int Disu_ToLeadID { get; set; }

        /// <summary>
        /// 代金券来源（转赠）
        /// </summary>
        public int Disu_FromID { get; set; }

        /// <summary>
        /// 代金券来源券号
        /// </summary>
        [NPoco.Ignore]
        public string Disu_FromNumber { get; set; }

        /// <summary>
        /// 代金券转赠ID
        /// </summary>
        public int Disu_ToID { get; set; }

        /// <summary>
        /// 代金券转赠券号
        /// </summary>
        [NPoco.Ignore]
        public string Disu_ToNumber { get; set; }

        /// <summary>
        /// 应用产品
        /// </summary>
        public string Disu_Products { get; set; }

        [NPoco.Ignore]
        public string ProductName { get; set; }

        [NPoco.Ignore]
        public List<int> ProductList
        {
            get { return string.IsNullOrEmpty(Disu_Products) ? new List<int>() : CommonHelper.JsonDeserialize<List<int>>(Disu_Products); }
            set { Disu_Products = CommonHelper.JsonSerialize(value); }
        }
    }

    /// <summary>
    /// 折扣申请使用详情视图
    /// </summary>
    [NPoco.TableName("VDiscountUse")]
    [NPoco.PrimaryKey("Disu_ID", AutoIncrement = true)]
    public class VDiscountUse : DiscountUseDTO
    {
        /// <summary>
        /// 折扣模式(0时间段，1单次申请，2每年固定，3每月固定，4代金券)
        /// </summary>
        public int Disc_Type { get; set; }

        /// <summary>
        /// 折扣方式（0折扣率，1优惠金额，2满减金额）
        /// </summary>
        public int Disc_Way { get; set; }

        [NPoco.Ignore]
        public string Disc_Way_Name { get; set; }

        /// <summary>
        /// 折扣类型名称
        /// </summary>
        public string Disc_Name { get; set; }

        /// <summary>
        /// 客户姓名
        /// </summary>
        public string Lead_Name { get; set; }

        /// <summary>
        /// 客户手机号
        /// </summary>
        public string Lead_Mobile { get; set; }

        /// <summary>
        /// 订单名称
        /// </summary>
        public string Orde_Number { get; set; }
    }
}
