﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbcCRM.Domain
{
    /// <summary>
    /// 收退款修改记录表
    /// </summary>
    [NPoco.TableName("AccountLog")]
    [NPoco.PrimaryKey("Acrl_ID", AutoIncrement = true)]
    public class AccountLogDTO
    {
        /// <summary>
        /// 主键自增ID
        /// </summary>
        public int Acrl_ID { get; set; }
        /// <summary>
        /// 修改前
        /// </summary>
        public string Acrl_Before { get; set; }
        [NPoco.Ignore]
        public AccountRecordDTO Before { get; set; }
        /// <summary>
        /// 修改后
        /// </summary>
        public string Acrl_After { get; set; }
        [NPoco.Ignore]
        public AccountRecordDTO After { get; set; }
        /// <summary>
        /// 业绩ID
        /// </summary>
        public int Acrl_AccountID { get; set; }

        /// <summary>
        /// 创建人
        /// </summary>
        public int Acrl_CreatedBy { get; set; }
        [NPoco.Ignore]
        public string Acrl_CreatedBy_Name { get; set; }
        /// <summary>
        /// 创建时间
        /// </summary>
        public DateTime Acrl_CreatedDate { get; set; }
    }
}
