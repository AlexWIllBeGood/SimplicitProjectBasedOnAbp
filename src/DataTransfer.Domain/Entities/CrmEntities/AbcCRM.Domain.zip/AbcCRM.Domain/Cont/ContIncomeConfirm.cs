﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbcCRM.Domain
{
    /// <summary>
    /// 合同收入确认表
    /// </summary>
    [NPoco.TableName("ContIncomeConfirm")]
    [NPoco.PrimaryKey("Cic_ID", AutoIncrement = true)]
    public class ContIncomeConfirm
    {
        /// <summary>
        /// 主键自增ID
        /// </summary>
        public int Cic_ID { get; set; }

        /// <summary>
        /// LeadID
        /// </summary>
        public int Cic_LeadID { get; set; }

        /// <summary>
        /// 合同ID
        /// </summary>
        public int Cic_ContID { get; set; }

        /// <summary>
        /// 订单ID
        /// </summary>
        public int Cic_OrderID { get; set; }

        /// <summary>
        /// 关联表ID（根据type判断：2/-1、上课记录 -2、转班记录 -3、退费记录）
        /// </summary>
        public int Cic_RelationID { get; set; }

        /// <summary>
        /// 类型(大于0金额为正)：1、合同买入 2、返销课 -1、销课 -2、转班 -3、退费
        /// </summary>
        public int Cic_Type { get; set; }

        /// <summary>
        /// 类型(大于0金额为正)：1、合同买入 2、返销课 -1、销课 -2、转班 -3、退费
        /// </summary>
        [NPoco.Ignore]
        public string Cic_Type_Name { get; set; }

        /// <summary>
        /// 课时
        /// </summary>
        public int Cic_ClassHour { get; set; }

        /// <summary>
        /// 金额
        /// </summary>
        public decimal Cic_Amount { get; set; }

        /// <summary>
        /// 备注
        /// </summary>
        public string Cic_Remark { get; set; }


        public int Cic_CreatedBy { get; set; }
        [NPoco.Ignore]
        public string Cic_CreatedBy_Name { get; set; }
        public DateTime Cic_CreatedDate { get; set; }
        public int Cic_UpdatedBy { get; set; }
        [NPoco.Ignore]
        public string Cic_UpdatedBy_Name { get; set; }
        public DateTime Cic_UpdatedDate { get; set; }

    }

    /// <summary>
    /// 合同收入确认表视图
    /// </summary>
    [NPoco.TableName("VContIncomeConfirm")]
    public class VContIncomeConfirm : ContIncomeConfirm
    {
        /// <summary>
        /// 学员姓名
        /// </summary>
        public string Lead_Name { get; set; }

        /// <summary>
        /// 合同号
        /// </summary>
        public string Cont_Number { get; set; }

        /// <summary>
        /// 订单号
        /// </summary>
        public string Orde_Number { get; set; }

        /// <summary>
        /// 订单中心
        /// </summary>
        public int Orde_Branch { get; set; }

        /// <summary>
        /// 班级中心
        /// </summary>
        [NPoco.Ignore]
        public string Orde_Branch_Name { get; set; }

        /// <summary>
        /// 班级ID
        /// </summary>
        public int Clas_ID { get; set; }

        /// <summary>
        /// 班号
        /// </summary>
        public string Clas_Code { get; set; }

        /// <summary>
        /// 排课
        /// </summary>
        public int Clsc_ID { get; set; }

        /// <summary>
        /// 期数
        /// </summary>
        public int Clsc_Period { get; set; }

        /// <summary>
        /// 每期序号
        /// </summary>
        public int Clsc_No { get; set; }

        /// <summary>
        /// 星期几
        /// </summary>
        [NPoco.Ignore]
        public string Week { get; set; }

        /// <summary>
        /// 上课日期
        /// </summary>
        public DateTime? Clsc_ClassDate { get; set; }
    }
}
