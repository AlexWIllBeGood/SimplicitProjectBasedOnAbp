﻿using AbcCRM.Common;
using AbcCRM.Domain.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbcCRM.Domain
{
    /// <summary>
    /// 折扣类型
    /// </summary>
    [NPoco.TableName("Discount")]
    [NPoco.PrimaryKey("Disc_DiscId", AutoIncrement = true)]
    public class DiscountDTO
    {
        /// <summary>
        /// 主键ID
        /// </summary>
        public int Disc_DiscId { get; set; }

        /// <summary>
        /// 折扣名称
        /// </summary>
        public string Disc_Name { get; set; }

        /// <summary>
        /// 折扣模式(0时间段，1单次申请，2每年固定，3每月固定，4代金券)
        /// </summary>
        public int Disc_Type { get; set; }

        /// <summary>
        /// 折扣方式（0折扣率，1优惠金额，2满减金额）
        /// </summary>
        public int Disc_Way { get; set; }

        /// <summary>
        /// 开始时间
        /// </summary>
        public DateTime? Disc_StartTime { get; set; }

        /// <summary>
        /// 结束时间
        /// </summary>
        public DateTime? Disc_EndTime { get; set; }

        /// <summary>
        /// 优惠折扣
        /// </summary>
        public decimal Disc_Rate { get; set; }

        /// <summary>
        /// 满减金额
        /// </summary>
        public decimal Disc_FullAmount { get; set; }

        /// <summary>
        /// 优惠金额
        /// </summary>
        public decimal Disc_Amount { get; set; }

        /// <summary>
        /// 置顶数量 产品数量、或者产品类型数
        /// </summary>
        public int Disc_Number { get; set; }

        /// <summary>
        /// 备注
        /// </summary>
        public string Disc_Remark { get; set; }

        /// <summary>
        /// 1、不与其他优惠同享（弃用）
        /// </summary>
        public int Disc_IsAlone { get; set; }

        /// <summary>
        /// 同享折扣方式（0折扣率，1优惠金额，2满减金额）
        /// </summary>
        public string Disc_ShareWay { get; set; }

        [NPoco.Ignore]
        public List<int> ShareWayList
        {
            get { return string.IsNullOrEmpty(Disc_ShareWay) ? new List<int>() : CommonHelper.JsonDeserialize<List<int>>(Disc_ShareWay); }
            set { Disc_ShareWay = CommonHelper.JsonSerialize(value); }
        }

        /// <summary>
        /// 应用中心
        /// </summary>
        public string Disc_Branchs { get; set; }

        [NPoco.Ignore]
        public string BranchName { get; set; }

        [NPoco.Ignore]
        public List<int> BranchList
        {
            get { return string.IsNullOrEmpty(Disc_Branchs) ? new List<int>() : CommonHelper.JsonDeserialize<List<int>>(Disc_Branchs); }
            set { Disc_Branchs = CommonHelper.JsonSerialize(value); }
        }

        public string Disc_Products { get; set; }

        [NPoco.Ignore]
        public string ProductName { get; set; }

        [NPoco.Ignore]
        public List<int> ProductList
        {
            get { return string.IsNullOrEmpty(Disc_Products) ? new List<int>() : CommonHelper.JsonDeserialize<List<int>>(Disc_Products); }
            set { Disc_Products = CommonHelper.JsonSerialize(value); }
        }

        public int Disc_CreatedBy { get; set; }

        public DateTime Disc_CreatedDate { get; set; }

        public int Disc_UpdatedBy { get; set; }

        public DateTime Disc_UpdatedDate { get; set; }

        /// <summary>
        /// 状态 0：启用  1：禁用 
        /// </summary>
        public int Disc_Status { get; set; }

        /// <summary>
        /// 删除标志位
        /// </summary>
        public int Disc_Deleted { get; set; }

        /// <summary>
        /// 折扣申请ID
        /// </summary>
        [NPoco.Ignore]
        public int Disc_ApplyID { get; set; }

        /// <summary>
        /// 代金券编号
        /// </summary>
        [NPoco.Ignore]
        public string Disc_DisuNumber { get; set; }

        /// <summary>
        /// 产品ID
        /// </summary>
        [NPoco.Ignore]
        public List<int> ProIds { get; set; }

        /// <summary>
        /// 产品类型
        /// </summary>
        [NPoco.Ignore]
        public string Disc_ProNames { get; set; }

        /// <summary>
        /// 产品类型名
        /// </summary>
        [NPoco.Ignore]
        public string Disc_ProTypeNames { get; set; }

        /// <summary>
        /// 类型IDS提交的时候使用
        /// </summary>
        [NPoco.Ignore]
        public List<int> ProTypeIds { get; set; }

        [NPoco.Ignore]
        public string Disc_Type_Name { get; set; }

        [NPoco.Ignore]
        public string Disc_Way_Name { get; set; }

        [NPoco.Ignore]
        public string Disc_CreatedBy_Name { get; set; }

        [NPoco.Ignore]
        public string Disc_UpdatedBy_Name { get; set; }

        /// <summary>
        /// 序号，辅助前端选择
        /// </summary>
        [NPoco.Ignore]
        public int Disc_No { get; set; }
    }

    public class DisUsePara
    {
        public int ID { get; set; }
        public string Type { get; set; }
    }
}
