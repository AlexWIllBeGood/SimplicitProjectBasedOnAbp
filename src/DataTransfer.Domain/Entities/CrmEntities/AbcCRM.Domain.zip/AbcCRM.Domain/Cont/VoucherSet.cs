﻿using AbcCRM.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbcCRM.Domain
{
    /// <summary>
    /// 代金券赠送设置
    /// </summary>
    [NPoco.TableName("VoucherSet")]
    [NPoco.PrimaryKey("Vous_ID", AutoIncrement = true)]
    public class VoucherSet
    {
        /// <summary>
        /// 主键ID
        /// </summary>
        public int Vous_ID { get; set; }

        /// <summary>
        /// 名称
        /// </summary>
        public string Vous_Name { get; set; }

        /// <summary>
        /// 开始赠送时间
        /// </summary>
        public DateTime? Vous_StartTime { get; set; }

        /// <summary>
        /// 结束赠送时间
        /// </summary>
        public DateTime? Vous_EndTime { get; set; }

        /// <summary>
        /// 赠送类型（0常规，1老带新）
        /// </summary>
        public int Vous_Type { get; set; }

        /// <summary>
        /// 赠送类型
        /// </summary>
        [NPoco.Ignore]
        public string Vous_Type_Name { get; set; }

        /// <summary>
        /// 赠送方式（0满，1每满）
        /// </summary>
        public int Vous_Way { get; set; }

        /// <summary>
        /// 赠送方式
        /// </summary>
        [NPoco.Ignore]
        public string Vous_Way_Name { get; set; }

        /// <summary>
        /// 满减金额
        /// </summary>
        public decimal Vous_FullAmount { get; set; }

        /// <summary>
        /// 赠送代金券类型
        /// </summary>
        public int Vous_Discount { get; set; }

        /// <summary>
        /// 赠送代金券类型
        /// </summary>
        [NPoco.Ignore]
        public string Vous_DiscountName { get; set; }

        /// <summary>
        /// 有效期（天）
        /// </summary>
        public int Vous_ValidityDay { get; set; }

        /// <summary>
        /// 备注
        /// </summary>
        public string Vous_Remark { get; set; }

        /// <summary>
        /// 状态 0：启用  1：禁用 
        /// </summary>
        public int Vous_Status { get; set; }

        /// <summary>
        /// 应用中心
        /// </summary>
        public string Vous_Branchs { get; set; }

        [NPoco.Ignore]
        public string BranchName { get; set; }

        [NPoco.Ignore]
        public List<int> BranchList
        {
            get { return string.IsNullOrEmpty(Vous_Branchs) ? new List<int>() : CommonHelper.JsonDeserialize<List<int>>(Vous_Branchs); }
            set { Vous_Branchs = CommonHelper.JsonSerialize(value); }
        }

        public string Vous_Products { get; set; }

        [NPoco.Ignore]
        public string ProductName { get; set; }

        [NPoco.Ignore]
        public List<int> ProductList
        {
            get { return string.IsNullOrEmpty(Vous_Products) ? new List<int>() : CommonHelper.JsonDeserialize<List<int>>(Vous_Products); }
            set { Vous_Products = CommonHelper.JsonSerialize(value); }
        }

        public int Vous_CreatedBy { get; set; }

        [NPoco.Ignore]
        public string Vous_CreatedBy_Name { get; set; }

        public DateTime Vous_CreatedDate { get; set; }

        public int Vous_UpdatedBy { get; set; }

        [NPoco.Ignore]
        public string Vous_UpdatedBy_Name { get; set; }

        public DateTime Vous_UpdatedDate { get; set; }

        public int Vous_Deleted { get; set; }
    }


    /// <summary>
    /// 代金券编号
    /// </summary>
    [NPoco.TableName("VoucherNo")]
    [NPoco.PrimaryKey("Voun_No", AutoIncrement = true)]
    public class VoucherNo
    {
        /// <summary>
        /// 主键ID
        /// </summary>
        public int Voun_No { get; set; }
    }
}
