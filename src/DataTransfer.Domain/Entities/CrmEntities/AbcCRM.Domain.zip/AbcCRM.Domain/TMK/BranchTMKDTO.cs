﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbcCRM.Domain
{
    /// <summary>
    /// TMK区域中心管理
    /// </summary>
    [NPoco.TableName("Basis_Branch_TMK")]
    [NPoco.PrimaryKey("Bran_ID", AutoIncrement = false)]
    public class BranchTMKDTO
    {
        /// <summary>
        /// 主键ID
        /// </summary>
        public int Bran_ID { get; set; }

        /// <summary>
        /// 父级
        /// </summary>
        public int? Bran_ParentID { get; set; }

        /// <summary>
        /// 区域编码
        /// </summary>
        public string Bran_Code { get; set; }

        /// <summary>
        /// 区域名称
        /// </summary>
        public string Bran_Name { get; set; }

        /// <summary>
        /// 类型（预留）
        /// </summary>
        public int Bran_Type { get; set; }

        /// <summary>
        /// 深度
        /// </summary>
        public int Bran_Depth { get; set; }

        /// <summary>
        /// 创建人
        /// </summary>
        public int? Bran_CreatedBy { get; set; }

        /// <summary>
        /// 创建时间
        /// </summary>
        public DateTime? Bran_CreatedDate { get; set; }

        /// <summary>
        /// 更新人
        /// </summary>
        public int? Bran_UpdatedBy { get; set; }

        /// <summary>
        /// 更新时间
        /// </summary>
        public DateTime? Bran_UpdatedDate { get; set; }

        /// <summary>
        /// 删除标志
        /// </summary>
        public int Bran_Deleted { get; set; }
    }
}
