﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbcCRM.Domain
{
    /// <summary>
    /// TMK组员管理
    /// </summary>
    [NPoco.TableName("Basis_Branch_TMKUser")]
    [NPoco.PrimaryKey("TmkU_ID", AutoIncrement = true)]
    public class BranchTMKUserDTO
    {
        /// <summary>
        /// 主键ID
        /// </summary>
        public int TmkU_ID { get; set; }

        /// <summary>
        /// TMK中心ID
        /// </summary>
        public int TmkU_TmkID { get; set; }

        /// <summary>
        /// TMK中心名称
        /// </summary>
        [NPoco.Ignore]
        public string TmkU_TmkName { get; set; }

        /// <summary>
        /// 用户ID
        /// </summary>
        public int TmkU_UserID { get; set; }

        /// <summary>
        /// 用户中文名
        /// </summary>
        [NPoco.Ignore]
        public string TmkU_UserName { get; set; }

        /// <summary>
        /// 组长标识
        /// </summary>
        public int TmkU_IsLeader { get; set; }

        public int? TmkU_CreatedBy { get; set; }

        public DateTime? TmkU_CreatedDate { get; set; }

        public int? TmkU_UpdatedBy { get; set; }

        public DateTime? TmkU_UpdatedDate { get; set; }      

        public int TmkU_Deleted { get; set; }
    }
}
