﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbcCRM.Domain.Leads
{
    /// <summary>
    /// tmk跟进记录表
    /// </summary>
    [NPoco.TableName("Tmk_Follow_Log")]
    [NPoco.PrimaryKey("Tmfl_ID", AutoIncrement = true)]
    public class Tmk_Follow_LogDTO
    {
        #region 属性
        /// <summary>
        /// 主键
        /// </summary>
        public int Tmfl_ID { get; set; }

        /// <summary>
        /// 关联的Lead
        /// </summary>
        public int? Tmfl_LeadID { get; set; }

        /// <summary>
        /// 电话结果（1已接通，2未接通）
        /// </summary>
        public int? Tmfl_CallResult { get; set; }

        /// <summary>
        /// 预约到访时间
        /// </summary>
        public DateTime? Tmfl_Lead_BookingDate { get; set; }

        /// <summary>
        /// 下次跟进时间
        /// </summary>
        public DateTime? Tmfl_NextFollow { get; set; }

        /// <summary>
        /// 沟通内容
        /// </summary>
        public string Tmfl_Info { get; set; }

        /// <summary>
        /// 当前TMK
        /// </summary>
        public int? Tmfl_Tmk { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public int? Tmfl_CreatedBy { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public DateTime? Tmfl_CreatedDate { get; set; }
        #endregion 

        [NPoco.Ignore]
        public string UserAvatar { get; set; }

        [NPoco.Ignore]
        public string Tmfl_CreatedBy_Name { get; set; }

        [NPoco.Ignore]
        public string Roles { get; set; }

        /// <summary>
        /// 电话结果
        /// </summary>
        [NPoco.Ignore]
        public string Tmfl_CallResult_Name { get; set; }
    }
}
