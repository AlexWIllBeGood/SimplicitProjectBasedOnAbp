﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbcCRM.Domain.Leads
{
    /// <summary>
    /// TMK分配记录
    /// </summary>
    [NPoco.TableName("Tmk_Dis_Log")]
    [NPoco.PrimaryKey("Tmdl_ID", AutoIncrement = true)]
    public class TmkDisLogDTO
    {
        #region 
        /// <summary>
        /// 主键
        /// </summary>
        public int Tmdl_ID { get; set; }

        /// <summary>
        /// LeadID关联的Lead
        /// </summary>
        public int? Tmdl_LeadID { get; set; }

        /// <summary>
        /// 类型字典（1新单，2分配，3回收，4放弃）
        /// </summary>
        public int? Tmdl_Type { get; set; }

        /// <summary>
        /// BranchID
        /// </summary>
        public int? Tmdl_BranID { get; set; }

        /// <summary>
        /// tmk用户ID
        /// </summary>
        public int? Tmdl_TMK { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public int? Tmdl_CreatedBy { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public DateTime? Tmdl_CreatedDate { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public int? Tmdl_Deleted { get; set; }

        #endregion

        [NPoco.Ignore]
        public string Disl_TypeName { get; set; }

        [NPoco.Ignore]
        public string Disl_TMKName { get; set; }

        [NPoco.Ignore]
        public string Disl_CreatedByName { get; set; }

        [NPoco.Ignore]
        public string Disl_BranName { get; set; }
    }

}
