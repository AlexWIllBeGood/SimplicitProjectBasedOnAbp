﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbcCRM.Domain
{
    /// <summary>
    /// 待分配页面统计实体
    /// </summary>
    public class DistLeadCount_TMK
    {
        /// <summary>
        /// 用户名
        /// </summary>
        public string UserName { get; set; }

        /// <summary>
        /// 合计
        /// </summary>
        public int LeadNum { get; set; }

        /// <summary>
        /// 新单数
        /// </summary>
        public int NewNum { get; set; }

        /// <summary>
        /// 跟进中数
        /// </summary>
        public int FollowNum { get; set; }

        /// <summary>
        /// 无效数
        /// </summary>
        public int InvalidNum { get; set; }

        /// <summary>
        /// 待跟进数
        /// </summary>
        public int StayFollowNum { get; set; }

        /// <summary>
        /// 已预约数
        /// </summary>
        public int AppNum { get; set; }

        /// <summary>
        /// 中心
        /// </summary>
        public int BranID { get; set; }

    }

    public class AllLeadCount
    {
        /// <summary>
        /// 待分配总数
        /// </summary>
        public int StayDistNum { get; set; }

        public List<DistLeadCount_TMK> DistLeadCounts { get; set; }
    }
}
