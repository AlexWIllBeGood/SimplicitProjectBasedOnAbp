﻿using System;
using System.Collections.Generic;

namespace AbcCRM.Domain
{
    /// <summary>
    /// 电子合同模板配置
    /// </summary>
    [NPoco.TableName("EContractTemplate")]
    [NPoco.PrimaryKey("Ctem_ID", AutoIncrement = true)]
    public class EContractTemplate
    {
        /// <summary>
        /// 自增ID
        /// </summary>
        public int Ctem_ID { get; set; }

        ///// <summary>
        ///// 产线
        ///// </summary>
        //public int Ctem_ProductType { get; set; }

        //[NPoco.Ignore]
        //public string Ctem_ProductType_Name { get; set; }

        /// <summary>
        /// 模板名称
        /// </summary>
        public string Ctem_Name { get; set; }

        /// <summary>
        /// 签名配置（json）
        /// </summary>
        public string Ctem_ECTemp { get; set; }

        /// <summary>
        /// 签名配置
        /// </summary>
        [NPoco.Ignore]
        public EContTempSetting ECTemps { get; set; }

        public int? Ctem_CreatedBy { get; set; }

        [NPoco.Ignore]
        public string Ctem_CreatedBy_Name { get; set; }

        public DateTime? Ctem_CreatedDate { get; set; }

        public int? Ctem_UpdatedBy { get; set; }

        [NPoco.Ignore]
        public string Ctem_UpdatedBy_Name { get; set; }

        public DateTime? Ctem_UpdatedDate { get; set; }

        public int Ctem_Deleted { get; set; }

    }

    /// <summary>
    /// 签名配置
    /// </summary>
    public class EContTempSetting
    {
        public EContTemp New { get; set; }

        public EContTemp Renewal { get; set; }

        public EContTemp Convert { get; set; }
    }

    /// <summary>
    /// 签名配置
    /// </summary>
    public class EContTemp
    {
        /// <summary>
        /// 模板路径
        /// </summary>
        public string Ctem_Path { get; set; }

        /// <summary>
        /// 指定签署人列表
        /// </summary>
        public List<ECSignSeal> Ctem_Signs { get; set; }

        /// <summary>
        /// 指定公章列表 区域章、产线章
        /// </summary>
        public List<ECSignSeal> Ctem_Seals { get; set; }
    }

    /// <summary>
    /// 签署账号
    /// </summary>
    public class ECSignSeal
    {
        /// <summary>
        /// 签署人类型 1 CC课程顾问，2 客户，3 代理人（监护人），4 SAC留学顾问
        /// </summary>
        public int SignType { get; set; }

        /// <summary>
        /// 公章类型 1 区域/中心公章， 2 总部公章
        /// </summary>
        public int SealType { get; set; }

        //[NPoco.Ignore]
        //public string SignType_Name { get; set; }

        //[NPoco.Ignore]
        //public string SealType_Name { get; set; }

        /// <summary>
        /// 位置
        /// </summary>
        public List<ECSignPostion> Position { get; set; }

        /// <summary>
        /// 签署方式 (1 自动，2 手动)
        /// </summary>
        public int SignWay { get; set; }
    }
}
