﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbcCRM.Domain
{
    /// <summary>
    /// CA证书
    /// </summary>
    [NPoco.TableName("EContractCa")]
    [NPoco.PrimaryKey("Ceca_ID", AutoIncrement = true)]
    public class EContractCa
    {
        /// <summary>
        /// 主键ID
        /// </summary>
        public int Ceca_ID { get; set; }

        /// <summary>
        /// 证书类型：1、主体 2、CC  3、学员 4、监护人 
        /// </summary>
        public int Ceca_Type { get; set; }

        /// <summary>
        /// 证书类型
        /// </summary>
        [NPoco.Ignore]
        public string Ceca_Type_Name { get; set; }

        /// <summary>
        /// 用户账号
        /// 用户的唯一标识
        /// ABC_+OrgID,ABC_User+UserID,ABC_Lead+LeadID,ABC_Agent+AgentID
        /// </summary>
        public string Ceca_Account { get; set; }

        /// <summary>
        /// CA证书
        /// </summary>
        public string Ceca_CA { get; set; }

        /// <summary>
        /// 用户姓名
        /// 必须和证件上登记的姓名一致
        /// </summary>
        public string Ceca_Name { get; set; }

        /// <summary>
        /// 邮箱
        /// </summary>
        public string Ceca_Email { get; set; }

        /// <summary>
        /// 手机号
        /// </summary>
        public string Ceca_Mobile { get; set; }

        /// <summary>
        /// 证件类型
        /// </summary>
        public string Ceca_IDType { get; set; }

        /// <summary>
        /// 证件类型
        /// </summary>
        [NPoco.Ignore]
        public string Ceca_IDType_Name { get; set; }

        /// <summary>
        /// 证件号码
        /// </summary>
        public string Ceca_IDNum { get; set; }

        /// <summary>
        /// 关联表ID
        /// </summary>
        public int Ceca_RelationId { get; set; }

        /// <summary>
        /// 证书状态：1、申请中 2、申请成功 3、申请失败
        /// </summary>
        public int? Ceca_Status { get; set; }

        /// <summary>
        /// 证书状态
        /// </summary>
        [NPoco.Ignore]
        public string Ceca_Status_Name { get; set; }

        public int Ceca_Createdby { get; set; }
        [NPoco.Ignore]
        public string Ceca_Createdby_Name { get; set; }
        public DateTime? Ceca_CreatedDate { get; set; }
        public int Ceca_Updatedby { get; set; }
        [NPoco.Ignore]
        public string Ceca_Updatedby_Name { get; set; }
        public DateTime? Ceca_UpdatedDate { get; set; }
        public int Ceca_Deleted { get; set; }
    }

    /// <summary>
    /// CA申请记录
    /// </summary>
    [NPoco.TableName("EContractCaLog")]
    [NPoco.PrimaryKey("CLog_ID", AutoIncrement = true)]
    public class EContractCaLog
    {
        /// <summary>
        /// 主键ID
        /// </summary>
        public int CLog_ID { get; set; }

        /// <summary>
        /// CA证书ID
        /// </summary>
        public int CLog_CAID { get; set; }

        public int CLog_Res { get; set; }
        public string CLog_Request { get; set; }
        public string CLog_Response { get; set; }
        public DateTime CLog_CreatedDate { get; set; }
    }
}
