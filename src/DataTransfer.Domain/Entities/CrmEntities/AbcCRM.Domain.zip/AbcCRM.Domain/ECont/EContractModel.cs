﻿using AbcCRM.Common;
using System;
using System.Collections.Generic;

namespace AbcCRM.Domain
{
    /// <summary>
    /// 电子合同
    /// </summary>
    [NPoco.TableName("EContract")]
    public class EContractModel: EContractBase
    {
        /// <summary>
        /// 合同Id
        /// </summary>
        public int Econ_ContarctID { get; set; }

        /// <summary>
        /// 订单ID
        /// </summary>
        public int Econ_OrderID { get; set; }
    }

    /// <summary>
    /// 电子协议
    /// </summary>
    [NPoco.TableName("EAgreement")]
    public class EAgreement : EContractBase
    {
        /// <summary>
        /// 学员姓名
        /// </summary>
        public string Econ_LeadName { get; set; }

        /// <summary>
        /// 监护人姓名
        /// </summary>
        public string Econ_AgentName { get; set; }

        /// <summary>
        /// 联系电话
        /// </summary>
        public string Econ_Mobile { get; set; }

        /// <summary>
        /// 班号
        /// </summary>
        public string Econ_ClassCode { get; set; }

        /// <summary>
        /// 课时
        /// </summary>
        public string Econ_ClassHour { get; set; }

        /// <summary>
        /// 主体ID
        /// </summary>
        public int Econ_OrgCodeID { get; set; }

        /// <summary>
        /// 主体名称
        /// </summary>
        public string Econ_OrgCodeName { get; set; }
    }

    /// <summary>
    /// 电子合同/电子协议基类
    /// </summary>
    [NPoco.PrimaryKey("Econ_ID", AutoIncrement = true)]
    public class EContractBase
    {
        /// <summary>
        /// LeadID
        /// </summary>
        public int Econ_LeadID { get; set; }

        /// <summary>
        /// Lead手机号
        /// </summary>
        [NPoco.Ignore]
        public string Econ_LeadMobile { get; set; }

        /// <summary>
        /// Lead邮箱
        /// </summary>
        [NPoco.Ignore]
        public string Econ_LeadEmail { get; set; }

        /// <summary>
        /// 签署监护人ID
        /// </summary>
        public int Econ_AgentID { get; set; }

        /// <summary>
        /// 签署人证件类型
        /// </summary>
        [NPoco.Ignore]
        public string Econ_SignUserIDType { get; set; }

        /// <summary>
        /// 签署人证件号码
        /// </summary>
        [NPoco.Ignore]
        public string Econ_SignUserIDCard { get; set; }

        /// <summary>
        /// 签署用户ID
        /// </summary>
        public int Econ_UserID { get; set; }

        /// <summary>
        /// 电子合同Id
        /// </summary>
        public int Econ_ID { get; set; }

        /// <summary>
        /// 电子合同号
        /// </summary>
        public string Econ_ContractNumber { get; set; }

        /// <summary>
        /// 所属中心
        /// </summary>
        public int Econ_Branch { get; set; }

        /// <summary>
        /// 所属中心
        /// </summary>
        [NPoco.Ignore]
        public string Econ_Branch_Name { get; set; }

        /// <summary>
        /// 电子合同签名id
        /// </summary>
        public string Econ_FsdID { get; set; }

        /// <summary>
        /// 电子合同文档id
        /// </summary>
        public string Econ_DocID { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string Econ_Sxdays { get; set; }

        /// <summary>
        /// 签名人数
        /// </summary>
        public int Econ_SignNum { get; set; }

        /// <summary>
        /// 待签名人数
        /// </summary>
        public int Econ_WaitNum { get; set; }

        /// <summary>
        /// 电子合同上上签创建时间
        /// </summary>
        public DateTime? Econ_SendTime { get; set; }

        /// <summary>
        /// 电子合同归档时间
        /// </summary>
        public DateTime? Econ_DoneTime { get; set; }

        /// <summary>
        /// 电子合同状态 0、未完成 1、已完成 2、已归档 3、已失效
        /// </summary>
        public int Econ_Status { get; set; }

        /// <summary>
        /// 电子合同状态 0、未完成 1、已完成 2、已归档 3、已失效
        /// </summary>
        [NPoco.Ignore]
        public string Econ_Status_Name { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string Econ_SignList { get; set; }

        /// <summary>
        /// 签名人
        /// </summary>
        public string Econ_UserList { get; set; }

        /// <summary>
        /// 电子合同文件路径
        /// </summary>
        public string Econ_FilePath { get; set; }

        /// <summary>
        /// 电子合同文件名
        /// </summary>
        public string Econ_FileName { get; set; }

        /// <summary>
        /// 待签名的PDF文档
        /// </summary>
        public string Econ_PdfPath { get; set; }

        /// <summary>
        /// PDF总页数
        /// </summary>
        public int Econ_PageNum { get; set; }

        /// <summary>
        /// 签名列表
        /// </summary>
        public string Econ_SignUsers { get; set; }

        /// <summary>
        /// 签定人
        /// </summary>
        public List<ECSignUser> SignUsers
        {
            get { return string.IsNullOrEmpty(Econ_SignUsers) ? new List<ECSignUser>() : CommonHelper.JsonDeserialize<List<ECSignUser>>(Econ_SignUsers); }
            set { Econ_SignUsers = CommonHelper.JsonSerialize(value); }
        }

        /// <summary>
        /// 当前签定人
        /// </summary>
        [NPoco.Ignore]
        public ECSignUser SignUser { get; set; }

        public DateTime Econ_CreatedDate { get; set; }

        public int? Econ_CreatedBy { get; set; }

        public DateTime Econ_UpdatedDate { get; set; }

        public int? Econ_UpdatedBy { get; set; }

        public int Econ_Deleted { get; set; }

        [NPoco.Ignore]
        public string Econ_CreatedBy_Name { get; set; }

        [NPoco.Ignore]
        public string Econ_UpdatedBy_Name { get; set; }
    }
}
