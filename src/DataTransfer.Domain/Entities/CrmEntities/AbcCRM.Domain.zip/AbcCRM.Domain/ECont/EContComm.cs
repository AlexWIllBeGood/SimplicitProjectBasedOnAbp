﻿using System.Collections.Generic;

namespace AbcCRM.Domain
{
    /// <summary>
    /// 创建电子合同请求参数
    /// </summary>
    public class CreateEContPara
    {
        /// <summary>
        /// 合同ID
        /// </summary>
        public int ContractId { get; set; }

        /// <summary>
        /// 合同号
        /// </summary>
        public string ContractNumber { get; set; }

        /// <summary>
        /// 合同页数
        /// </summary>
        public int Page { get; set; }

        /// <summary>
        /// 合同路径
        /// </summary>
        public string Path { get; set; }

        /// <summary>
        /// 签署人
        /// </summary>
        public List<ECSignSeal> Signs { get; set; }
    }

    /// <summary>
    /// 发起电子合同参数
    /// </summary>
    public class ECSendPara
    {
        /// <summary>
        /// 电子协议
        /// </summary>
        public EAgreement agreement { get; set; }

        /// <summary>
        /// 主体ID
        /// </summary>
        public int OrgCodeID { get; set; }

        /// <summary>
        /// 合同ID
        /// </summary>
        public int ContID { get; set; }

        /// <summary>
        /// 合同号
        /// </summary>
        public string ContNumber { get; set; }

        /// <summary>
        /// 订单ID
        /// </summary>
        public int OrderID { get; set; }

        /// <summary>
        /// 订单号
        /// </summary>
        public string OrderNumber { get; set; }

        /// <summary>
        /// 页数
        /// </summary>
        public int Page { get; set; }

        /// <summary>
        /// 路径
        /// </summary>
        public string Path { get; set; }

        /// <summary>
        /// 请求类型 1、PC端 2、手机端
        /// </summary>
        public int type { get; set; }

        /// <summary>
        /// 签署对象
        /// </summary>
        public List<ECSignUser> SignUsers { get; set; }
    }

    /// <summary>
    /// 手动签名参数
    /// </summary>
    public class ContSignPara
    {
        /// <summary>
        /// 电子合同id
        /// </summary>
        public int id { get; set; }

        /// <summary>
        /// leadID
        /// </summary>
        public int leadID { get; set; }

        /// <summary>
        /// 电子合同文档id
        /// </summary>
        public string docID { get; set; }

        /// <summary>
        /// 合同Id
        /// </summary>
        public int contID { get; set; }

        /// <summary>
        /// 订单ID
        /// </summary>
        public int orderID { get; set; }

        public string key { get; set; }

        /// <summary>
        /// 请求类型 1、PC端 2、手机端
        /// </summary>
        public int type { get; set; }

        /// <summary>
        /// 签署人
        /// </summary>
        public ECSignUser SignUser { get; set; }

        /// <summary>
        /// 跳转地址
        /// </summary>
        public string ReturnUrl { get; set; }

        /// <summary>
        /// 通知地址
        /// </summary>
        public string PushUrl { get; set; }
    }

    /// <summary>
    /// 签署人
    /// </summary>
    public class ECSignUser
    {
        /// <summary>
        /// 签署人账号
        /// </summary>
        public string Account { get; set; }

        /// <summary>
        /// 接收验证码手机号
        /// </summary>
        public string Mobile { get; set; }

        /// <summary>
        /// 签名位置
        /// </summary>
        public List<ECSignPostion> SignPostion { get; set; }

        /// <summary>
        /// 签署人类型 1：CC 2：客户(包含监护人) 3：公章
        /// </summary>
        public int SignType { get; set; }

        /// <summary>
        /// 签名方式 (1 自动，2 手动)
        /// </summary>
        public int SignWay { get; set; }

        /// <summary>
        /// 签名状态 （0 未完成，1 已完成）
        /// </summary>
        public int SignStatus { get; set; }

        public string SignName { get; set; }

        public string SignDate { get; set; }
    }

    /// <summary>
    /// 位置
    /// </summary>
    public class ECSignPostion
    {
        /// <summary>
        /// 页码
        /// </summary>
        public int? PageNum { get; set; }

        /// <summary>
        /// X轴
        /// </summary>
        public string X { get; set; }

        /// <summary>
        /// Y轴
        /// </summary>
        public string Y { get; set; }
    }

    /// <summary>
    /// 签署合同状态回调
    /// </summary>
    public class ReceiveCont
    {
        /// <summary>
        /// 上上签合同ID
        /// </summary>
        public string contractId { get; set; }

        /// <summary>
        /// 签署人
        /// </summary>
        public string account { get; set; }

        /// <summary>
        /// 签署状态 1：正在进行中；2：已完成；3：已拒绝并取消；
        /// </summary>
        public int signerStatus { get; set; }
    }

    /// <summary>
    /// 申请证书结果回调
    /// </summary>
    public class ReceiveCA
    {
        public string certType { get; set; }

        /// <summary>
        /// 证书编号
        /// </summary>
        public string cert { get; set; }

        public string message { get; set; }

        /// <summary>
        /// 申请证书的账号
        /// </summary>
        public string account { get; set; }

        /// <summary>
        /// 异步申请队列的序号
        /// </summary>
        public string taskId { get; set; }

        /// <summary>
        /// 状态 5
        /// </summary>
        public string status { get; set; }
    }
}
