﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//namespace AbcCRM.Domain
//{
//    public class SaveContProModel
//    {
//        public int contid { get; set; }
//        public int proclastype { get; set; }
//        public int userid { get; set; }
//    }
//}
