﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbcCRM.Domain
{
    /// <summary>
    /// 统一邮件
    /// </summary>
    [NPoco.TableName("EmailLog")]
    [NPoco.PrimaryKey("emai_emailid", AutoIncrement = true)]
    public class MailDTO
    {
        public int emai_emailid { get; set; }

        /// <summary>
        /// 收件人
        /// </summary>
        public string emai_emailName { get; set; }

        /// <summary>
        /// 收件邮箱
        /// </summary>
        public string emai_emailAddress { get; set; }

        /// <summary>
        /// 邮件状态
        /// </summary>
        public int emai_emailStatus { get; set; }

        [NPoco.Ignore]
        public string emai_emailStatus_Name { get; set; }

        /// <summary>
        /// 创建时间
        /// </summary>
        public DateTime? emai_CreatedDate { get; set; }

        /// <summary>
        /// 创建人
        /// </summary>
        public int emai_CreatedBy { get; set; }

        [NPoco.Ignore]
        public string emai_CreatedBy_Name { get; set; }

        /// <summary>
        /// 邮件类型 ec 电子合同，ea 电子协议 receipt 电子收据
        /// </summary>
        public string emai_Type { get; set; }

        /// <summary>
        /// 关联ID
        /// </summary>
        public int? emai_TID { get; set; }

        /// <summary>
        /// 邮件标题
        /// </summary>
        public string emai_Title { get; set; }

        /// <summary>
        /// 邮件内容
        /// </summary>
        public string emai_Content { get; set; }

        /// <summary>
        /// 邮件附件
        /// </summary>
        public string emai_File { get; set; }

        /// <summary>
        /// 附件类型
        /// </summary>
        public string emai_FileType { get; set; }

        /// <summary>
        /// 附件名称
        /// </summary>
        public string emai_FileName { get; set; }

        /// <summary>
        /// 发件人
        /// </summary>
        public string emai_Sender { get; set; }

        /// <summary>
        /// 错误消息
        /// </summary>
        public string Emai_Remark { get; set; }
    }


    public class MailShow<T>
    {
        public T Data { get; set; }

        public string Email { get; set; }

        public string UserName { get; set; }

       public string EmailType { get; set; }
    }
}
