﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbcCRM.Domain
{
    /// <summary>
    /// 报表权限
    /// </summary>
    [NPoco.TableName("ReportPerm")]
    [NPoco.PrimaryKey("Rper_ID", AutoIncrement = true)]
    public class ReportPermDTO
    {
        /// <summary>
        /// 自增ID
        /// </summary>
        public int Rper_ID { get; set; }

        /// <summary>
        /// 报表ID
        /// </summary>
        public int Rper_ReportID { get; set; }

        /// <summary>
        /// 角色ID
        /// </summary>
        public int Rper_RoleID { get; set; }

        /// <summary>
        /// 区域ID
        /// </summary>
        public int Rper_Branch { get; set; }

        /// <summary>
        /// 0正常 1删除
        /// </summary>
        public int Rper_Deleted { get; set; }

        /// <summary>
        /// 创建人
        /// </summary>
        public int? Rper_CreatedBy { get; set; }

        /// <summary>
        /// 创建时间
        /// </summary>
        public DateTime? Rper_CreatedDate { get; set; }

        /// <summary>
        /// 更新人
        /// </summary>
        public int? Rper_UpdatedBy { get; set; }

        /// <summary>
        /// 更新时间
        /// </summary>
        public DateTime? Rper_UpdatedDate { get; set; }
    }

}
