﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//namespace AbcCRM.Domain
//{
//    [NPoco.TableName("t_crm_sms")]
//    [NPoco.PrimaryKey("tcms_msgid", AutoIncrement = true)]
//    public class SMSDTO
//    {
//        public int Tcms_ID { get; set; }
//        public int Tcms_Type { get; set; }
//        public string Tcms_Mobile { get; set; }
//        public string Tcms_Msg { get; set; }
//        public int Tcms_VCode { get; set; }
//        public string Tcms_Reply { get; set; }
//        public int? Tcms_CreatedBy { get; set; }
//        public DateTime? Tcms_CreatedDate { get; set; }
//        public int? Tcms_UpdatedBy { get; set; }
//        public DateTime? Tcms_UpdatedDate { get; set; }
//        public int Tcms_Status { get; set; }

//        [NPoco.Ignore]
//        public string Tcms_Status_Name { get; set; }

//        [NPoco.Ignore]
//        public string Tcms_CreatedBy_Name { get; set; }

//        [NPoco.Ignore]
//        public bool CanSent { get; set; }

//        [NPoco.Ignore]
//        public string Tcms_Mobile_Name { get; set; }
//    }
//}
