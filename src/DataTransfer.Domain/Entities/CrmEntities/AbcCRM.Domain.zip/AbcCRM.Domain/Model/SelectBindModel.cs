﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbcCRM.Domain
{
    /// <summary>
    /// 下拉框绑定实体
    /// </summary>
    public class SelectBindModel
    {
        /// <summary>
        /// 值
        /// </summary>
        public int ID { get; set; }

        /// <summary>
        /// 显示
        /// </summary>
        public string Text { get; set; }

    }
}
