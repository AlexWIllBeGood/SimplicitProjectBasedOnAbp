﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//namespace AbcCRM.Domain
//{
//    /// <summary>
//    /// 合同课时转移记录表 （）
//    /// </summary>
//    [NPoco.TableName("TranContClassHourLog")]
//    [NPoco.PrimaryKey("Tcch_Id", AutoIncrement = true)]
//    public class TranContClassHourLog
//    {
//        public int Tcch_Id { get; set; }

//        /// <summary>
//        /// 0转出1转入
//        /// </summary>
//        public int Tcch_Type { get; set; }

//        /// <summary>
//        /// 当前合同Id
//        /// </summary>
//        public int Tcch_CurContId { get; set; }
//        /// <summary>
//        /// 当前班级Id
//        /// </summary>
//        public int Tcch_CurClassId { get; set; }

//        /// <summary>
//        /// 当前班级Id
//        /// </summary>
//        [NPoco.Ignore]
//        public string Tcch_CurClassName { get; set; }
//        /// <summary>
//        /// 目标合同Id
//        /// </summary>
//        public int Tcch_OtherContId { get; set; }
//        /// <summary>
//        /// 目标班级Id
//        /// </summary>
//        public int Tcch_OtherClassId { get; set; }

//        /// <summary>
//        /// 对方课程名
//        /// </summary>
//        [NPoco.Ignore]
//        public string Tcch_OtherClassName { get; set; }
//        /// <summary>
//        /// 
//        /// </summary>
//        public int Tcch_ClassHour { get; set; }

//        [NPoco.Ignore]
//        public string Tcch_CreatedName { get; set; }
//        public int Tcch_CreatedBy { get; set; }
//        public DateTime Tcch_CreatedDate { get; set; }
//        public int Tcch_UpdatedBy { get; set; }
//        public DateTime Tcch_UpdatedDate { get; set; }
//        public int Tcch_Deleted { get; set; }


//        [NPoco.Ignore]
//        public string ContNumber { get; set; }
//    }
//}
