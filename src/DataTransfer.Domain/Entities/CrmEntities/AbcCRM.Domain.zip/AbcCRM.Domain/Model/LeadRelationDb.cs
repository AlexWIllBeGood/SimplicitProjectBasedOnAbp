﻿//using System;

//namespace AbcCRM.Domain
//{
//    /// <summary>
//    /// lead家庭关系表
//    /// </summary>
//    [NPoco.TableName("LeadRelation")]
//    [NPoco.PrimaryKey("leadrel_LeadRelId", AutoIncrement = true)]
//    public class LeadRelationDb
//    {
//        /// <summary>
//        /// 主键id
//        /// </summary>
//        public int leadrel_LeadRelId { get; set; }

//        //public int Leadrel_ID { get; set; }

//        /// <summary>
//        /// leadid
//        /// </summary>
//        public int leadrel_LeadId { get; set; }

//        /// <summary>
//        /// 引用id
//        /// </summary>
//        public int leadrel_RefLeadId { get; set; }
//        /// <summary>
//        /// 引用id
//        /// 0：姐姐
//        /// 1：妹妹
//        /// 2：哥哥
//        /// 3：弟弟
//        /// 4：表兄弟
//        /// 5：表姊妹
//        /// 6：堂兄弟
//        /// 7：堂姊妹
//        /// 8：爸爸
//        /// 9：妈妈
//        /// 10：爷爷
//        /// 11：奶奶
//        /// 12：叔叔
//        /// 13：阿姨
//        /// 14：伯父
//        /// 15：伯母
//        /// </summary>
//        public int? leadrel_RelaId { get; set; }

//        /// <summary>
//        /// 关系描述
//        /// </summary>
//        public string leadrel_RelaDesc { get; set; }

//        public int leadrel_CreatedBy { get; set; }
//        public DateTime leadrel_CreatedDate { get; set; }
//        public int leadrel_UpdatedBy { get; set; }
//        public DateTime leadrel_UpdatedDate { get; set; }
//        /// <summary>
//        /// 状态  >=0 有效，少于0 有效
//        /// </summary>
//        public int leadrel_Status { get; set; }
//    }
//}
