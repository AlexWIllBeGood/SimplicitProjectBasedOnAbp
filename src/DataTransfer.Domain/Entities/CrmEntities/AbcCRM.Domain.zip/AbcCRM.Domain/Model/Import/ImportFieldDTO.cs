﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//namespace AbcCRM.Domain.Model.Import
//{
//    [NPoco.TableName("ImportField")]
//    [NPoco.PrimaryKey("if_Id", AutoIncrement = true)]
//    public class ImportFieldDTO
//    {
//        public int if_Id { get; set; }

//        public string if_Name { get; set; }
//        /// <summary>
//        /// 数据库匹配列
//        /// </summary>
//        public string if_Code { get; set; }

//        public int if_Ref_ItId { get; set; }

//        public int if_IsReq { get; set; }

//        public int if_CheckValid { get; set; }

//        /// <summary>
//        /// 当 if_RefData==1 ， 配置内容为caption_famaily_code
//        /// 当 if_RefData<>1 ， 配置内容为sql脚本
//        /// </summary>
//        public string if_CheckSqlFormart { get; set; }

//        /// <summary>
//        /// 检测字符串的正则表达式
//        /// </summary>
//        public string if_TypeRegex { get; set; }

//        public int if_Type { get; set; }
//        /// <summary>
//        /// 是否引用数据
//        /// 1：引用数据库中的内容 Custom_Captions desc  根据desc 获取Code
//        /// 2: 引用field的字段为条件   从后台获取值
//        /// 3: 默认值
//        /// </summary>
//        public int if_RefData { get; set; }

//        /// <summary>
//        /// if_RefData=0 引用自生的值
//        /// if_RefData=2 的时候用到 引用列的值
//        /// if_RefData=3 当前登陆人和时间的默认值
//        /// </summary>
//        public int? if_Ref_IfId { get; set; }

//        public int if_Status { get; set; }

//        public DateTime if_CreatedDate { get; set; }

//        public DateTime if_UpdatedDate { get; set; }

//        public int if_CreatedBy { get; set; }

//        public int if_UpdatedBy { get; set; }


//        public string if_DfValue { get; set; }
//    }
//}
