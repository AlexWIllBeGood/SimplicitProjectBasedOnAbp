﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//namespace AbcCRM.Domain.Model.Import
//{
//    [NPoco.TableName("ImportTable")]
//    [NPoco.PrimaryKey("it_Id",AutoIncrement =true)]
//    public class ImportTableDTO
//    {
//        public int it_Id { get; set; }

//        public string it_TableName { get; set; }

//        public string it_TableCode { get; set; }

//        public int it_Status { get; set; }

//        public int it_CreatedBy { get; set; }

//        public int it_UpdatedBy { get; set; }

//        /// <summary>
//        /// 主键是否自动增长
//        /// </summary>
//        public int it_PrimaryKeyAutoInCre { get; set; }

//        public DateTime? it_CreatedDate { get; set; }

//        public DateTime? it_UpdatedDate { get; set; }
//    }
//}
