﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbcCRM.Domain
{
    public class MinGroupUserModel
    {
        /// <summary>
        /// 用户ID
        /// </summary>
        public int GroupU_UserID { get; set; }

        /// <summary>
        /// 用户中文名
        /// </summary>
        public string GroupU_UserName { get; set; }

        /// <summary>
        /// 组长标识
        /// </summary>
        public int GroupU_IsLeader { get; set; }

    }
}
