﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbcCRM.Domain
{
    /// <summary>
    /// 指标
    /// </summary>
    [NPoco.TableName("Target_Sales")]
    [NPoco.PrimaryKey("Targ_ID", AutoIncrement = true)]
    public class TargetDTO
    {
       public int Targ_ID { get; set; }

        /// <summary>
        /// 年
        /// </summary>
        public int Targ_Year { get; set; }

        /// <summary>
        /// 月
        /// </summary>
        public int Targ_Month { get; set; }

        /// <summary>
        /// 中心
        /// </summary>
        public int Targ_BranchID { get; set; }

        [NPoco.Ignore]
        public string Targ_BranchName { get; set; }

        /// <summary>
        /// 指标类型
        /// </summary>
        public int Targ_Type { get; set; }

        [NPoco.Ignore]
        public string Targ_Type_Name { get; set; }

        public decimal Targ_Target { get; set; }

        public int Targ_CreatedBy { get; set; }

        [NPoco.Ignore]
        public string Targ_CreatedBy_Name { get; set; }

        public DateTime? Targ_CreatedDate { get; set; }
        public int Targ_UpdatedBy { get; set; }

        [NPoco.Ignore]
        public string Targ_UpdatedBy_Name { get; set; }

        public DateTime? Targ_UpdatedDate { get; set; }

        public int Targ_Deleted { get; set; }

    }
}
