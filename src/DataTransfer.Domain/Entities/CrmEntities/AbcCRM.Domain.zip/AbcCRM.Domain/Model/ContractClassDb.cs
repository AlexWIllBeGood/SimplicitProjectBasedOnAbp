﻿//using AbcCRM.Domain.Leads;
//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//namespace AbcCRM.Domain
//{
//    [NPoco.TableName("Contract_Class")]
//    [NPoco.PrimaryKey("contc_ContCid", AutoIncrement = true)]
//    public class ContractClassDb
//    {
//        public int contc_ContCId { get; set; }

//        public int contc_ContId { get; set; }

//        [NPoco.Ignore]
//        public ContractDTO cont { get; set; }

//        [NPoco.Ignore]
//        public LeadDTO lead { get; set; }

//        /// <summary>
//        /// 产品课程类型id  
//        /// 0：寒暑班
//        /// 1：短期班
//        /// </summary>
//        public int contc_ProClasTypeId { get; set; }

//        /// <summary>
//        /// 
//        /// </summary>
//        [NPoco.Ignore]
//        public string contc_ProClassTypeName { get; set; }

//        /// <summary>
//        /// 配置班型时间
//        /// </summary>
//        public DateTime? contc_ClassBegDate { get; set; }

//        public int? contc_ClassId { get; set; }

//        public int contc_CreatedBy { get; set; }

//        public int contc_UpdatedBy { get; set; }

//        public DateTime contc_CreatedDate { get; set; }

//        public DateTime contc_UpdatedDate { get; set; }

//        /// <summary>
//        /// -1：标记删除，0:待上课，1:上课中，2:暂停上课,3：请假 4：取消 5:已完结
//        /// </summary>
//        public int contc_Status { get; set; }

//        /// <summary>
//        /// 状态
//        /// </summary>
//        [NPoco.Ignore]
//        public string contc_Status_Name { get; set; }

//        /// <summary>
//        /// 总课时
//        /// </summary>
//        public int contc_ClassHour { get; set; }

//        /// <summary>
//        /// 已上课时
//        /// </summary>
//        public int contc_UsedClassHour { get; set; }

//        /// <summary>
//        /// 补填之前的已上课时
//        /// </summary>        
//        public int contc_UsedClassHourByHis { get; set; }

//        /// <summary>
//        /// 剩余课时
//        /// </summary>        
//        public int contc_RestClassHour { get; set; }

//        [NPoco.Ignore]
//        public int contc_SysRestClassHour { get; set; }

//        /// <summary>
//        /// 转出课时
//        /// </summary>
//        public int contc_TranOutClassHour { get; set; }
//        /// <summary>
//        /// 转入课时
//        /// </summary>
//        public int contc_TranClassHour { get; set; }

//        /// <summary>
//        /// 合同转入课时
//        /// </summary>
//        public int contc_TranContClassHour { get; set; }

//        /// <summary>
//        /// 合同转出课时
//        /// </summary>
//        public int contc_TranContOutClassHour { get; set; }

//        /// <summary>
//        /// 转移课时
//        /// </summary>
//        [NPoco.Ignore]
//        public int TranClassHour { get; set; }

//        /// <summary>
//        /// 合同转移课时
//        /// </summary>
//        [NPoco.Ignore]
//        public int TranContClassHour { get; set; }

//        /// <summary>
//        /// 对应产品ids
//        /// </summary>
//        public string contc_ProIds { get; set; }

//        /// <summary>
//        /// 产线ID
//        /// </summary>
//        public int contc_ProTypeId { get; set; }

//        public int contc_Month { get; set; }

//        /// <summary>
//        /// 产品信息
//        /// </summary>
//        [NPoco.Ignore]
//        public List<ProductDTO> Pinfoes { get; set; }

//        /// <summary>
//        /// 赠送课时
//        /// </summary>
//        public int contc_GiftClassHour { get; set; }

//        /// <summary>
//        /// 请假课时
//        /// </summary>
//        public int contc_LeaveClassHour { get; set; }

//        /// <summary>
//        /// 补课课时
//        /// </summary>
//        public int contc_MissedClassHour { get; set; }

//        /// <summary>
//        /// 课程信息
//        /// </summary>
//        [NPoco.Ignore]
//        public ClassDTO contc_Classinfo { get; set; }
//    }
//}
