﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbcCRM.Domain
{
    /// <summary>
    /// 报表管理
    /// </summary>
    [NPoco.TableName("Report")]
    [NPoco.PrimaryKey("Repo_ID", AutoIncrement = true)]
    public class ReportDTO
    {
        /// <summary>
        /// 主键
        /// </summary>
        public int Repo_ID { get; set; }

        /// <summary>
        /// 报表名称
        /// </summary>
        public string Repo_Name { get; set; }

        /// <summary>
        /// 排序
        /// </summary>
        public int Repo_Order { get; set; }

        /// <summary>
        /// 报表存储过程
        /// </summary>
        public string Repo_Proc { get; set; }

        /// <summary>
        /// 类型
        /// </summary>
        public string Repo_Type { get; set; }

        /// <summary>
        /// 报表路径
        /// </summary>
        public string Repo_Path { get; set; }

        /// <summary>
        /// 0:正常 1：禁用
        /// </summary>
        public int Repo_Status { get; set; }

        /// <summary>
        /// 报表说明
        /// </summary>
        public string Repo_Desc { get; set; }

        /// <summary>
        /// 发布纪录
        /// </summary>
        public string Repo_Log { get; set; }

        /// <summary>
        /// 创建人
        /// </summary>
        public int Repo_CreatedBy { get; set; }

        /// <summary>
        /// 创建时间
        /// </summary>
        public DateTime Repo_CreatedDate { get; set; }

        /// <summary>
        /// 更新人
        /// </summary>
        public int? Repo_UpdatedBy { get; set; }

        /// <summary>
        /// 更新时间
        /// </summary>
        public DateTime? Repo_UpdatedDate { get; set; }

        /// <summary>
        /// 删除标志位
        /// </summary>
        public int Repo_Deleted { get; set; }

        /// <summary>
        /// 分类名称
        /// </summary>
        [NPoco.Ignore]
        public string Repo_TypeName { get; set; }

        /// <summary>
        /// 角色
        /// </summary>
        [NPoco.Ignore]
        public List<int> Roles { get; set; }
    }
}
