﻿namespace AbcCRM.Domain
{
    /// <summary>
    /// 系统配置表
    /// </summary>
    [NPoco.TableName("SysConfig")]
    [NPoco.PrimaryKey("c_key", AutoIncrement = false)]
    public class SysConfig
    {
        [NPoco.Column("c_key")]
        public SysConfigEnum Key { get; set; }

        [NPoco.Column("c_str_value")]
        public string StrValue { get; set; }

        /// <summary>
        /// 测试专用
        /// </summary>
        [NPoco.Column("c_str_value_test")]
        public string StrValueTest { get; set; }

        [NPoco.Column("c_str_remark")]
        public string Remark { get; set; }
    }

    public enum SysConfigEnum
    {
        /// <summary>
        /// Ftp地址配置
        /// </summary>
        FtpCfg = 1,

        /// <summary>
        /// 邮件地址配置
        /// </summary>
        MailCfg = 2,

        /// <summary>
        /// 教务系统地址配置
        /// </summary>
        EASCfg = 3,

        /// <summary>
        /// 丰台区支付宝支付配置
        /// </summary>
        FengTaiAliPay = 4,

        /// <summary>
        /// 丰台区微信支付配置
        /// </summary>
        FengTaiWxPay = 5,

        /// <summary>
        /// Pay域名
        /// </summary>
        PayDomainName = 6,

        /// <summary>
        /// 域名
        /// </summary>
        DomainName = 7,

        /// <summary>
        /// 测试用户
        /// </summary>
        DebugUser = 8,

        /// <summary>
        /// 测试用户邮箱
        /// </summary>
        DebugUserEmail = 9,

        /// <summary>
        /// 西城区支付宝支付配置
        /// </summary>
        XichengAliPay = 10,

        /// <summary>
        /// 西城区微信支付配置
        /// </summary>
        XichengWxPay = 11,

        /// <summary>
        /// 立刻说免登陆跳转地址
        /// </summary>
        LikeshuoLoginUrl = 12,

    }

    /// <summary>
    /// 地址配置
    /// </summary>
    public class JsonCfg
    {
        /// <summary>
        /// 平台地址
        /// </summary>
        public string Url { get; set; }

        /// <summary>
        /// 平台key
        /// </summary>
        public string Key { get; set; }

        /// <summary>
        /// 平台密码
        /// </summary>
        public string Token { get; set; }
    }
}
