﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbcCRM.Domain
{
    /// <summary>
    /// 学员，班级关联表
    /// </summary>
    [NPoco.TableName("ClassStudent")]
    [NPoco.PrimaryKey("Clst_ID", AutoIncrement = true)]
    public class ClassStudentDTO
    {
        public int Clst_ID { get; set; }

        /// <summary>
        /// 关联班级
        /// </summary>
        public int? Clst_ClassID { get; set; }

        /// <summary>
        /// 关联合同
        /// </summary>
        public int Clst_ContID { get; set; }
        /// <summary>
        /// 关联学员
        /// </summary>
        public int Clst_LeadID { get; set; }

        /// <summary>
        /// 总课时
        /// </summary>
        public int? Clst_ClassHour { get; set; }

        /// <summary>
        /// 上课状态(0待上课,1上课中,2正常完结,3变更审核中,4已停课,5转班完结,6退费完结,7停课到期)
        /// </summary>
        public int Clst_Status { get; set; }

        /// <summary>
        /// 最后上课状态，用来记录审核前状态
        /// </summary>
        public int Clst_LastStatus { get; set; }

        [NPoco.Ignore]
        public string Clst_Status_Name { get; set; }

        /// <summary>
        /// 删除标志位
        /// </summary>
        public int Clst_Deleted { get; set; }

        public int Clst_CreatedBy { get; set; }

        public DateTime? Clst_CreatedDate { get; set; }

        public int Clst_UpdatedBy { get; set; }

        public DateTime? Clst_UpdatedDate { get; set; }

        /// <summary>
        /// 调整课时
        /// </summary>
        public int Clst_AdjustHour { get; set; }

        /// <summary>
        /// 已上课时
        /// </summary>
        public int Clst_FinishHour { get; set; }

        /// <summary>
        /// 剩余课时
        /// </summary>
        [NPoco.Ignore]
        public int Clst_SurplusHour { get; set; }

        /// <summary>
        /// 开始上课时间
        /// </summary>
        public DateTime? Clst_StartDate { get; set; }

        /// <summary>
        /// 结束上课时间
        /// </summary>
        public DateTime? Clst_EndDate { get; set; }

        /// <summary>
        /// 准备停课次数
        /// </summary>
        [NPoco.Ignore]
        public int Clst_StopCount { get; set; }
    }

    [NPoco.TableName("VClassStudent")]
    public class ClassStudentShow : ClassStudentDTO
    {
        public string Lead_Name { get; set; }
        public int Lead_LeadID { get; set; }
        public string Lead_Mobile { get; set; }
        public int Oppo_CC { get; set; }
        public string Clas_Name { get; set; }
        public string Clas_Code { get; set; }
        public DateTime? Clas_ActualBeginDate { get; set; }
        public DateTime? Clas_BeginDate { get; set; }
        public int Clas_Status { get; set; }
        [NPoco.Ignore]
        public string Clas_Status_Name { get; set; }
        public int Clas_LT { get; set; }
        [NPoco.Ignore]
        public string Clas_LT_Name { get; set; }
        public int Clas_FT { get; set; }
        [NPoco.Ignore]
        public string Clas_FT_Name { get; set; }
        public int Clas_SA { get; set; }
        [NPoco.Ignore]
        public string Clas_SA_Name { get; set; }
        public int Clas_BranID { get; set; }
        [NPoco.Ignore]
        public string Clas_Branch_Name { get; set; }

        /// <summary>
        /// 产品ID
        /// </summary>
        public int Prod_ProductID { get; set; }

        /// <summary>
        /// 产品名称
        /// </summary>
        public string Prod_Name { get; set; }

        /// <summary>
        /// 产品
        /// </summary>
        [NPoco.Ignore]
        public ProductDTO Prod { get; set; }

        /// <summary>
        /// 是否允许停转退
        /// </summary>
        [NPoco.Ignore]
        public bool IsEdit { get; set; }

        /// <summary>
        /// 合同金额
        /// </summary>
        [NPoco.Ignore]
        public decimal ContractAmount { get; set; }

        /// <summary>
        /// 合同业绩金额
        /// </summary>
        [NPoco.Ignore]
        public decimal ContractResults { get; set; }

        /// <summary>
        /// 首次交费日期
        /// </summary>
        [NPoco.Ignore]
        public string ContractDate { get; set; }

        /// <summary>
        /// 合同总课时
        /// </summary>
        [NPoco.Ignore]
        public int? ContractHour { get; set; }
    }

    /// <summary>
    /// 学员班级总课时变更记录表
    /// </summary>
    [NPoco.TableName("ClassStudent_Log")]
    [NPoco.PrimaryKey("Cslg_ID", AutoIncrement = true)]
    public class ClassStudentLog
    {
        public int Cslg_ID { get; set; }

        /// <summary>
        /// 关联的学员班级总课时ID
        /// </summary>
        public int Cslg_ClassStudentID { get; set; }

        /// <summary>
        /// 变更类型 1：新增课时，2:退费扣减课时，3：转移扣减课时，4：手动调整课时
        /// </summary>
        public int Cslg_Type { get; set; }

        /// <summary>
        /// 变更类型名称
        /// </summary>
        [NPoco.Ignore]
        public string Cslg_Type_Name { get; set; }

        /// <summary>
        /// 课时
        /// </summary>
        public int Cslg_ClassHour { get; set; }

        /// <summary>
        /// 调整课时
        /// </summary>
        public int Cslg_AdjustHour { get; set; }

        /// <summary>
        /// 已上课时
        /// </summary>
        public int Cslg_FinishHour { get; set; }

        /// <summary>
        /// 关联合同
        /// </summary>
        public int Cslg_ContID { get; set; }

        /// <summary>
        /// 创建人
        /// </summary>
        public int Cslg_CreatedBy { get; set; }

        [NPoco.Ignore]
        public string Cslg_CreatedBy_Name { get; set; }

        /// <summary>
        /// 创建时间
        /// </summary>
        public DateTime? Cslg_CreatedDate { get; set; }

        public int Cslg_Deleted { get; set; }

    }

    /// <summary>
    /// 学员班级总课时变更记录显示模型
    /// </summary>
    public class ClassStudentLogShow : ClassStudentLog
    {
        /// <summary>
        /// 合同号
        /// </summary>
        public string Cont_Number { get; set; }
    }

    /// <summary>
    /// 学员班级停课记录表
    /// </summary>
    [NPoco.TableName("ClassStudent_StopLog")]
    [NPoco.PrimaryKey("Stop_ID", AutoIncrement = true)]
    public class ClassStudentStopLog
    {
        public int Stop_ID { get; set; }

        public int Stop_LeadID { get; set; }

        public int Stop_ClassID { get; set; }

        /// <summary>
        /// 班号
        /// </summary>
        [NPoco.Ignore]
        public string Stop_ClassCode { get; set; }

        /// <summary>
        /// 中心
        /// </summary>
        [NPoco.Ignore]
        public string Stop_ClassBranName { get; set; }

        /// <summary>
        /// 退课原因
        /// </summary>
        public string Stop_Reason { get; set; }

        /// <summary>
        /// 剩余课时
        /// </summary>
        public int Stop_SurplusHour { get; set; }

        /// <summary>
        /// 剩余金额
        /// </summary>
        public decimal Stop_SurplusAmount { get; set; }

        /// <summary>
        /// 开始时间
        /// </summary>
        public DateTime Stop_StartDate { get; set; }

        /// <summary>
        /// 结束时间
        /// </summary>
        public DateTime Stop_EndDate { get; set; }

        /// <summary>
        /// 审核状态
        /// </summary>
        public int Stop_Status { get; set; }

        [NPoco.Ignore]
        public string Stop_Status_Name { get; set; }

        /// <summary>
        /// 费用计算方式
        /// </summary>
        public string Stop_CostCalcWay { get; set; }

        public int? Stop_CreatedBy { get; set; }

        [NPoco.Ignore]
        public string Stop_CreatedBy_Name { get; set; }

        public DateTime? Stop_CreatedDate { get; set; }

        public int? Stop_UpdatedBy { get; set; }

        [NPoco.Ignore]
        public string Stop_UpdatedBy_Name { get; set; }

        public DateTime? Stop_UpdatedDate { get; set; }

        public int Stop_Deleted { get; set; }
    }

    /// <summary>
    /// 学员班级复课实体
    /// </summary>
    public class RestoreClassStu 
    {
        /// <summary>
        /// 学员班级关系实体
        /// </summary>
        public ClassStudentDTO classStu { get; set; }
        /// <summary>
        /// 复课的排课ID
        /// </summary>
        public int scheduleID { get; set; }
    }

    /// <summary>
    /// 提前完结停课
    /// </summary>
    public class StuStopEndDate 
    {
        public ClassStudentDTO classStu { get; set; }
        public DateTime EndDate { get; set; }

    }

    /// <summary>
    /// 学员班级停课记录显示模型
    /// </summary>
    public class ClassStudentStopLogShow : ClassStudentStopLog
    {
        /// <summary>
        /// 班号
        /// </summary>
        public string Clas_Code { get; set; }

        /// <summary>
        /// 中心
        /// </summary>
        public int Clas_BranID { get; set; }
        public int Oppo_CC { get; set; }
        /// <summary>
        /// 中心
        /// </summary>
        [NPoco.Ignore]
        public string Clas_BranName { get; set; }

        /// <summary>
        /// 学员姓名
        /// </summary>
        public string Lead_Name { get; set; }
        /// <summary>
        /// 学员ID
        /// </summary>
        public int Lead_LeadID { get; set; }


        /// <summary>
        /// 学员手机号
        /// </summary>
        public string Lead_Mobile { get; set; }

        /// <summary>
        /// 流程ID
        /// </summary>
        [NPoco.Ignore]
        public int WfInstID { get; set; }
    }

    /// <summary>
    /// 学员班级转班转学记录表
    /// </summary>
    [NPoco.TableName("ClassStudent_TransferLog")]
    [NPoco.PrimaryKey("Tran_ID", AutoIncrement = true)]
    public class ClassStudentTransferLog
    {
        public int Tran_ID { get; set; }

        /// <summary>
        /// 多转关系ID
        /// </summary>
        public string Tran_BundleID { get; set; }

        /// <summary>
        /// 客户ID
        /// </summary>
        public int Tran_LeadID { get; set; }

        /// <summary>
        /// 班级
        /// </summary>
        public int Tran_ClassID { get; set; }

        /// <summary>
        /// 转班订单
        /// </summary>
        public int Tran_OrderID { get; set; }

        /// <summary>
        /// 转学/转班 原因
        /// </summary>
        public string Tran_Reason { get; set; }

        /// <summary>
        /// 转移中心
        /// </summary>
        public int Tran_BranID { get; set; }

        /// <summary>
        /// 转移中心
        /// </summary>
        [NPoco.Ignore]
        public string Tran_BranName { get; set; }

        /// <summary>
        /// 转移班级(单个，一般使用下面多转的ID)
        /// </summary>
        public int Tran_TransferClassID { get; set; }

        /// <summary>
        /// 多转班级ID
        /// </summary>
        public string Tran_BundleClassID { get; set; }

        /// <summary>
        /// 售卖方式
        /// </summary>
        public int Tran_ProsID { get; set; }

        /// <summary>
        /// 数量
        /// </summary>
        public int Tran_SaleNum { get; set; }

        /// <summary>
        /// 应收金额
        /// </summary>
        public decimal Tran_AccountReceivable { get; set; }

        /// <summary>
        /// 新班开课时间（转学、平转）
        /// </summary>
        public DateTime? Tran_ClassBeginDate { get; set; }

        /// <summary>
        /// 转移课时
        /// </summary>
        public int Tran_SurplusHour { get; set; }

        /// <summary>
        /// 转移金额
        /// </summary>
        public decimal Tran_SurplusAmount { get; set; }

        /// <summary>
        /// 审核状态
        /// </summary>
        public int Tran_Status { get; set; }

        [NPoco.Ignore]
        public string Tran_Status_Name { get; set; }

        /// <summary>
        /// 转移类型(0转班，1转学，2平转)
        /// </summary>
        public int Tran_Type { get; set; }

        [NPoco.Ignore]
        public string Tran_Type_Name { get; set; }

        /// <summary>
        /// 费用计算方式
        /// </summary>
        public string Tran_CostCalcWay { get; set; }

        /// <summary>
        /// 创建时间
        /// </summary>
        public int Tran_CreatedBy { get; set; }

        [NPoco.Ignore]
        public string Tran_CreatedBy_Name { get; set; }

        public DateTime Tran_CreatedDate { get; set; }

        public int? Tran_UpdatedBy { get; set; }

        [NPoco.Ignore]
        public string Tran_UpdatedBy_Name { get; set; }

        public DateTime? Tran_UpdatedDate { get; set; }

        public int Tran_Deleted { get; set; }
    }

    /// <summary>
    /// 学员班级转班转学记录显示模型
    /// </summary>
    public class ClassStudentTransferLogShow : ClassStudentTransferLog
    {
        /// <summary>
        /// 班号
        /// </summary>
        public string Clas_Code { get; set; }

        /// <summary>
        /// 中心
        /// </summary>
        public int Clas_BranID { get; set; }

        /// <summary>
        /// 中心
        /// </summary>
        [NPoco.Ignore]
        public string Clas_BranName { get; set; }

        /// <summary>
        /// 转移班号
        /// </summary>
        public string Tran_TransferClassCode { get; set; }

        /// <summary>
        /// 学员姓名
        /// </summary>
        public string Lead_Name { get; set; }

        /// <summary>
        /// 学员手机号
        /// </summary>
        public string Lead_Mobile { get; set; }

        /// <summary>
        /// 转班订单
        /// </summary>
        public string Orde_Number { get; set; }

        /// <summary>
        /// 转班删除状态
        /// </summary>
        public int Orde_Deleted { get; set; }

        /// <summary>
        /// 流程ID
        /// </summary>
        [NPoco.Ignore]
        public int WfInstID { get; set; }
    }

    /// <summary>
    /// 学员班级退费记录表
    /// </summary>
    [NPoco.TableName("ClassStudent_RefundLog")]
    [NPoco.PrimaryKey("Refund_ID", AutoIncrement = true)]
    public class ClassStudentRefundLog
    {
        /// <summary>
        /// 自增主键
        /// </summary>
        public int Refund_ID { get; set; }

        /// <summary>
        /// 退费类型 0：班课，1：订单
        /// </summary>
        public int Refund_Type { get; set; }

        /// <summary>
        /// 退费类型 0：班课，1：订单
        /// </summary>
        [NPoco.Ignore]
        public string Refund_TypeName { get; set; }

        /// <summary>
        /// 客户ID
        /// </summary>
        public int Refund_LeadID { get; set; }

        /// <summary>
        /// 订单号
        /// </summary>
        public int Refund_OrderID { get; set; }

        /// <summary>
        /// 产线，区分退费方式
        /// </summary>
        public int Refund_ProductType { get; set; }

        /// <summary>
        /// 班级ID
        /// </summary>
        public int Refund_ClassID { get; set; }

        /// <summary>
        /// 退费课时
        /// </summary>
        public int Refund_SurplusHour { get; set; }

        /// <summary>
        /// 剩余价值
        /// </summary>
        public decimal Refund_SurplusAmount { get; set; }

        /// <summary>
        /// 退费金额
        /// </summary>
        public decimal Refund_Amount { get; set; }

        /// <summary>
        /// 审核状态
        /// </summary>
        public int Refund_Status { get; set; }

        /// <summary>
        /// 办理日期
        /// </summary>
        public DateTime? Refund_ProcessdDate { get; set; }

        /// <summary>
        /// 备注
        /// </summary>
        public string Refund_Remark { get; set; }

        /// <summary>
        /// 费用计算方式
        /// </summary>
        public string Refund_CostCalcWay { get; set; }

        [NPoco.Ignore]
        public string Refund_Status_Name { get; set; }

        public int Refund_CreatedBy { get; set; }

        [NPoco.Ignore]
        public string Refund_CreatedBy_Name { get; set; }

        public DateTime Refund_CreatedDate { get; set; }

        public int? Refund_UpdatedBy { get; set; }

        [NPoco.Ignore]
        public string Refund_UpdatedBy_Name { get; set; }

        public DateTime? Refund_UpdatedDate { get; set; }

        /// <summary>
        /// 删除标志位
        /// </summary>
        public int Refund_Deleted { get; set; }

        /// <summary>
        /// 扣罚金额
        /// </summary>
        public decimal? Refund_FineAmount { get; set; }

        /// <summary>
        /// 校办批准日期
        /// </summary>
        public DateTime? Refund_RatifyDate { get; set; }

        /// <summary>
        /// 退费类型
        /// </summary>
        public string Refund_RefundType { get; set; }

        /// <summary>
        /// 处理意见
        /// </summary>
        public string Refund_ProcessdOpinion { get; set; }

        /// <summary>
        /// 退费原因
        /// </summary>
        public string Refund_Reason { get; set; }

        /// <summary>
        /// 开课是否超过一年
        /// </summary>
        public string Refund_IsOverYear { get; set; }

        /// <summary>
        /// 是否当月计算新生
        /// </summary>
        public string Refund_IsMonthNewborn { get; set; }

        /// <summary>
        /// 当月计算新生个数
        /// </summary>
        public int Refund_MonthNewbornNumber { get; set; }

        /// <summary>
        /// 打款日期
        /// </summary>
        public DateTime? Refund_PayDate { get; set; }
    }

    /// <summary>
    /// 学员班级退费记录显示模型
    /// </summary>
    public class ClassStudentRefundLogShow : ClassStudentRefundLog
    {
        /// <summary>
        /// 班号
        /// </summary>
        public string ClassCodeOrOrderNumber { get; set; }

        /// <summary>
        /// 中心
        /// </summary>
        public int BranID { get; set; }

        /// <summary>
        /// 中心
        /// </summary>
        [NPoco.Ignore]
        public string BranName { get; set; }

        /// <summary>
        /// 学员姓名
        /// </summary>
        public string Lead_Name { get; set; }

        /// <summary>
        /// 学员手机号
        /// </summary>
        public string Lead_Mobile { get; set; }

        /// <summary>
        /// 订单启动日期
        /// </summary>
        public DateTime Orde_SignUpDate { get; set; }

        /// <summary>
        /// 订单实收金额
        /// </summary>
        public decimal Orde_CashReceived { get; set; }

        /// <summary>
        /// 合同金额
        /// </summary>
        [NPoco.Ignore]
        public decimal ContractAmount { get; set; }

        /// <summary>
        /// 合同业绩金额
        /// </summary>
        [NPoco.Ignore]
        public decimal ContractResults { get; set; }

        /// <summary>
        /// 首次交费日期
        /// </summary>
        [NPoco.Ignore]
        public string ContractDate { get; set; }

        /// <summary>
        /// 合同总课时
        /// </summary>
        [NPoco.Ignore]
        public int? ContractHour { get; set; }

        /// <summary>
        /// 流程ID
        /// </summary>
        [NPoco.Ignore]
        public int WfInstID { get; set; }
    }

    /// <summary>
    /// 转移业绩模型
    /// </summary>
    public class TranResultsModel
    {
        /// <summary>
        /// 班级ID
        /// </summary>
        public int ClassID { get; set; }

        /// <summary>
        /// 转移金额
        /// </summary>
        public decimal TranAmount { get; set; }
    }
}
