﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbcCRM.Domain
{
    /// <summary>
    /// VOpportunityLead视图
    /// </summary>
    [NPoco.TableName("VFeedbackRecord")]
    [NPoco.PrimaryKey("Fdkr_ID", AutoIncrement = true)]
    public class VFeedbackRecordDTO : FeedbackRecordDTO
    {
        public int Prod_ProductID { get; set; }

        public string Prod_Name { get; set; }

        /// <summary>
        /// 学员姓名
        /// </summary>
        public string Lead_Name { get; set; }
        /// <summary>
        /// 学员手机号
        /// </summary>
        public string Lead_Mobile { get; set; }
        /// <summary>
        /// 订单号
        /// </summary>
        public string Orde_Number { get; set; }

        /// <summary>
        /// 产品大类
        /// </summary>
        public int Orde_ProductType { get; set; }

        /// <summary>
        /// 订单备注
        /// </summary>
        public string Orde_Remark { get; set; }

        public string Orde_SignUpDate { get; set; }
        /// <summary>
        /// 班号
        /// </summary>
        public string Clas_Code { get; set; }

        /// <summary>
        /// 修改人
        /// </summary>
        [NPoco.Ignore]
        public string Fdkr_UpdatedBy_Name { get; set; }

        /// <summary>
        /// 创建人
        /// </summary>
        [NPoco.Ignore]
        public string Fdkr_CreatedBy_Name { get; set; }

        /// <summary>
        /// 反馈类型
        /// </summary>
        [NPoco.Ignore]
        public string Fdkr_Type_Name { get; set; }
        /// <summary>
        /// 推荐人
        /// </summary>
        public string Fdkr_RefLead_Name { get; set; }
        /// <summary>
        /// 推荐人班号
        /// </summary>
        public string Fdkr_RefClassCode { get; set; }
        /// <summary>
        /// 推荐人班级组别
        /// </summary>
        public string Fdkr_RefClassGroup { get; set; }
        [NPoco.Ignore]
        public string Fdkr_RefClassGroup_Name { get; set; }
        /// <summary>
        /// 推荐人——老师
        /// </summary>
        [NPoco.Ignore]
        public string Fdkr_RefTeacher_Name { get; set; }
        /// <summary>
        /// 推荐人——老师类型
        /// </summary>
        [NPoco.Ignore]
        public string Fdkr_RefTeachJobType_Name { get; set; }
        /// <summary>
        /// 中心名
        /// </summary>
        [NPoco.Ignore]
        public string Fdkr_ContBranID_Name { get; set; }
        /// <summary>
        /// 销售
        /// </summary>
        [NPoco.Ignore]
        public string Fdkr_ContSales_Name { get; set; }
        /// <summary>
        /// 反馈状态
        /// </summary>
        [NPoco.Ignore]
        public string Fdkr_Status_Name { get; set; }
        /// <summary>
        /// 总部审核结果
        /// </summary>
        [NPoco.Ignore]
        public string Fdkr_CheckStatus_Name { get; set; }
        /// <summary>
        /// 中心反馈
        /// </summary>
        [NPoco.Ignore]
        public string Fdkr_BranchFeedback_Name { get; set; }
        

    }
}
