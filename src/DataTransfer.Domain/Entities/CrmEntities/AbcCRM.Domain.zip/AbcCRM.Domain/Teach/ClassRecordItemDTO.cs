﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbcCRM.Domain.Teach
{

    /// <summary>
    /// 上课记录
    /// </summary>
    [NPoco.TableName("ClassRecordItem")]
    [NPoco.PrimaryKey("clri_Id", AutoIncrement = true)]
    public class ClassRecordItemDTO
    {
        public int clri_Id { get; set; }

        /// <summary>
        /// 类型：0：DEMO,1:正式 ,2:补课
        /// </summary>
        public int clri_Type { get; set; }

        /// <summary>
        /// 排课ID
        /// </summary>
        public int clri_ClassScheduleId { get; set; }
        public int clri_ClassID { get; set; }
        [NPoco.Ignore]
        public List<int> clri_ClassScheduleIdes { get; set; }

        [NPoco.Ignore]
        public ClassScheduleDTO ClassSchedule { get; set; }

        /// <summary>
        /// 类型：0：试听学员,1:正式学员
        /// </summary>
        public int clri_LeadType { get; set; }

        [NPoco.Ignore]
        public string clri_LeadType_Name { get; set; }

        public int clri_LeadId { get; set; }

        [NPoco.Ignore]
        public LeadDTO lead { get; set; }

        public int clri_ContractId { get; set; }

        [NPoco.Ignore]
        public ContractDTO cont { get; set; }

        public int clri_ContProId { get; set; }

        /// <summary>
        /// 合同课程记录id
        /// </summary>
        public int clri_ContCId { get; set; }

        //[NPoco.Ignore]
        //public ContractClassDb contractClass { get; set; }

        /// <summary>
        /// 本次消耗课时
        /// </summary>
        public int clri_ClassHour { get; set; }

        /// <summary>
        /// 状态：0待上课，1已上课，2请假，3取消，4停课，5未出席
        /// </summary>
        public int clri_Status { get; set; }

        [NPoco.Ignore]
        public string clri_Status_Name { get; set; }

        [NPoco.Ignore]
        public string clri_Type_Name { get; set; }

        /// <summary>
        /// 备注
        /// </summary>
        public string clri_Remark { get; set; }

        /// <summary>
        /// 创建人
        /// </summary>
        public int clri_CreatedBy { get; set; }

        [NPoco.Ignore]
        public string clri_CreatedBy_Name { get; set; }

        /// <summary>
        /// 创建时间
        /// </summary>
        public DateTime clri_CreatedDate { get; set; }

        public int? clri_UpdatedBy { get; set; }

        [NPoco.Ignore]
        public string clri_UpdatedBy_Name { get; set; }

        public DateTime? clri_UpdatedDate { get; set; }

        /// <summary>
        /// 删除标志位
        /// </summary>
        public int Clri_Deleted { get; set; }
    }

   
    /// <summary>
    /// 上课记录视图
    /// </summary>
    [NPoco.TableName("VClassRecord")]
    public class VClassRecordItem:ClassRecordItemDTO
    {
        /// <summary>
        /// 班级编码
        /// </summary>
        public string Clas_Code { get; set; }

        /// <summary>
        /// 所属中心
        /// </summary>
        public int Clas_BranID { get; set; }
        [NPoco.Ignore]
        public string Clas_Bran_Name { get; set; }
        /// <summary>
        /// 上课日期
        /// </summary>
        public DateTime? Clsc_ClassDate { get; set; }
        /// <summary>
        /// 总课时（分钟）
        /// </summary>
        public int Clsc_ClassTime { get; set; }
        /// <summary>
        /// 消耗课时
        /// </summary>
        public int Clsc_ClassHour { get; set; }

        /// <summary>
        /// 教室
        /// </summary>
        public string Clsc_Classroom { get; set; }

        /// <summary>
        /// 中教
        /// </summary>
        public int? Clsc_LT { get; set; }
        /// <summary>
        /// 中教课时（分钟）
        /// </summary>
        public int Clsc_LTClassTime { get; set; }
        /// <summary>
        /// 中教消耗课时
        /// </summary>
        [NPoco.Ignore]
        public decimal Clsc_LTClassHour { get; set; }
        /// <summary>
        /// 外教
        /// </summary>
        public int? Clsc_FT { get; set; }
        /// <summary>
        /// 外教课时（分钟）
        /// </summary>
        public int Clsc_FTClassTime { get; set; }
        /// <summary>
        /// 外教消耗课时
        /// </summary>
        [NPoco.Ignore]
        public decimal Clsc_FTClassHour { get; set; }
        /// <summary>
        /// 中教名称
        /// </summary>
        [NPoco.Ignore]
        public string Clsc_LT_Name { get; set; }

        /// <summary>
        /// 外教名称
        /// </summary>
        [NPoco.Ignore]
        public string Clsc_FT_Name { get; set; }
        /// <summary>
        /// 上课开始时间（不带日期）
        /// </summary>
        public string Clsc_BeginTime { get; set; }

        /// <summary>
        /// 上课结束时间（不带日期）
        /// </summary>
        public string Clsc_EndTime { get; set; }

        /// <summary>
        /// 周几
        /// </summary>
        [NPoco.Ignore]
        public string Week { get; set; }

        /// <summary>
        /// 班型人数
        /// </summary>
        public int Clsc_Num { get; set; }

        /// <summary>
        /// 状态代码（0待上课，1已上课，2已取消）
        /// </summary>
        public int Clsc_Status { get; set; }
        [NPoco.Ignore]
        public string Clsc_Status_Name { get; set; }

        /// <summary>
        /// 期数
        /// </summary>
        public int Clsc_Period { get; set; }

        /// <summary>
        /// 每期序号
        /// </summary>
        public int Clsc_No { get; set; }

        public int Lead_LeadID { get; set; }
        public string Lead_Name { get; set; }
        public string Lead_Mobile { get; set; }
        public int Clas_ProdID { get; set; }
        public string Prod_Name { get; set; }
        public int Prod_Type { get; set; }
        public string Prot_Name { get; set; }
        public int Prot_ClassRule { get; set; }

    }

    /// <summary>
    /// 学员维度上课记录
    /// </summary>
    [NPoco.TableName("VStuClassRecord")]
    public class StuClassRecordItem: VClassRecordItem
    {
        
    }
    /// <summary>
    /// 多条上课记录
    /// </summary>
    public class ClassRecordMultiple
    {
        public List<ClassRecordItemDTO> list { get; set; }
        /// <summary>
        /// 上课状态
        /// </summary>
        public int Status { get; set; }
        /// <summary>
        /// 消耗课时
        /// </summary>
        public int ClassHour { get; set; }
    }

    /// <summary>
    /// 上课记录调整记录
    /// </summary>
    [NPoco.TableName("ClassRecordItemLog")]
    [NPoco.PrimaryKey("Clrl_ID", AutoIncrement = true)]
    public class ClassRecordItemLogDTO
    {
        public int Clrl_ID { get; set; }
        /// <summary>
        /// 排课类型
        /// </summary>
        public int Clrl_Type { get; set; }
        /// <summary>
        /// 调整至哪节排课ID开始
        /// </summary>
        public int Clrl_ClassScheduleID { get; set; }

        /// <summary>
        /// 班级ID
        /// </summary>
        public int Clrl_ClassID { get; set; }

        /// <summary>
        /// LeadID
        /// </summary>
        public int Clrl_LeadID { get; set; }

        /// <summary>
        /// 班级学员关系ID
        /// </summary>
        public int Clrl_ClassStudentID { get; set; }

        /// <summary>
        /// 备注
        /// </summary>
        public string Clrl_Remark { get; set; }

        /// <summary>
        /// 创建人
        /// </summary>
        public int Clrl_CreatedBy { get; set; }

        [NPoco.Ignore]
        public string Clrl_CreatedBy_Name { get; set; }

        /// <summary>
        /// 创建时间
        /// </summary>
        public DateTime Clrl_CreatedDate { get; set; }

        public int? Clrl_UpdatedBy { get; set; }

        [NPoco.Ignore]
        public string Clrl_UpdatedBy_Name { get; set; }

        public DateTime? Clrl_UpdatedDate { get; set; }

        /// <summary>
        /// 删除标志位
        /// </summary>
        public int Clrl_Deleted { get; set; }
    }
}
