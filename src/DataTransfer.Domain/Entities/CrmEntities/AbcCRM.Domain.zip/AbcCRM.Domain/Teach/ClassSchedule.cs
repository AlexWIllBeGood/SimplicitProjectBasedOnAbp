﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbcCRM.Domain.Teach
{
    public class ClassSchedule
    {
        public DateTime? ClassDate { get; set; }
        public int Week { get; set; }
        public string WeekName { get; set; }
        public string BeginTime { get; set; }
        public string EndTime { get; set; }
    }
}
