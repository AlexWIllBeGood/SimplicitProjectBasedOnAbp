﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbcCRM.Domain
{
    /// <summary>
    /// 反馈配置表
    /// </summary>
    [NPoco.TableName("FeedbackConfig")]
    [NPoco.PrimaryKey("Fdkc_ID", AutoIncrement = true)]
    public class FeedbackConfigDTO
    {
        #region 属性		
        /// <summary>
        /// 
        /// </summary>
        public int Fdkc_ID { get; set; }

        /// <summary>
        /// 反馈类型（1新生，2老生，3试听）
        /// </summary>
        public int? Fdkc_Type { get; set; }

        /// <summary>
        /// 报名产品
        /// </summary>
        public int? Fdkc_ProductID { get; set; }

        /// <summary>
        /// 数据符号（1大于等于，2小于）
        /// </summary>
        public int? Fdkc_DataSymbol { get; set; }

        /// <summary>
        /// 金额
        /// </summary>
        public decimal? Fdkc_Amount { get; set; }

        /// <summary>
        /// 反馈数
        /// </summary>
        public decimal? Fdkc_Number { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public int? Fdkc_CreatedBy { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public DateTime? Fdkc_CreatedDate { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public int? Fdkc_UpdatedBy { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public DateTime? Fdkc_UpdatedDate { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public int? Fdkc_Deleted { get; set; }

        #endregion

        /// <summary>
        /// 反馈类型名
        /// </summary>
        [NPoco.Ignore]
        public string Fdkc_Type_Name { get; set; }

        /// <summary>
        /// 产品名
        /// </summary>
        [NPoco.Ignore]
        public string Fdkc_ProductID_Name { get; set; }

        /// <summary>
        /// 数据符号
        /// </summary>
        [NPoco.Ignore]
        public string Fdkc_DataSymbol_Name { get; set; }

        /// <summary>
        /// 创建人
        /// </summary>
        [NPoco.Ignore]
        public string Fdkc_CreatedBy_Name { get; set; }

        /// <summary>
        /// 更新人
        /// </summary>
        [NPoco.Ignore]
        public string Fdkc_UpdatedBy_Name { get; set; }
    }
}
