﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbcCRM.Domain
{
    /// <summary>
    /// 试听课记录
    /// </summary>
    [NPoco.TableName("DemoRecord")]
    [NPoco.PrimaryKey("Derd_ID", AutoIncrement = true)]
    public class DemoRecordDTO
    {
        #region 属性		
        /// <summary>
        /// 主键
        /// </summary>
        public int Derd_ID { get; set; }

        /// <summary>
        /// leadID
        /// </summary>
        public int? Derd_LeadID { get; set; }

        /// <summary>
        /// 状态（0未使用，1使用中，2已使用）
        /// </summary>
        public int? Derd_Status { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public int? Derd_CreatedBy { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public DateTime? Derd_CreatedDate { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public int? Derd_UpdatedBy { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public DateTime? Derd_UpdatedDate { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public int Derd_Deleted { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string Derd_Remark { get; set; }

        /// <summary>
        /// 试讲老师
        /// </summary>
        public int? Derd_TeacherID { get; set; }

        /// <summary>
        /// 试听产品
        /// </summary>
        public int? Derd_ProductID { get; set; }

        #endregion

        /// <summary>
        /// 试听状态
        /// </summary>
        [NPoco.Ignore]
        public string Derd_Status_Name { get; set; }

        /// <summary>
        /// 创建人
        /// </summary>
        [NPoco.Ignore]
        public string Derd_CreatedBy_Name { get; set; }

        /// <summary>
        /// 修改人
        /// </summary>
        [NPoco.Ignore]
        public string Derd_UpdatedBy_Name { get; set; }

        /// <summary>
        /// 试讲老师
        /// </summary>
        [NPoco.Ignore]
        public string Derd_TeacherID_Name { get; set; }

        /// <summary>
        /// 试听产品
        /// </summary>
        [NPoco.Ignore]
        public string Derd_ProductID_Name { get; set; }
    }
}
