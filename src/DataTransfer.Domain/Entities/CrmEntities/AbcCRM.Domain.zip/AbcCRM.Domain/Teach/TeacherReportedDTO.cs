﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbcCRM.Domain
{
    /// <summary>
    /// 教师报备
    /// </summary>
    [NPoco.TableName("TeacherReported")]
    [NPoco.PrimaryKey("Trrd_ID", AutoIncrement = true)]
    public class TeacherReportedDTO
    {
        #region 属性		
        /// <summary>
		/// 主键
		/// </summary>
        public int Trrd_ID { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public int? Trrd_CreatedBy { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string Trrd_CreatedByName { get; set; }


        /// <summary>
        /// 
        /// </summary>
        public DateTime? Trrd_CreatedDate { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public int? Trrd_UpdatedBy { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string Trrd_UpdatedByName { get; set; }


        /// <summary>
        /// 
        /// </summary>
        public DateTime? Trrd_UpdatedDate { get; set; }


        /// <summary>
        /// 
        /// </summary>
        public int Trrd_Deleted { get; set; }


        /// <summary>
        /// 教师姓名
        /// </summary>
        public string Trrd_TeacherName { get; set; }


        /// <summary>
        /// 教师UserID
        /// </summary>
        public int? Trrd_TeacherUserID { get; set; }

        /// <summary>
        /// 推荐人姓名
        /// </summary>
        public string Trrd_RecommenderName { get; set; }

        /// <summary>
        /// 推荐人ID
        /// </summary>
        public int? Trrd_RecommenderID { get; set; }
        /// <summary>
        /// 报备客户系统是否存在，0:不存在，1：存在
        /// </summary>
        public int? Trrd_IsNew { get; set; }
        /// <summary>
        /// 新生姓名（报备客户姓名）
        /// </summary>
        public string Trrd_NewName { get; set; }

        /// <summary>
        /// 新生ID（报备客户关联的LeadID）
        /// </summary>
        public int? Trrd_NewID { get; set; }
        /// <summary>
        /// 新生ID关联的lead
        /// </summary>
        [NPoco.Ignore]
        public LeadDTO Trrd_NewLead { get; set; }
        /// <summary>
        /// 新lead所选二级渠道
        /// </summary>
        public int Trrd_LeadChannelTwo { get; set; }
        /// <summary>
        /// 报备编号
        /// </summary>
        public string Trrd_ReportedNo { get; set; }

        /// <summary>
        /// 报备中心名
        /// </summary>
        public string Trrd_ReportedBranName { get; set; }


        /// <summary>
        /// 报备中心ID
        /// </summary>
        public int Trrd_ReportedBranID { get; set; }

        /// <summary>
        /// 新生电话（报备客户手机号）
        /// </summary>
        public string Trrd_Telephone { get; set; }

        /// <summary>
        /// 交费金额
        /// </summary>
        public decimal? Trrd_PayAmount { get; set; }

        /// <summary>
        /// 所报产品
        /// </summary>
        public int? Trrd_ProductTypeID { get; set; }

        /// <summary>
        /// 课程-产品大类-老系统用
        /// </summary>
        public string Trrd_ProductTypeName { get; set; }

        /// <summary>
        /// 交费时间
        /// </summary>
        public DateTime? Trrd_PayDate { get; set; }
        [NPoco.Ignore]
        public string Trrd_PayDate_Short { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string Trrd_CCName { get; set; }

        /// <summary>
        /// 课程顾问
        /// </summary>
        public int? Trrd_CC { get; set; }

        /// <summary>
        /// 总部备注
        /// </summary>
        public string Trrd_HQRemark { get; set; }

        /// <summary>
        /// 总部审核
        /// </summary>
        public int? Trrd_HQAudit { get; set; }

        /// <summary>
        /// 中心备注
        /// </summary>
        public string Trrd_CenterRemark { get; set; }

        /// <summary>
        /// 交费性质
        /// </summary>
        public int? Trrd_PayNature { get; set; }
       
        /// <summary>
        /// 报备类型
        /// </summary>
        public int? Trrd_ReportedType { get; set; }

        /// <summary>
        /// 财务核实交费
        /// </summary>
        public decimal? Trrd_FinancialVerifPayment { get; set; }

        /// <summary>
        /// 奖金计入月份
        /// </summary>
        public DateTime? Trrd_BonusPlanDate { get; set; }
        [NPoco.Ignore]
        public string Trrd_BonusPlanDate_Short { get; set; }
        /// <summary>
        /// 学员管理创建日期
        /// </summary>
        public DateTime? Trrd_StudentManageDate { get; set; }

        /// <summary>
        /// 报备时间
        /// </summary>
        public DateTime? Trrd_ReportedDate
        {
            get;
            set;
        }

        /// <summary>
        /// 是否报名
        /// </summary>
        public int Trrd_Apply
        {
            get;
            set;
        }

        /// <summary>
        /// 奖金归属人UserID
        /// </summary>
        public int? Trrd_BonusHolderUserID
        {
            get;
            set;
        }

        /// <summary>
        /// 奖金归属人姓名
        /// </summary>
        public string Trrd_BonusHolderName
        {
            get;
            set;
        }

        /// <summary>
        /// 中心反馈
        /// </summary>
        public int? Trrd_CenterFeedback
        {
            get;
            set;
        }

        /// <summary>
        /// 旧系统的e__jsbb表主键
        /// </summary>
        public string Trrd_C__JsbbId
        {
            get;
            set;
        }

        #endregion

        [NPoco.Ignore]
        public string Trrd_ReportedType_Name { get; set; }

        [NPoco.Ignore]
        public string Trrd_PayNature_Name { get; set; }

        [NPoco.Ignore]
        public string Trrd_HQAudit_Name { get; set; }

        [NPoco.Ignore]
        public string Trrd_ReportedBran_Name { get; set; }

        [NPoco.Ignore]
        public string Trrd_ProductType_Name { get; set; }

        /// <summary>
        /// 审批状态
        /// </summary>
        public int Trrd_Status { get; set; }
        [NPoco.Ignore]
        public string Trrd_Status_Name { get; set; }
        /// <summary>
        /// 归档日期
        /// </summary>
        public DateTime? Trrd_ArchiveDate { get; set; }
        [NPoco.Ignore]
        public string Trrd_Apply_Name{get;set;}

    }
}