﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbcCRM.Domain
{
    /// <summary>
    /// 反馈记录表
    /// </summary>
    [NPoco.TableName("FeedbackRecord")]
    [NPoco.PrimaryKey("Fdkr_ID", AutoIncrement = true)]
    public class FeedbackRecordDTO
    {
        #region 属性		
        /// <summary>
        /// 主键
        /// </summary>
        public int Fdkr_ID { get; set; }

        /// <summary>
        /// 签单LeadID
        /// </summary>
        public int? Fdkr_ContLeadID { get; set; }

        /// <summary>
        /// 合同订单号
        /// </summary>
        public int? Fdkr_ContOrderID { get; set; }
        /// <summary>
        /// 合同产品ID
        /// </summary>
        public int? Fdkr_ContProID { get; set; }
        /// <summary>
        /// 合同班号
        /// </summary>
        public int? Fdkr_ContClassID { get; set; }

        /// <summary>
        /// 合同中心ID
        /// </summary>
        public int Fdkr_ContBranID { get; set; }
        /// <summary>
        /// 签单CC
        /// </summary>
        public int Fdkr_ContSales { get; set; }
        /// <summary>
        /// 合同金额（订单内同班号的合同实收合计）
        /// </summary>
        public decimal? Fdkr_ContAmount { get; set; }

        /// <summary>
        /// 反馈数（暂时不用）
        /// </summary>
        public decimal? Fdkr_FeedBackNum { get; set; }

        /// <summary>
        /// 中心填报-推荐人
        /// </summary>
        public int? Fdkr_RefLeadID { get; set; }
        /// <summary>
        /// 中心填报-推荐人所属班级
        /// </summary>
        public int? Fdkr_RefClassID { get; set; }
        /// <summary>
        /// 中心填报-班级对于的中教
        /// </summary>
        public int? Fdkr_RefTeachID { get; set; }

        /// <summary>
        /// 中心填报-老师职位类型（全职，兼职）
        /// </summary>
        public int? Fdkr_TeachJobType { get; set; }
        /// <summary>
        /// 中心填报-中心反馈
        /// </summary>
        public int Fdkr_BranchFeedback { get; set; }
        /// <summary>
        /// 中心填报-中心反馈
        /// </summary>
        public string Fdkr_BranchRemark { get; set; }

        /// <summary>
        /// 总部-审核结果
        /// </summary>
        public int? Fdkr_CheckStatus { get; set; }
        /// <summary>
        /// 总部-审核备注
        /// </summary>
        public string Fdkr_CheckRemark { get; set; }
        /// <summary>
        /// 评级中反馈个数
        /// </summary>
        public decimal? Fdkr_LevelNum { get; set; }
        /// <summary>
        /// 月评中反馈个数
        /// </summary>
        public decimal? Fdkr_MonthNum { get; set; }
        /// <summary>
        /// 反馈奖金
        /// </summary>
        public decimal? Fdkr_Amount { get; set; }
        /// <summary>
        /// 反馈记录状态 0待提交，1审批中，2已审批,3驳回，-1驳回操作（操作状态）
        /// </summary>
        public int Fdkr_Status { get; set; }
        /// <summary>
        /// 创建人
        /// </summary>
        public int? Fdkr_CreatedBy { get; set; }
        /// <summary>
        /// 反馈生成时间-（默认订单启动时间）
        /// </summary>
        public DateTime? Fdkr_Date { get; set; }
        /// <summary>
        /// 创建时间
        /// </summary>
        public DateTime? Fdkr_CreatedDate { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public int? Fdkr_UpdatedBy { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public DateTime? Fdkr_UpdatedDate { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public int Fdkr_Deleted { get; set; }

        /// <summary>
        /// 反馈类型(1新生，2老生，3试听)
        /// </summary>
        public int? Fdkr_Type { get; set; }

        #endregion

        /// <summary>
        /// 操作状态 0保存，1驳回
        /// </summary>
        [NPoco.Ignore]
        public int Fdkr_OperationStatus { get; set; }

        /// <summary>
        /// 复制
        /// </summary>
        /// <returns></returns>
        public FeedbackRecordDTO Copy()
        {
            return (FeedbackRecordDTO)this.MemberwiseClone();
        }
    }
}
