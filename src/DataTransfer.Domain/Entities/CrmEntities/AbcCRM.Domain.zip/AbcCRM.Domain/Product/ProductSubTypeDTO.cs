﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbcCRM.Domain
{
    /// <summary>
    /// 产品大类
    /// </summary>
    [NPoco.TableName("ProductSubType")]
    [NPoco.PrimaryKey("Prost_ID", AutoIncrement = true)]
    public class ProductSubTypeDTO
    {
        /// <summary>
        /// 小类ID
        /// </summary>
        [NPoco.Column("Prost_ID")]
        public int Prost_ID { get; set; }
        /// <summary>
        /// 大类ID
        /// </summary>
        public int? Prot_ID { get; set; }
        /// <summary>
        /// 小类名称
        /// </summary>
        public string Prost_Name { get; set; }
        /// <summary>
        /// 时段类型
        /// </summary>
        public int? Clas_PeriodType { get; set; }
        /// <summary>
        /// 班级规模类型
        /// </summary>
        public int? Clas_ScaleType { get; set; }
        /// <summary>
        /// 班级教师类型
        /// </summary>
        public int? Clas_TeacherType { get; set; }
        /// <summary>
        /// 创建人
        /// </summary>
        public int? Prost_CreatedBy { get; set; }
        /// <summary>
        /// 创建时间
        /// </summary>
        public DateTime? Prost_CreatedDate { get; set; }
    }
}
