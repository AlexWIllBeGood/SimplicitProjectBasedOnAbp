﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbcCRM.Domain
{
    /// <summary>
    /// 产品级别
    /// </summary>
    [NPoco.TableName("ProductLevel")]
    [NPoco.PrimaryKey("Prol_ID", AutoIncrement = true)]
    public class ProductLevelDTO
    {
        public int Prol_ID { get; set; }

        public string Prol_Code { get; set; }

        public string Prol_Name { get; set; }

        /// <summary>
        /// 级别缩写
        /// </summary>
        public string Prol_Ab { get; set; }

        public int? Prol_CreatedBy { get; set; }

        [NPoco.Ignore]
        public string Prol_CreatedBy_Name { get; set; }

        public DateTime? Prol_CreatedDate { get; set; }

        public int? Prol_UpdatedBy { get; set; }

        [NPoco.Ignore]
        public string Prol_UpdatedBy_Name { get; set; }

        public DateTime? Prol_UpdatedDate { get; set; }

        public int Prol_Deleted { get; set; }
    }
}
