﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbcCRM.Domain.Model
{
    public class ProductTypeExDTO : ProductTypeDTO
    {
        /// <summary>
        /// 产品ID
        /// </summary>
        public int Prod_ProductID { get; set; }

    }
}
