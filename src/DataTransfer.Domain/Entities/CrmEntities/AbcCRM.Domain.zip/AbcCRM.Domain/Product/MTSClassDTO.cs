﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbcCRM.Domain.Product
{
    /// <summary>
    /// MTS课程信息
    /// </summary>
    [Serializable]
    public class ApiArgument_CrmClass
    {
        public ApiArgument_CrmClass()
        {
            students = new List<CrmClassStudent>();
        }
        /// <summary>
        /// 班级id
        /// </summary>
        public int classId { get; set; }
        /// <summary>
        /// 班级编号
        /// </summary>
        public string classNo { get; set; }
        /// <summary>
        /// 班级类型
        /// </summary>
        public string classType { get; set; }
        /// <summary>
        /// 班级名称
        /// </summary>
        public string className { get; set; }
        /// <summary>
        /// 中心
        /// </summary>
        public string branchName { get; set; }
        /// <summary>
        /// 产品名称
        /// </summary>
        public string productName { get; set; }
        /// <summary>
        /// 级别名称
        /// </summary>
        public string levelName { get; set; }
        /// <summary>
        /// 总课时数
        /// </summary>
        public int totalHours { get; set; }
        /// <summary>
        /// 已上课时数
        /// </summary>
        public int doneHours { get; set; }
        /// <summary>
        /// 班级人数
        /// </summary>
        public int stuCount { get; set; }
        /// <summary>
        /// 班级状态
        /// </summary>
        public int classStatus { get; set; }
        /// <summary>
        /// 是否延期
        /// </summary>
        public bool isDelay { get; set; }
        /// <summary>
        /// 待续费人数
        /// </summary>
        public int? maybeRenewCount { get; set; }

        /// <summary>
        /// 预开班时间
        /// </summary>
        [JsonIgnore]
        public DateTime? expectTime { get; set; }

        public string expectStartTime
        {
            get
            {
                if (!expectTime.HasValue)
                {
                    return string.Empty;
                }
                return expectTime.Value.ToString("yyyy-MM-dd HH:mm:ss");
            }
        }

        public string saUserName { get; set; }

        /// <summary>
        /// 开班时间
        /// </summary>
        [JsonIgnore]
        public DateTime? actualTime { get; set; }

        public string actualStartTime
        {
            get
            {
                if (!actualTime.HasValue)
                {
                    return string.Empty;
                }
                return actualTime.Value.ToString("yyyy-MM-dd HH:mm:ss");
            }
        }
        /// <summary>
        /// 创建时间
        /// </summary>

        [JsonIgnore]
        public DateTime? createTimeUse { get; set; }

        public string createTime
        {
            get
            {
                if (!createTimeUse.HasValue)
                {
                    return string.Empty;
                }
                return createTimeUse.Value.ToString("yyyy-MM-dd HH:mm:ss");
            }
        }

        /// <summary>
        /// 教室
        /// </summary>
        public int? classRoomId { get; set; }

        /// <summary>
        /// 教室最大容纳人数
        /// </summary>
        public int? classRoomMaxCapactity { get; set; } = -1;

        /// <summary>
        /// 状态
        /// </summary>
        [JsonIgnore]
        public int status { get; set; } = 101;

        /// <summary>
        /// 班级的学生列表
        /// </summary>
        public List<CrmClassStudent> students { get; set; }
    }
    /// <summary>
    /// 班级的学生列表
    /// </summary>
    [Serializable]
    public class CrmClassStudent
    {
        [JsonIgnore]
        public int classId { get; set; }
        /// <summary>
        /// Crm合同id
        /// </summary>
        public int crmContractId { get; set; }
        /// <summary>
        /// Crm合同号
        /// </summary>
        public string crmContractNum { get; set; }
        /// <summary>
        /// 学生中文名
        /// </summary>
        public string stuCname { get; set; }
        /// <summary>
        /// 学生中文名
        /// </summary>
        public string stuEname { get; set; }

        [JsonIgnore]
        public DateTime? createTime { get; set; }
        /// <summary>
        /// 入班时间
        /// </summary>
        public string stuJoinTime
        {

            get
            {
                if (!createTime.HasValue)
                {
                    return string.Empty;
                }
                return createTime.Value.ToString("yyyy-MM-dd HH:mm:ss");
            }
        }
    }
    /// <summary>
    /// 请求接口的参数
    /// </summary>
    [Serializable]
    public class SearchClassParam
    {
        /// <summary>
        /// 平台,101:青少,102:ABC
        /// </summary>
        public string platformKey { get; set; } = "";

        /// <summary>
        /// 级别CODE
        /// </summary>
        public string level { get; set; }
        /// <summary>
        /// 中心
        /// </summary>
        public int branchId { get; set; }
        /// <summary>
        /// CRM合同类型，对应MTS p_product 表中的crmProductId
        /// </summary>
        public int typeId { get; set; }
        /// <summary>
        /// 课程小类， 及1周末班 2 周中班
        /// </summary>
        public int typeSub { get; set; }
    }
    /// <summary>
    /// MTS返回实体
    /// </summary>
    public class MTSResponseEntity
    {
        /// <summary>
        /// 状态码
        /// </summary>
        public string ResultCode { get; set; }
        /// <summary>
        /// 状态信息
        /// </summary>
        public string ResultMessage { get; set; }
        ///// <summary>
        ///// 返回结果
        ///// </summary>
        public List<ApiArgument_CrmClass> ResultData { get; set; }
    }
}
