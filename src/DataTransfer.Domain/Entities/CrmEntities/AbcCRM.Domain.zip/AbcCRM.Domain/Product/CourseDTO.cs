﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbcCRM.Domain
{
    /// <summary>
    /// 课程
    /// </summary>
    [NPoco.TableName("Course")]
    [NPoco.PrimaryKey("Cour_ID")]
    public class CourseDTO
    {
        /// <summary>
        /// 自增主键
        /// </summary>
        public int Cour_ID { get; set; }

        /// <summary>
        /// 课程名称
        /// </summary>
        public string Cour_Name { get; set; }

        /// <summary>
        /// 排序
        /// </summary>
        public int Cour_Order { get; set; }

        /// <summary>
        /// 单节价格
        /// </summary>
        public decimal Cour_Price { get; set; }

        /// <summary>
        /// 单节时长
        /// </summary>
        public int? Cour_ClassTime { get; set; }

        /// <summary>
        /// 课程类型
        /// </summary>
        public int? Cour_Type { get; set; }

        /// <summary>
        /// 创建人
        /// </summary>
        public int Cour_CreatedBy { get; set; }

        /// <summary>
        /// 创建时间
        /// </summary>
        public DateTime Cour_CreatedDate { get; set; }

        /// <summary>
        /// 更新人
        /// </summary>
        public int? Cour_UpdatedBy { get; set; }

        /// <summary>
        /// 更新时间
        /// </summary>
        public DateTime? Cour_UpdatedDate { get; set; }

        /// <summary>
        /// 删除标志位
        /// </summary>
        public int Cour_Deleted { get; set; }
    }
}
