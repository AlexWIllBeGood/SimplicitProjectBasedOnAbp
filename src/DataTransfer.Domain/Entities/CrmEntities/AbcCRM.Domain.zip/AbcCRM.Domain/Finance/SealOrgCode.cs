﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbcCRM.Domain
{
    /// <summary>
    /// 主体与中心，产线关系表
    /// </summary>
    [NPoco.TableName("OrgCodeRelate")]
    [NPoco.PrimaryKey("Csea_ID", AutoIncrement = true)]
    public class SealOrgCode
    {
        /// <summary>
        /// 主键ID
        /// </summary>
        public int Csea_ID { get; set; }

        /// <summary>
        /// 关联类型 1、中心 2、产线
        /// </summary>
        public int Csea_Type { get; set; }

        /// <summary>
        /// 关联类型
        /// </summary>
        [NPoco.Ignore]
        public string Csea_Type_Name { get; set; }

        /// <summary>
        /// 中心ID
        /// </summary>
        public int Csea_Branch { get; set; }

        /// <summary>
        /// 中心
        /// </summary>
        [NPoco.Ignore]
        public string Csea_Branch_Name { get; set; }

        /// <summary>
        /// 产品类别ID
        /// </summary>
        public int Csea_ProductType { get; set; }

        /// <summary>
        /// 产品类别
        /// </summary>
        [NPoco.Ignore]
        public string Csea_ProductType_Name { get; set; }

        /// <summary>
        /// 主体ID
        /// </summary>
        public int Csea_OrgCode { get; set; }

        public DateTime? Csea_CreatedDate { get; set; }
        public int Csea_CreatedBy { get; set; }
        [NPoco.Ignore]
        public string Csea_CreatedBy_Name { get; set; }
        public DateTime? Csea_UpdatedDate { get; set; }
        public int Csea_UpdatedBy { get; set; }
        [NPoco.Ignore]
        public string Csea_UpdatedBy_Name { get; set; }
        public int Csea_Deleted { get; set; }
    }

    /// <summary>
    /// 主体视图
    /// </summary>
    [NPoco.TableName("VOrgCodeRelate")]
    public class SealOrgCodeShow : SealOrgCode
    {
        /// <summary>
        /// 主体名称
        /// </summary>
        public string Tcoc_Name { get; set; }

        /// <summary>
        /// 税务登记证号
        /// </summary>
        public string Tcoc_TaxCode { get; set; }
    }
}
