﻿using AbcCRM.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbcCRM.Domain
{
    /// <summary>
    /// 电子收据
    /// </summary>
    [NPoco.TableName("Receipt")]
    [NPoco.PrimaryKey("Rece_ID", AutoIncrement = true)]
    public class ReceiptDTO
    {
        /// <summary>
        /// 主键ID
        /// </summary>
        public int Rece_ID { get; set; }

        /// <summary>
        /// LeadID
        /// </summary>
        public int Rece_LeadID { get; set; }

        /// <summary>
        /// 学员姓名
        /// </summary>
        public string Rece_LeadName { get; set; }

        /// <summary>
        /// 学员邮箱
        /// </summary>
        [NPoco.Ignore]
        public string Rece_LeadEmail { get; set; }

        /// <summary>
        /// 关联的订单ID
        /// </summary>
        public int Rece_OrderID { get; set; }

        /// <summary>
        /// 订单号
        /// </summary>
        public string Rece_OrderNumber { get; set; }

        /// <summary>
        /// 重置收据关联的原收据
        /// </summary>
        public int? Rece_ParentID { get; set; }

        /// <summary>
        /// 重置收据关联的原收据号
        /// </summary>
        public string Rece_ParentNumber { get; set; }

        /// <summary>
        /// 收据类型 0 正常，1 重置
        /// </summary>
        public int Rece_Type { get; set; }

        /// <summary>
        /// 收据状态 0 待发送，1 已发送，2 作废
        /// </summary>
        public int Rece_Status { get; set; }

        /// <summary>
        /// 收据状态 0 待发送，1 已发送，2 作废
        /// </summary>
        [NPoco.Ignore]
        public string Rece_Status_Name { get; set; }

        /// <summary>
        /// 收据中心
        /// </summary>
        public int Rece_Branch { get; set; }

        /// <summary>
        /// 收据中心
        /// </summary>
        [NPoco.Ignore]
        public string Rece_Branch_Name { get; set; }

        /// <summary>
        /// 收据号
        /// </summary>
        public string Rece_Number { get; set; }

        /// <summary>
        /// 收据主体
        /// </summary>
        public int Rece_SealID { get; set; }

        /// <summary>
        /// 收据主体
        /// </summary>
        public string Rece_SealName { get; set; }

        /// <summary>
        /// 公章路径
        /// </summary>
        public string Rece_SealPath { get; set; }

        /// <summary>
        /// PDF文件名称
        /// </summary>
        public string Rece_FileName { get; set; }

        /// <summary>
        /// PDF地址
        /// </summary>
        public string Rece_Path { get; set; }

        /// <summary>
        /// Ftp地址
        /// </summary>
        public string Rece_FtpPath { get; set; }

        /// <summary>
        /// 发送次数
        /// </summary>
        public int Rece_SendNum { get; set; }

        /// <summary>
        /// 收据金额
        /// </summary>
        public decimal Rece_Amount { get; set; }

        /// <summary>
        /// 收据金额(大写)
        /// </summary>
        [NPoco.Ignore]
        public string Rece_Amount_CN { get; set; }

        /// <summary>
        /// 备注
        /// </summary>
        public string Rece_Remark { get; set; }

        /// <summary>
        /// 原收据作废信息
        /// </summary>
        public string Rece_ResetInfo { get; set; }

        /// <summary>
        /// 收款明细
        /// </summary>
        public string Rece_Accounts { get; set; }

        /// <summary>
        /// 收款明细
        /// </summary>
        [NPoco.Ignore]
        public List<ReceiptAccount> Rece_AccountList
        {
            get { return string.IsNullOrEmpty(Rece_Accounts) ? new List<ReceiptAccount>() : CommonHelper.JsonDeserialize<List<ReceiptAccount>>(Rece_Accounts); }
            set { Rece_Accounts = CommonHelper.JsonSerialize(value); }
        }

        public int Rece_CreatedBy { get; set; }

        [NPoco.Ignore]
        public string Rece_CreatedBy_Name { get; set; }

        public DateTime Rece_CreatedDate { get; set; }

        public int Rece_UpdatedBy { get; set; }

        [NPoco.Ignore]
        public string Rece_UpdatedBy_Name { get; set; }

        public DateTime Rece_UpdatedDate { get; set; }

        public int Rece_Deleted { get; set; }
    }

    /// <summary>
    /// 页面展示收款列表
    /// </summary>
    public class ReceiptAccount
    {
        public int Acrd_ID { get; set; }
        public string Acrd_Type { get; set; }
        public string Acrd_Way { get; set; }
        public decimal Acrd_Amount { get; set; }
        public string Acrd_Date { get; set; }
    }
}
