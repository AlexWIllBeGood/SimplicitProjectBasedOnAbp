﻿using System;

namespace AbcCRM.Domain
{
    /// <summary>
    /// POS设备中心配置
    /// </summary>
    [NPoco.TableName("PosConfig")]
    [NPoco.PrimaryKey("Posc_ID", AutoIncrement = true)]
    public class PosConfigDTO
    {
        /// <summary>
        /// 主键id
        /// </summary>
        public int Posc_ID { get; set; }

        /// <summary>
        /// POS机类型   
        /// </summary>
        public string Posc_PosType { get; set; }

        /// <summary>
        /// POS机名称
        /// </summary>
        public string Posc_PosName { get; set; }

        /// <summary>
        /// POS终端号
        /// </summary>
        public string Posc_PosNum { get; set; }

        /// <summary>
        /// 商户号
        /// </summary>
        public string Posc_MerchantId { get; set; }

        /// <summary>
        /// 密钥
        /// </summary>
        public string Posc_PrivateKey { get; set; }

        /// <summary>
        /// 机身号
        /// </summary>
        public string Posc_BodyNum { get; set; }

        /// <summary>
        /// 中心
        /// </summary>
        public int Posc_Branch { get; set; }

        /// <summary>
        /// 中心
        /// </summary>
        [NPoco.Ignore]
        public string Posc_BranchName { get; set; }

        /// <summary>
        /// 是否禁用
        /// </summary>
        public int Posc_Disabled { get; set; }

        /// <summary>
        /// 是否删除
        /// </summary>
        public int Posc_Deleted { get; set; }

        public int Posc_CreatedBy { get; set; }
        [NPoco.Ignore]
        public string Posc_CreatedBy_Name { get; set; }
        public DateTime Posc_CreatedDate { get; set; }
        public int Posc_UpdatedBy { get; set; }
        [NPoco.Ignore]
        public string Posc_UpdatedBy_Name { get; set; }
        public DateTime Posc_UpdatedDate { get; set; }
    }
}
