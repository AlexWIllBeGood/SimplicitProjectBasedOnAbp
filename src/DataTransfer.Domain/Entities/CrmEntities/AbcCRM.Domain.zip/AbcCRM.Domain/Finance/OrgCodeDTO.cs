﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbcCRM.Domain
{
    /// <summary>
    /// 财务税务主体表
    /// </summary>
    [NPoco.TableName("OrgCode")]
    [NPoco.PrimaryKey("Tcoc_ID", AutoIncrement = true)]
    public class OrgCodeDTO
    {
        /// <summary>
        /// 主键ID
        /// </summary>
        public int Tcoc_ID { get; set; }

        /// <summary>
        /// 主体名称
        /// </summary>
        public string Tcoc_Name { get; set; }

        /// <summary>
        /// 注册号
        /// </summary>
        public string Tcoc_IcCode { get; set; }

        /// <summary>
        /// 组织机构代码
        /// </summary>
        public string Tcoc_OrgCode { get; set; }

        /// <summary>
        /// 税务登记证号
        /// </summary>
        public string Tcoc_TaxCode { get; set; }

        /// <summary>
        /// 注册地址
        /// </summary>
        public string Tcoc_Address { get; set; }

        /// <summary>
        /// 注册人信息-联系人姓名
        /// </summary>
        public string Tcoc_LinkMan { get; set; }

        /// <summary>
        /// 注册人信息-联系方式
        /// </summary>
        public string Tcoc_LinkMobile { get; set; }

        /// <summary>
        /// 注册人信息-邮箱
        /// </summary>
        public string Tcoc_LinkEmail { get; set; }

        /// <summary>
        /// 注册人信息-身份证号
        /// </summary>
        public string Tcoc_LinkIDNum { get; set; }

        /// <summary>
        /// 公章图片路径
        /// </summary>
        public string Tcoc_SealPath { get; set; }

        /// <summary>
        /// 主体状态
        /// 0：启用
        /// 1：禁用
        /// </summary>
        public int Tcoc_Status { get; set; }

        /// <summary>
        /// 禁用状态
        /// </summary>
        [NPoco.Ignore]
        public string Tcoc_Status_Name { get; set; }

        /// <summary>
        /// CA申请状态
        /// </summary>
        [NPoco.Ignore]
        public string Tcoc_CAStatus_Name { get; set; }

        ///// <summary>
        ///// 公章CA账号
        ///// </summary>
        //public string Tcoc_Account { get; set; }

        ///// <summary>
        ///// 公章CA证书
        ///// </summary>
        //public string Tcoc_CerNo { get; set; }

        #region 发票相关
        ///// <summary>
        ///// 联系电话
        ///// </summary>
        //public string Tcoc_Tel { get; set; }

        ///// <summary>
        ///// 开户行
        ///// </summary>
        //public string Tcoc_Bank { get; set; }

        ///// <summary>
        ///// 开户行账号
        ///// </summary>
        //public string Tcoc_BankAccount { get; set; }

        ///// <summary>
        ///// 税目编码
        ///// </summary>
        //public string Tcoc_TaxArticleCode { get; set; }

        ///// <summary>
        ///// 商品名称
        ///// </summary>
        //public string Tcoc_TaxArticleName { get; set; }

        ///// <summary>
        ///// 税率
        ///// </summary>
        //public decimal Tcoc_TaxRate { get; set; }

        ///// <summary>
        ///// 是否0税率 0否 1是
        ///// </summary>
        //public int Tcoc_TaxIsZero { get; set; }

        ///// <summary>
        ///// 发票限额-普票
        ///// </summary>
        //public string Tcoc_TaxMax { get; set; }

        ///// <summary>
        ///// 发票限额-专票
        ///// </summary>
        //public string Tcoc_TaxMaxSpecial { get; set; }

        ///// <summary>
        ///// 税盘分号
        ///// </summary>
        //public string Tcoc_MachineNO { get; set; }

        ///// <summary>
        ///// 普票余量
        ///// </summary>
        //public string Tcoc_LimitOrd { get; set; }

        ///// <summary>
        ///// 专票余量
        ///// </summary>
        //public string Tcoc_LimitSpe { get; set; }

        ///// <summary>
        ///// 通知用户
        ///// </summary>
        //public string Tcoc_AlertUsers { get; set; }

        #endregion

        public DateTime? Tcoc_CreatedDate { get; set; }

        public int Tcoc_CreatedBy { get; set; }

        [NPoco.Ignore]
        public string Tcoc_CreatedBy_Name { get; set; }

        public DateTime? Tcoc_UpdatedDate { get; set; }

        public int Tcoc_UpdatedBy { get; set; }

        [NPoco.Ignore]
        public string Tcoc_UpdatedBy_Name { get; set; }

        public int Tcoc_Deleted { get; set; }
    }
}
