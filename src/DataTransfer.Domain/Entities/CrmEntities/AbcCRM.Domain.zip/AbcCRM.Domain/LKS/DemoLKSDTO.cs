﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbcCRM.Domain
{
    /// <summary>
    /// 立刻说回写Demo数据
    /// </summary>
    public class SyncLksDemo
    {
        /// <summary>
        /// 第三方Demo编码(DemoId)
        /// </summary>
        public string ThirdDemoCode { get; set; }

        /// <summary>
        /// 第三方Demo课堂编码(ArrangeCourseId)
        /// </summary>
        public string ThirdDemoArrangeCode { get; set; }

        /// <summary>
        /// 更新人(员工OA或学员ID)
        /// </summary>
        public string UpdateName { get; set; }

        /// <summary>
        /// 更新时间
        /// </summary>
        public DateTime? UpdateTime { get; set; }

        /// <summary>
        /// 请求备注
        /// </summary>
        public string RequestRemark { get; set; }

        /// <summary>
        /// 请求人
        /// </summary>
        public string RequestName { get; set; }

        /// <summary>
        /// 请求时间
        /// </summary>
        public DateTime? RequestTime { get; set; }

        /// <summary>
        /// 学员编号(手机号)
        /// </summary>
        public string StudentNo { get; set; }

        /// <summary>
        /// 状态
        /// </summary>
        public string State { get; set; }

        /// <summary>
        /// 上课时间
        /// </summary>
        public DateTime? ClassTime { get; set; }
        /// <summary>
        /// 课程主题
        /// </summary>
        public string Topic { get; set; }
        /// <summary>
        /// 教师类型
        /// </summary>
        public string TeachingObject { get; set; }
        /// <summary>
        /// 教师名字
        /// </summary>
        public string TeacherName { get; set; }

        /// <summary>
        /// 备注
        /// </summary>
        public string Remarks { get; set; }

        /// <summary>
        /// Demo创建时间
        /// </summary>
        public DateTime? CreateTime { get; set; }

        /// <summary>
        /// 课件名称
        /// </summary>
        public string Title { get; set; }

        /// <summary>
        /// 学员出席状态
        /// </summary>
        public string StudentAttendance { get; set; }

        /// <summary>
        /// 教师产线
        /// </summary>
        public string TeacherProductLine { get; set; }

        /// <summary>
        /// 教师出席状态
        /// </summary>
        public string TeacherAttendance { get; set; }

        /// <summary>
        /// 操作人类型
        /// </summary>
        public string OperatorNameType { get; set; }
    }
}
