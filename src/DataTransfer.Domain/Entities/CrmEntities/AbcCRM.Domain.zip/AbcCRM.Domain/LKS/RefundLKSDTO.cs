﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbcCRM.Domain
{
    /// <summary>
    /// 订单退费实体
    /// </summary>
    public class OrderRefundSycn
    {
        public string orderNo { get; set; }

        public string studentNo { get; set; }

        public string operationName { get; set; }

        public string remark { get; set; }

        public double refundAmount { get; set; }

        public List<ContarcntRefund> contractList { get; set; }

        public List<RefundOrder> payRecordList { get; set; }

        public DateTime createDate { get; set; }


    }

    /// <summary>
    /// 退费流水
    /// </summary>
    public class RefundOrder
    {


        /// <summary>
        ///方式  网银支付101,微信支付 102,支付宝 103,银行汇款104,中心支付105,银行分期106,其他支付107,
        /// </summary>
        public int paymentType { get; set; }

        public DateTime? payTime { get; set; }


        public decimal refundAmount { get; set; }

        /// <summary>
        /// 第三方支付平台编号
        /// </summary>
        public string thirdPlatformTradeNo { get; set; }

        /// <summary>
        /// 银行名称
        /// </summary>
        public string bankName { get; set; }


        /// <summary>
        /// 备注
        /// </summary>
        public string remark { get; set; }


        public string OrderPaymentNo { get; set; }
    }


    /// <summary>
    /// 合同退费
    /// </summary>
    public class ContarcntRefund
    {
        public string contractNo { get; set; }

        public double refundAmount { get; set; }

    }

    

}
