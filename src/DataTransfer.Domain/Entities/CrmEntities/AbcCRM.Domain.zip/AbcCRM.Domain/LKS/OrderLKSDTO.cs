﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace AbcCRM.Domain
{
    /// <summary>
    /// 立刻说平台回写订单实体
    /// </summary>
    public class OrderLKSSyncDTO
    {
        /// <summary>
        /// 订单号
        /// </summary>
        [Required(ErrorMessage = "订单号不能为空")]
        public string OrderNumber { get; set; }
        /// <summary>
        /// 订单金额
        /// </summary>
        [Required(ErrorMessage = "订单金额不能为空")]
        public decimal? OrderAmount { get; set; }
        /// <summary>
        /// 订单应收
        /// </summary>
        [Required(ErrorMessage = "应收金额不能为空")]
        public decimal AccountReceivable { get; set; }
        /// <summary>
        /// 手续费
        /// </summary>
        [Required(ErrorMessage = "手续费不能为空")]
        public decimal? OrderFee { get; set; }
        /// <summary>
        /// 优惠金额
        /// </summary>
        [Required(ErrorMessage = "优惠金额不能为空")]
        public decimal? OfferAmount { get; set; }
        /// <summary>
        /// 折扣率
        /// </summary>
        [Required(ErrorMessage = "折扣率不能为空")]
        public decimal? DiscountRate { get; set; }
        /// <summary>
        /// 折扣金额
        /// </summary>
        [Required(ErrorMessage = "折扣金额不能为空")]
        public decimal? DiscountAmount { get; set; }
        /// <summary>
        /// 代金券
        /// </summary>
        [Required(ErrorMessage = "代金券不能为空")]
        public decimal? VouchersAmount { get; set; }
        /// <summary>
        /// 学习时间（天数）
        /// </summary>
        [Required(ErrorMessage = "学习时间不能为空")]
        public int? StudyDate { get; set; }
        /// <summary>
        /// 产线
        /// </summary>
        [Required(ErrorMessage = "产线不能为空")]
        public int? ProductLineCode { get; set; }
        /// <summary>
        /// 产线
        /// </summary>
        [Required(ErrorMessage = "产线不能为空")]
        public string ProductLine { get; set; }
        /// <summary>
        /// 备注
        /// </summary>
        [Required(ErrorMessage = "备注不能为空")]
        public string Remark { get; set; }
        /// <summary>
        /// 立刻说产品明细
        /// </summary>
        public List<LksContDetail> ContList { get; set; }


    }
    /// <summary>
    /// 立刻说合同产品明细
    /// </summary>
    public class LksContDetail
    {
        /// <summary>
        /// 合同号
        /// </summary>
        public string ContNumber { get; set; }
        /// <summary>
        /// 产品名称
        /// </summary>
        public string ProductName { get; set; }
        /// <summary>
        /// 产品Code
        /// </summary>
        public string ProductNo { get; set; }
        /// <summary>
        /// 产线名称
        /// </summary>
        public string ProductType { get; set; }
        /// <summary>
        /// 数量
        /// </summary>
        public int Quantity { get; set; }
        /// <summary>
        /// 合同金额
        /// </summary>
        public decimal ContAmount { get; set; }
        /// <summary>
        /// 合同状态
        /// </summary>
        public string ContStatus { get; set; }
        /// <summary>
        /// 开始时间
        /// </summary>
        public DateTime? ContBegDate { get; set; }
        /// <summary>
        /// 结束时间
        /// </summary>
        public DateTime? ContEndDate { get; set; }
        /// <summary>
        /// 合同服务期（合同总天数）
        /// </summary>
        public int ContStudyDate { get; set; }
    }

    /// <summary>
    /// 订单合同变更实体
    /// </summary>
    public class OrderLKSUpdate
    {
        /// <summary>
        /// 合同列表
        /// </summary>
        public List<ContarcntUpdateSycn> data { get; set; }
        /// <summary>
        /// 状态
        /// </summary>
        public int status { get; set; }
    }
    /// <summary>
    /// 启动/终止合同列表
    /// </summary>
    public class ContarcntUpdateSycn
    {

        /// <summary>
        /// 合同号
        /// </summary>
        public string contractNo { get; set; }
        /// <summary>
        /// 订单号
        /// </summary>
        public string orderNo { get; set; }

        /// <summary>
        ///开始时间
        /// </summary>
        public DateTime? beginTime { get; set; }

        /// <summary>
        /// 结束的时间
        /// </summary>
        public DateTime? endTime { get; set; }


        /// <summary>
        /// 操作人
        /// </summary>
        public string operationName { get; set; }

        /// <summary>
        /// 操作时间
        /// </summary>
        public DateTime? operationTime { get; set; }

        /// <summary>
        /// 合同状态
        /// </summary>
        public int status { get; set; }
        /// <summary>
        /// 合同状态
        /// </summary>
        public string statusName { get; set; }

        /// <summary>
        /// 冻结的开始时间
        /// </summary>
        public DateTime? frozenBeginTime { get; set; }

        /// <summary>
        /// 冻结结束的时间
        /// </summary>
        public DateTime? frozenEndTime { get; set; }

        /// <summary>
        /// 原合同开始时间
        /// </summary>
        public DateTime? originalBeginDate { get; set; }

        /// <summary>
        /// 原合同结束时间
        /// </summary>
        public DateTime? originalEndDate { get; set; }

    }

    /// <summary>
    /// 立刻说自主生成订单同步实体
    /// </summary>
    public class OrderLksCreated
    {
    
        /// <summary>
        /// 应收金额
        /// </summary>
        public double accountReceivable { get; set; }

        /// <summary>
        /// 订单号
        /// </summary>
        public string orderNo { get; set; }

        /// <summary>
        ///合同号
        /// </summary>
        public string contractNo { get; set; }

        /// <summary>
        /// 合同产线
        /// </summary>
        public string contractProductLine { get; set; }

        /// <summary>
        /// 合同产品
        /// </summary>
        public string contractProductName { get; set; }

        public string Mobile { get; set; }

        public string beginTime { get; set; }

        public string endTime { get; set; }

        public string operationTime { get; set; }

        /// <summary>
        /// 操作人
        /// </summary>
        public string operationName { get; set; }

        /// <summary>
        /// 金额
        /// </summary>
        public double total { get; set; }

        /// <summary>
        /// 实收金额
        /// </summary>
        public double receivableAmount { get; set; }

        /// <summary>
        /// 线上Cc
        /// </summary>
        public string onLineCcName { get; set; }

        /// <summary>
        /// 线上Sa
        /// </summary>
        public string onLineSaName { get; set; }

        public DateTime signUpTime { get; set; }
    }

    /// <summary>
    /// 立刻说平台新增延时卡合同实体
    /// </summary>
    public class ContLksYSK
    {
        /// <summary>
        /// 延时卡订单号
        /// </summary>
        [Required(ErrorMessage = "延时卡订单号不能为空")]
        public string OrderNumber { get; set; }

        /// <summary>
        /// 关联的合同号
        /// </summary>
        [Required(ErrorMessage = "关联合同号不能为空")]
        public string ContNumber { get; set; }

        /// <summary>
        /// 金额
        /// </summary>
        public decimal ContAmount { get; set; }

        /// <summary>
        /// CC
        /// </summary>
        public string CCName { get; set; }

        /// <summary>
        /// SA
        /// </summary>
        public string SAName { get; set; }

        /// <summary>
        /// 签订时间
        /// </summary>
        public DateTime? ContSignDate { get; set; }

        /// <summary>
        /// 产品
        /// </summary>
        [Required(ErrorMessage = "产品不能为空")]
        public string ProductName { get; set; }

        /// <summary>
        /// 产品列表
        /// </summary>
        public List<ContLksPro> ContProList { get; set; }
        /// <summary>
        /// 操作人    ABC立刻说合同必填
        /// </summary>
        public string OperationName { get; set; }
    }

    /// <summary>
    /// 立刻说延时卡订单对应的产品
    /// </summary>
    public class ContLksPro
    {
        /// <summary>
        /// 产品名称
        /// </summary>
        public string ProductName { get; set; }

        /// <summary>
        /// 产品金额
        /// </summary>
        public decimal ProductAmount { get; set; }

        /// <summary>
        /// 产品Code
        /// </summary>
        public string ProductCode { get; set; }

        /// <summary>
        /// 产线类型
        /// </summary>
        public string ProductType { get; set; }

        /// <summary>
        /// 产品数量
        /// </summary>
        public int Quantity { get; set; }
    }

    /// <summary>
    /// CC账号
    /// </summary>
    public class OrderLksCC
    {
        public string Mobile { get; set; }
        public string CcOa { get; set; }
    }
}
