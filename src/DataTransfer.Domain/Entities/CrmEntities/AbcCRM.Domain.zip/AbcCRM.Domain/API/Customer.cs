﻿using System;
using System.ComponentModel.DataAnnotations;

namespace AbcCRM.Domain
{
    /// <summary>
    /// 客户信息（对外实体）
    /// </summary>
    [NPoco.TableName("Customer")]
    [NPoco.PrimaryKey("Excu_ID", AutoIncrement = true)]
    public class Customer
    {
        /// <summary>
        /// 主键
        /// </summary>
        public int Excu_ID { get; set; }

        /// <summary>
        /// 同步状态
        /// </summary>
        public string Excu_Status { get; set; }

        /// <summary>
        /// 客户姓名
        /// </summary>
        [Required(ErrorMessage = "客户姓名不能为空")]
        public string Excu_Name { get; set; }

        /// <summary>
        /// 客户性别
        /// </summary>
        [Required(ErrorMessage = "客户性别不能为空")]
        public int? Excu_Gender { get; set; }

        /// <summary>
        /// 客户年龄
        /// </summary>
        public int? Excu_Age { get; set; }

        /// <summary>
        /// 客户手机
        /// </summary>
        [Required(ErrorMessage = "客户手机不能为空")]
        public string Excu_Mobile { get; set; }
        /// <summary>
        /// 中心
        /// </summary>
        public int? Excu_City { get; set; }
        /// <summary>
        /// 意向中心
        /// </summary>
        public int? Excu_IntendedBranID { get; set; }
        /// <summary>
        /// 推广点
        /// </summary>
        [Required(ErrorMessage = "推广点不能为空")]
        public int? Excu_MChannelID { get; set; }

        /// <summary>
        /// 来源
        /// </summary>
        public int? Excu_Source { get; set; }

        /// <summary>
        /// 网络二级推广单元
        /// </summary>
        public string Excu_SupportSecond { get; set; }

        /// <summary>
        /// 网络三级推广单元
        /// </summary>
        public string Excu_SupportThird { get; set; }

        /// <summary>
        /// 网络四级推广/网络关键词
        /// </summary>
        public string Excu_KeyWord { get; set; }

        /// <summary>
        /// 备注
        /// </summary>
        public string Excu_Remarks { get; set; }

        /// <summary>
        /// 感兴趣的课程
        /// </summary>
        public int? Excu_IntendedCourse { get; set; }

        [Required(ErrorMessage = "操作人不能为空")]
        public string Excu_Operator { get; set; }

        public int Excu_OperatorUserID { get; set; }

        public string Excu_Promoter { get; set; }

        public int? Excu_CreatedBy { get; set; }

        public DateTime? Excu_CreatedDate { get; set; }

        public int? Excu_UpdatedBy { get; set; }

        public DateTime? Excu_UpdatedDate { get; set; }

        public int Excu_Deleted { get; set; }

        /// <summary>
        /// 会员ID
        /// </summary>
        public string Excu_MemberID { get; set; }

        /// <summary>
        /// 注册时间
        /// </summary>
        public DateTime? Excu_RegisterDate { get; set; }

        /// <summary>
        /// offer
        /// </summary>
        public string Excu_Offer { get; set; }

        /// <summary>
        /// 网络客服
        /// </summary>
        public string Excu_CustomerService { get; set; }

        /// <summary>
        /// 外系统Lead主键ID
        /// </summary>
        public int Excu_LeadID { get; set; }

        /// <summary>
        /// 本系统LeadID
        /// </summary>
        public int Excu_SysLeadID { get; set; }

        /// <summary>
        /// 推荐学员ID
        /// </summary>
        public int? Excu_RenewBy { get; set; }

        /// <summary>
        /// 老学员手机号
        /// </summary>
        public string Excu_RenewMobile { get; set; }

        /// <summary>
        /// 分享报备CC
        /// </summary>
        public string Excu_CC { get; set; }

        /// <summary>
        /// 分享报备SA
        /// </summary>
        public string Excu_SA { get; set; }

    }
}
