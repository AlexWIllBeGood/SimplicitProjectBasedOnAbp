﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbcCRM.Domain
{
    /// <summary>
    /// 同步记录表
    /// </summary>
    [NPoco.TableName("SysSyncLog")]
    [NPoco.PrimaryKey("Sys_ID", AutoIncrement = true)]
    public class SysSyncLog
    {
        /// <summary>
        /// 自增主键
        /// </summary>
        public int Sys_ID { get; set; }

        /// <summary>
        /// 系统名称
        /// </summary>
        public string Sys_Name { get; set; }

        /// <summary>
        /// 请求URL
        /// </summary>
        public string Sys_Url { get; set; }

        /// <summary>
        /// 请求方式
        /// </summary>
        public int Sys_RequestType { get; set; }

        /// <summary>
        /// 请求内容
        /// </summary>
        public string Sys_Request { get; set; }

        /// <summary>
        /// 返回内容
        /// </summary>
        public string Sys_Response { get; set; }

        /// <summary>
        /// 是否成功
        /// </summary>
        public int Sys_IsSucc { get; set; }

        /// <summary>
        /// 发送时间
        /// </summary>
        public DateTime Sys_SendTime { get; set; }
        /// <summary>
        /// 同步类型
        /// </summary>
        public string Sys_SyncType { get; set; }
        /// <summary>
        /// 关联的数据ID
        /// </summary>
        public int Sys_Key { get; set; }
    }
}
