﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbcCRM.Domain.Enums
{
    public enum IDTypeEnum
    {
        [Description("身份证")]
        身份证 = 1,

        [Description("护照")]
        护照 = 2,
    }
}
