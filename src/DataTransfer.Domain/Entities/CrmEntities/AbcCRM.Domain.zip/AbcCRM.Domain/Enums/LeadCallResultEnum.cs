﻿//using System;
//using System.Collections.Generic;
//using System.ComponentModel;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//namespace AbcCRM.Domain.Enums
//{
//    ///// <summary>
//    ///// 电话结果
//    ///// </summary>
//    //public enum LeadCallResultEnum
//    //{
//    //    [Description("新线索")]
//    //    新线索 = 1,

//    //    [Description("报名其它机构")]
//    //    报名其它机构 = 2,

//    //    [Description("潜在客户")]
//    //    潜在客户 = 3,

//    //    [Description("优质客户")]
//    //    优质客户 = 4,

//    //    [Description("距离太远")]
//    //    距离太远 = 5,

//    //    [Description("无人接听")]
//    //    无人接听 = 6,

//    //    [Description("三访无人接听")]
//    //    三访无人接听 = 7,

//    //    [Description("挂断")]
//    //    挂断 = 8,

//    //    [Description("三访挂断")]
//    //    三访挂断 = 9,

//    //    [Description("无效资源")]
//    //    无效资源 = 10,

//    //    [Description("拒绝")]
//    //    拒绝 = 11,

//    //    [Description("冻结资源")]
//    //    冻结资源 = 12,
//    //}

//    ///// <summary>
//    ///// 咨询结果
//    ///// </summary>
//    //public enum LeadConsultResultEnum
//    //{
//    //    [Description("空号、错号、停机")]
//    //    空号 = 1,

//    //    [Description("无法到京学习")]
//    //    无法到京学习 = 2,

//    //    [Description("接通挂断")]
//    //    接通挂断 = 3,

//    //    [Description("明确表示没注册")]
//    //    明确表示没注册 = 4,

//    //    [Description("年龄不符")]
//    //    年龄不符 = 5,

//    //    [Description("九访无人接听")]
//    //    九访无人接听 = 6,

//    //    [Description("无人接听")]
//    //    无人接听 = 7,

//    //    [Description("半年内无意向")]
//    //    半年内无意向 = 8,

//    //    [Description("需二次预约")]
//    //    需二次预约 = 9,

//    //    [Description("距离过远")]
//    //    距离过远 = 10,

//    //    [Description("潜在客户")]
//    //    潜在客户 = 11,
//    //}
//}
