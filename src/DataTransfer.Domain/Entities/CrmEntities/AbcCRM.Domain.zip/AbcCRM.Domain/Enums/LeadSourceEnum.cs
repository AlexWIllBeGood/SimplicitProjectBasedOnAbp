﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbcCRM.Domain.Enums
{
    public enum LeadSourceEnum
    {
        [Description("T-Out")]
        TOut = 1,

        [Description("T-In")]
        TIn = 2,

        [Description("Walk-In")]
        WalkIn = 3,

        [Description("P-Walk-In")]
        PWalkIn = 4,

        [Description("Call-Out")]
        CallOut = 5,    
    }
}
