﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbcCRM.Domain.Enums
{
    /// <summary>
    /// 记录类型
    /// </summary>
    public enum CommTypeEnum
    {
        [Description("跟进记录")]
        跟进记录 = 1,

        [Description("备注记录")]
        备注记录 = 2,
    }
}
