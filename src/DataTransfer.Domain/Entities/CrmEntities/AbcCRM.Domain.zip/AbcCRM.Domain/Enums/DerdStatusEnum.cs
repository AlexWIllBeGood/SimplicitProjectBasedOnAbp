﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbcCRM.Domain.Enums
{
    public enum DerdStatusEnum
    {
        [Description("未使用")]
        未使用 = 0,

        [Description("使用中")]
        使用中 = 1,

        [Description("已使用")]
        已使用 = 2,
    }

    public enum FdkcTypeEnum
    {
        [Description("新生")]
        新生 = 1,

        [Description("老生")]
        老生 = 2,

        [Description("试听")]
        试听 = 3,
    }

}
