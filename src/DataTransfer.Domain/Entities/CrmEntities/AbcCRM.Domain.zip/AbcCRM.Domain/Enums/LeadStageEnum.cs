﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbcCRM.Domain.Enums
{
    public enum LeadStageEnum
    {
        [Description("TMK跟进")]
        TMK跟进 = 1,

        [Description("已到访")]
        已到访 = 2,

        [Description("CC跟进")]
        CC跟进 = 3,
    }
}
