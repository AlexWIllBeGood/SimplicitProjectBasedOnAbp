﻿//using System;
//using System.Collections.Generic;
//using System.ComponentModel;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//namespace AbcCRM.Domain.Enums
//{
//    /// <summary>
//    /// 分配日志类型
//    /// </summary>
//    public enum DistributeLogTypeEnum
//    {
//        [Description("新单")]
//        新单 = 1,

//        [Description("分配")]
//        分配 = 2,

//        [Description("回收")]
//        回收 = 3,

//        [Description("放弃")]
//        放弃 = 4,
//    }
//}
