﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbcCRM.Domain.Enums
{
    public enum LeadStatusEnum
    {
        [Description("CC待分配")]
        CC待分配 = 1,

        [Description("CC跟进中")]
        CC跟进中 = 2,

        [Description("已签单")]
        已签单 = 3,
    }

    public enum LeadStatusTMKEnum
    {
        [Description("TMK待分配")]
        TMK待分配 = 1,

        [Description("TMK待跟进")]
        TMK待跟进 = 2,

        [Description("TMK跟进中")]
        TMK跟进中 = 3,

        [Description("TMK已预约")]
        TMK已预约 = 4,

        [Description("TMK判无效")]
        TMK判无效 = 5,
    }
}
