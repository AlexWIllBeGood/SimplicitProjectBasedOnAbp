﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbcCRM.Domain.Enums
{
    /// <summary>
    /// 排班状态(排课状态)
    /// </summary>
    public enum ClscStatusEnum
    {
        /// <summary>
        /// 待上课
        /// </summary>
        [Description("待上课")]
        待上课 = 0,

        /// <summary>
        /// 已上课
        /// </summary>
        [Description("已上课")]
        已上课 = 1,

        /// <summary>
        /// 已上课
        /// </summary>
        [Description("已取消")]
        已取消 = 2,

    }

    /// <summary>
    /// 排班状态(排课状态)
    /// </summary>
    public enum ClriStatusEnum
    {
        /// <summary>
        /// 待上课
        /// </summary>
        [Description("待上课")]
        待上课 = 0,

        /// <summary>
        /// 已上课
        /// </summary>
        [Description("已上课")]
        已上课 = 1,

        /// <summary>
        /// 请假
        /// </summary>
        [Description("请假")]
        请假 = 2,

        /// <summary>
        /// 已上课
        /// </summary>
        [Description("取消")]
        取消 = 3,

    }

    public enum ClstStatusEnum
    {
        /// <summary>
        /// 待上课
        /// </summary>
        [Description("待上课")]
        待上课 = 0,

        /// <summary>
        /// 上课中
        /// </summary>
        [Description("上课中")]
        上课中 = 1,

        /// <summary>
        /// 正常完结
        /// </summary>
        [Description("正常完结")]
        正常完结 = 2,

        /// <summary>
        /// 变更审核中
        /// </summary>
        [Description("变更审核中")]
        变更审核中 = 3,

        /// <summary>
        /// 已停课
        /// </summary>
        [Description("已停课")]
        已停课 = 4,

        /// <summary>
        /// 转班完结
        /// </summary>
        [Description("转班完结")]
        转班完结 = 5,

        /// <summary>
        /// 退费完结
        /// </summary>
        [Description("退费完结")]
        退费完结 = 6
    }

}
