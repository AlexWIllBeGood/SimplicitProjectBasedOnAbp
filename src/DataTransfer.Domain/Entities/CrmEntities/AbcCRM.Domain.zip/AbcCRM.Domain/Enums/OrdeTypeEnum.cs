﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbcCRM.Domain.Enums
{
    /// <summary>
    /// 订单类型
    /// </summary>
    public enum OrdeTypeEnum
    {
        [Description("定金")]
        定金 = 0,

        [Description("正式合同")]
        正式合同 = 1,
    }
}
