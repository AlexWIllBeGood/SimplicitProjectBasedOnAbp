﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//namespace AbcCRM.Domain.EAS
//{
//    /// <summary>
//    /// 返回值
//    /// </summary>
//    public class ResponseResult
//    {
//        /// <summary>
//        /// 请求是否成功
//        /// </summary>
//        public bool isSuccess { get; set; }

//        /// <summary>
//        /// 请求返回代码
//        /// </summary>
//        public int code { get; set; }

//        /// <summary>
//        /// 请求结果信息
//        /// </summary>
//        public string msg { get; set; }

//        /// <summary>
//        /// 具体数据
//        /// </summary>
//        public Object data { get; set; }
//    }
//}
