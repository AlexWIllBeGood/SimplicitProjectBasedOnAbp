﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;


//namespace AbcCRM.Domain.EAS
//{
//    public class StudentModelEx: StudentModel
//    {

//        public List<object> classStudents { get; set; }

//        public List<object> classScheduleStudents { get; set; }

//        public List<object> parentStudents { get; set; }

//        public List<object> classes { get; set; }

//        public List<object> classSchedules { get; set; }

//        public List<object> parents { get; set; }

//    }
//}
