﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbcCRM.Domain.EAS
{
    /// <summary>
    /// 课程进度信息
    /// </summary>
    public class ClassTimeScheduleModel
    {
        /// <summary>
        /// 总进度数
        /// </summary>
        public int TotalNumber { get; set; }

        /// <summary>
        /// 已完成进度数
        /// </summary>
        public int FinishNumber { get; set; }

    }

}
