﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbcCRM.Domain.EAS
{
    /// <summary>
    /// 排课信息
    /// </summary>
    public class ArrangingInfo
    {
        /// <summary>
        /// 排课信息
        /// </summary>
        public ClassScheduleEx ClassScheduleEx { get; set; }

        /// <summary>
        /// 排课学生
        /// </summary>
        public List<int> Students { get; set; }
    }

}
