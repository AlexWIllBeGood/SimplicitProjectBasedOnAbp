﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbcCRM.Domain.EAS
{
    /// <summary>
    /// 中心信息
    /// </summary>
    public class BranchInfoModel
    {
        /// <summary>
        /// 中心ID
        /// </summary>
        public int ID { get; set; }

        /// <summary>
        /// 父级
        /// </summary>
        public int? ParentID { get; set; }

        /// <summary>
        /// 区域编码
        /// </summary>
        public string Code { get; set; }

        /// <summary>
        /// 区域名称
        /// </summary>
        public string Name { get; set; }
        /// <summary>
        /// 区域简写
        /// </summary>
        public string ShortName { get; set; }

        /// <summary>
        /// 区域缩写
        /// </summary>
        public string Ab { get; set; }

        /// <summary>
        /// 深度(总公司1，区域公司2，分校3)
        /// </summary>
        public int Depth { get; set; }

        /// <summary>
        /// 创建人ID
        /// </summary>
        public int? CreatedBy { get; set; }

        /// <summary>
        /// 创建时间
        /// </summary>
        public DateTime? CreatedDate { get; set; }

        /// <summary>
        /// 更新人ID
        /// </summary>
        public int? UpdatedBy { get; set; }

        /// <summary>
        /// 更新时间
        /// </summary>
        public DateTime? UpdatedDate { get; set; }

        /// <summary>
        /// 是否删除
        /// </summary>
        public int Deleted { get; set; }
    }
}
