﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//namespace AbcCRM.Domain.EAS
//{
//    /// <summary>
//    /// 修改教师信息实体
//    /// </summary>
//    public class EditTeacherModel
//    {
//        /// <summary>
//        /// 教师Id 
//        /// </summary>
//        public int bindingId { get; set; }

//        /// <summary>
//        /// 修改内容json（要修改什么就传什么）
//        /// </summary>
//        public string teacher { get; set; }
//    }
//}
