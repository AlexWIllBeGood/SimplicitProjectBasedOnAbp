﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbcCRM.Domain.EAS
{
    /// <summary>
    /// 班级实体
    /// </summary>
    public class ClassModel
    {
        /// <summary>
        /// 班级CRMId 
        /// </summary>
        public int bindingId { get; set; }

        /// <summary>
        /// 创建时间 
        /// </summary>
        public DateTime createTime { get; set; }

        /// <summary>
        /// 更新时间
        /// </summary>
        public DateTime updateTime { get; set; } 

        /// <summary>
        /// 开始时间 
        /// </summary>
        public DateTime startTime { get; set; }

        /// <summary>
        /// 班级状态 (0 = 准备（对应我们的0和1） , 1 = 开班（对应我们的2）, 2 = 结束（对应我们的3）) 
        /// </summary>
        public int classStatus { get; set; }

        /// <summary>
        /// 班号
        /// </summary>
        public string classCode { get; set; }

        /// <summary>
        /// 班级所在中心
        /// </summary>
        public int classBranID { get; set; }

        /// <summary>
        /// 班级级别 
        /// </summary>
        public int level { get; set; }

        /// <summary>
        /// 级别编码
        /// </summary>
        public string levelCode { get; set; }

        /// <summary>
        /// 类别编码
        /// </summary>
        public string productTypeCode { get; set; }
    }
}
