﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//namespace AbcCRM.Domain.EAS
//{
//    /// <summary>
//    /// 教师实体
//    /// </summary>
//    public class TeacherModel
//    {
//        /// <summary>
//        /// 是否在职
//        /// </summary>
//        public bool inPosition { get; set; }

//        /// <summary>
//        /// 教师类型 (0 = ForeignTeacher(外教) , 1 = LocalTeacher(中教) ,2=助教) 
//        /// </summary>
//        public int teacherType { get; set; }

//        /// <summary>
//        /// CMR 教师Id 
//        /// </summary>
//        public int bindingId { get; set; }

//        /// <summary>
//        /// 员工编号
//        /// </summary>
//        public string number { get; set; }

//        /// <summary>
//        /// 中文名
//        /// </summary>
//        public string cnName { get; set; }

//        /// <summary>
//        /// 英文名
//        /// </summary>
//        public string enName { get; set; }


//        /// <summary>
//        /// 用户名
//        /// </summary>
//        public string userName { get; set; }

//        /// <summary>
//        /// 密码
//        /// </summary>
//        public string password { get; set; }

//        /// <summary>
//        /// 手机号
//        /// </summary>
//        public string mobile { get; set; }

//        /// <summary>
//        /// 用户头像
//        /// </summary>
//        public string profilePhoto { get; set; }

//        /// <summary>
//        /// 用户状态 (0 = None(无) , 1 = Active(激活) , 2 = Suspended(暂停使用) , 3 = Deleted(已删除) )
//        /// </summary>
//        public int userStatus { get; set; }

//        /// <summary>
//        /// 邮箱
//        /// </summary>
//        public string email { get; set; }

//        /// <summary>
//        /// 创建时间
//        /// </summary>
//        public DateTime createTime { get; set; }

//        /// <summary>
//        /// 更新时间
//        /// </summary>
//        public DateTime updateTime { get; set; }

//        /// <summary>
//        /// 班级
//        /// </summary>
//        public List<int> classIDs { get; set; }

//        /// <summary>
//        /// 中心
//        /// </summary>
//        public int branID { get; set; }

//        public string sapPositionsStr { get; set; }
//    }
//}
