﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbcCRM.Domain.EAS
{
    /// <summary>
    /// 排课信息
    /// </summary>
    public class ClassScheduleEx
    {
        /// <summary>
        /// 序号
        /// </summary>
        public int No { get; set; }


        /// <summary>
        /// 排课ID
        /// </summary>
        public int ClscID { get; set; }

        /// <summary>
        /// 上课日期
        /// </summary>
        public DateTime ClassDate { get; set; }

        /// <summary>
        /// 班号
        /// </summary>
        public string ClassCode { get; set; }
        /// <summary>
        /// 课程名称
        /// </summary>
        public string CourseTitle { get; set; }
        /// <summary>
        /// 所属班级ID
        /// </summary>
        public int ClassID { get; set; }

        /// <summary>
        /// 上课开始时间（带日期+时间）
        /// </summary>
        public DateTime BeginDate { get; set; }

        /// <summary>
        /// 上课结束时间（带日期+时间）
        /// </summary>
        public DateTime EndDate { get; set; }

        /// <summary>
        /// 班型人数(定课人数)
        /// </summary>
        public int Number { get; set; }

        /// <summary>
        /// 状态代码（0待上课，1已上课，2已取消）
        /// </summary>
        public int Status { get; set; }

        /// <summary>
        /// 班型时长（课时）
        /// </summary>
        public int ClassTime { get; set; }

        /// <summary>
        /// 上课老师（中教）
        /// </summary>
        public int LT { get; set; }

        /// <summary>
        /// 上课老师（中教编号）
        /// </summary>
        public string LTNumber { get; set; }

        /// <summary>
        /// 中教课时（单节时长）
        /// </summary>
        public int LTClassTime { get; set; }

        /// <summary>
        /// 助教
        /// </summary>
        public int? Sa { get; set; }

        /// <summary>
        /// 助教编号
        /// </summary>
        public string SaNumber { get; set; }

        /// <summary>
        /// 外教课时（单节时长）
        /// </summary>
        public int FTClassTime { get; set; }

        /// <summary>
        /// 外教
        /// </summary>
        public int FT { get; set; }


        /// <summary>
        /// 外教编号
        /// </summary>
        public string FTNumber { get; set; }

        /// <summary>
        /// 预约人数
        /// </summary>
        public int AppNum { get; set; }

        /// <summary>
        /// 级别编码
        /// </summary>
        public string LevelCode { get; set; }

        /// <summary>
        /// 级别名称
        /// </summary>
        public string LevelName { get; set; }
        /// <summary>
        /// 产品ID
        /// </summary>
        public int ProductID { get; set; }
        /// <summary>
        /// 产品Code
        /// </summary>
        public string ProductCode { get; set; }
    }
}
