﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbcCRM.Domain.EAS
{
    ///// <summary>
    ///// 班级学生
    ///// </summary>
    //public class ClassStudentModel
    //{
    //    /// <summary>
    //    /// 班级Id 
    //    /// </summary>
    //    public int bindingId { get; set; }

    //    /// <summary>
    //    /// 学生IDs
    //    /// </summary>
    //    public List<int> studentIdList { get; set; }
    //}

    /// <summary>
    /// 学员班级信息
    /// </summary>
    public class ClassStudentInfo
    {
        /// <summary>
        /// 关联班级
        /// </summary>
        public int? ClassID { get; set; }

        /// <summary>
        /// 关联合同
        /// </summary>
        public int ContID { get; set; }

        /// <summary>
        /// 关联学员
        /// </summary>
        public int LeadID { get; set; }
        
        /// <summary>
        /// 总课时
        /// </summary>
        public int? ClassHour { get; set; }

        /// <summary>
        /// 上课状态（0待上课，1上课中，2正常完结，3变更审核中，4已停课，5转班完结，6退费完结）
        /// </summary>
        public int Status { get; set; }
    }

}
