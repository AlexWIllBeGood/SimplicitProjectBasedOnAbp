﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbcCRM.Domain.EAS
{
    /// <summary>
    /// 修改学员信息
    /// </summary>
    public class EditStudentModel
    {
        /// <summary>
        /// 学生Id 
        /// </summary>
        public int bindingId { get; set; }

        /// <summary>
        /// 修改内容json（要修改什么就传什么）
        /// </summary>
        public string student { get; set; }
    }
}
