﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//namespace AbcCRM.Domain.EAS
//{
//    /// <summary>
//    /// 学员实体
//    /// </summary>
//    public class StudentModel
//    {
//        /// <summary>
//        /// 当前级别
//        /// </summary>
//        public int currentLevelId { get; set; }

//        /// <summary>
//        /// 主键ID
//        /// </summary>
//        public int id { get; set; }

//        /// <summary>
//        /// CRM 学生Id 
//        /// </summary>
//        public int bindingId { get; set; }

//        /// <summary>
//        /// 中文名
//        /// </summary>
//        public string cnName { get; set; }

//        /// <summary>
//        /// 英文名
//        /// </summary>
//        public string enName { get; set; }


//        /// <summary>
//        /// 用户名
//        /// </summary>
//        public string userName { get; set; }

//        /// <summary>
//        /// 密码
//        /// </summary>
//        public string password { get; set; }

//        /// <summary>
//        /// 手机号
//        /// </summary>
//        public string mobile { get; set; }

//        /// <summary>
//        /// 角色 (0 = None(无) , 2 = Student(学生) , 4 = Teacher(老师) , 8 = Parent(家长) )
//        /// </summary>
//        public int role { get; set; }

//        /// <summary>
//        /// 用户头像
//        /// </summary>
//        public string profilePhoto { get; set; }

//        /// <summary>
//        /// 用户状态 (0 = None(无) , 1 = Active(激活) , 2 = Suspended(暂停使用) , 3 = Deleted(已删除) )
//        /// </summary>
//        public int userStatus { get; set; }

//        /// <summary>
//        /// 邮箱
//        /// </summary>
//        public string email { get; set; }

//        /// <summary>
//        /// 创建时间
//        /// </summary>
//        public DateTime createTime { get; set; }

//        /// <summary>
//        /// 更新时间
//        /// </summary>
//        public DateTime updateTime { get; set; }

//        /// <summary>
//        /// 班级ID
//        /// </summary>
//        public List<int> classIDs { get; set; }

//        /// <summary>
//        /// 中心ID
//        /// </summary>
//        public int branID { get; set; }

//        /// <summary>
//        /// CC员工编号
//        /// </summary>
//        public string ccNumber { get; set; }

//        /// <summary>
//        /// CC用户ID
//        /// </summary>
//        public int ccUserID { get; set; }


//    }
//}
