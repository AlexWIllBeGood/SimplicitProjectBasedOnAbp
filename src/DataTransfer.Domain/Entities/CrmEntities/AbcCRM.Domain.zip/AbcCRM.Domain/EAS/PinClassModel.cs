﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace AbcCRM.Domain.EAS
{
    /// <summary>
    /// 销课请求实体
    /// </summary>
    public class PinClassModel
    {
        /// <summary>
        /// 排课ID主键
        /// </summary>
        public int ClscID { get; set; }

        /// <summary>
        /// 排课状态：0已上课（需要传学员状态列表），1待上课（不需传学员状态列表，会将所有已出席和未出席的学员设置为待上课）
        /// </summary>
        public int ClscStasus { get; set; }

        /// <summary>
        /// 学生状态
        /// </summary>
        public List<StudentStatusModel> Students { get; set; }
    }

    /// <summary>
    /// 学生状态
    /// </summary>
    public class StudentStatusModel
    {
        /// <summary>
        /// 学生ID
        /// </summary>
        public int StudentID { get; set; }

        /// <summary>
        /// 状态：0已出席，1未出席
        /// </summary>
        public int Status { get; set; }
    }

}