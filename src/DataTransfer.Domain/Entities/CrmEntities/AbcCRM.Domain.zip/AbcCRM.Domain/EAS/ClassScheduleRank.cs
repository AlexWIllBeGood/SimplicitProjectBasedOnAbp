﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//namespace AbcCRM.Domain.EAS
//{
//    public class ClassScheduleRank
//    {
//        /// <summary>
//        /// 主键
//        /// </summary>
//        public int Clsc_ID { get; set; }

//        /// <summary>
//        /// 序号
//        /// </summary>
//        public int Rank { get; set; }
//    }
//}
