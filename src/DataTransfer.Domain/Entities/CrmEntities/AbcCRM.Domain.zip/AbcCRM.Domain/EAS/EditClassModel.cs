﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//namespace AbcCRM.Domain.EAS
//{
//    public class EditClassModel
//    {
//        /// <summary>
//        /// 班级Id 
//        /// </summary>
//        public int bindingId { get; set; }

//        /// <summary>
//        /// 修改内容json（要修改什么就传什么）
//        /// </summary>
//        public string metenClass { get; set; }
//    }
//}
