﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbcCRM.Domain
{
    /// <summary>
    /// SAP组织架构
    /// </summary>
    [NPoco.TableName("HrDCPath")]
    [NPoco.PrimaryKey("Hdcp_ID", AutoIncrement = true)]
    public class HrDCPathDTO
    {
        /// <summary>
        /// Id
        /// </summary>
        public int Hdcp_ID { get; set; }

        /// <summary>
        /// 架构/部门ID
        /// </summary>
        public int Hdcp_DID { get; set; }

        /// <summary>
        /// 父Id
        /// </summary>
        public int? Hdcp_PID { get; set; }

        /// <summary>
        /// 架构全路径
        /// </summary>
        public string Hdcp_DCPath { get; set; }

        /// <summary>
        /// 架构BranchId
        /// </summary>
        public int Hdcp_DCBranchID { get; set; }

        /// <summary>
        /// CRM配置BranchID
        /// </summary>
        public int? Hdcp_CRMBranchID { get; set; }
        /// <summary>
        /// 状态
        /// </summary>
        public int? Hdcp_Status { get; set; }

        /// <summary>
        /// 部门同步状态(0:未同步，1:已同步)
        /// </summary>
        public int Hdcp_SyncState { get; set; }

        /// <summary>
        /// 创建时间
        /// </summary>
        public DateTime Hdcp_CreateDate { get; set; }

        /// <summary>
        /// 更新时间
        /// </summary>
        public DateTime? Hdcp_UpdateDate { get; set; }

        /// <summary>
        /// 删除状态
        /// </summary>
        public int Deleted { get; set; }
    }
}
