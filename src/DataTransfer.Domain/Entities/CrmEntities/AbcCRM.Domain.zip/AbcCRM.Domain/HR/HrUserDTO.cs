﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbcCRM.Domain
{
    /// <summary>
    /// SAP员工信息
    /// </summary>
    [NPoco.TableName("HrUser")]
    [NPoco.PrimaryKey("Hrtu_Id", AutoIncrement = true)]
    public class HrUserDTO
    {
        public int Hrtu_ID { get; set; }

        /// <summary>
        /// 员工账号
        /// </summary>
        public string Hrtu_UserName { get; set; }

        /// <summary>
        /// 英文名
        /// </summary>
        public string Hrtu_EnName { get; set; }

        /// <summary>
        /// 中文名
        /// </summary>
        public string Hrtu_CnName { get; set; }

        /// <summary>
        /// 工号
        /// </summary>
        public string Hrtu_EmployeeCode { get; set; }

        /// <summary>
        /// 入职时间
        /// </summary>
        public DateTime? Hrtu_JoinInDate { get; set; }

        /// <summary>
        /// 手机号
        /// </summary>
        public string Hrtu_Mobile { get; set; }

        /// <summary>
        /// 身份证号
        /// </summary>
        public string Hrtu_IdCard { get; set; }

        /// <summary>
        /// 地址
        /// </summary>
        public string Hrtu_Address { get; set; }

        /// <summary>
        /// 职位
        /// </summary>
        public string Hrtu_PositionName { get; set; }

        /// <summary>
        /// SapID
        /// </summary>
        public int? Hrtu_SapBranchId { get; set; }

        /// <summary>
        /// 组织架构
        /// </summary>
        public string Hrtu_Path { get; set; }

        /// <summary>
        /// 职务名称
        /// </summary>
        public string Hrtu_JobTitle { get; set; }

        /// <summary>
        /// 对应的CRM中心ID
        /// </summary>
        public int? Hrtu_CRMBranchID { get; set; }

        /// <summary>
        /// CRM中心名称
        /// </summary>
        [NPoco.Ignore]
        public string Hrtu_CRMBranch_Name { get; set; }

        /// <summary>
        /// 职位角色同步状态
        /// </summary>
        public string Hrtu_Status { get; set; }

        /// <summary>
        /// 创建时间
        /// </summary>
        public DateTime? Hrtu_CreateDate { get; set; }

        /// <summary>
        /// 更新时间
        /// </summary>
        public DateTime? Hrtu_UpdateDate { get; set; }
        /// <summary>
        /// 人员性别
        /// </summary>
        public int Hrtu_Gender { get; set; }
        /// <summary>
        /// 生日
        /// </summary>
        public DateTime? Hrtu_Birthday { get; set; }

        /// <summary>
        /// 在职状态
        /// </summary>
        public int? Hrtu_IsDisable { get; set; }

    }
}
