﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbcCRM.Domain
{
    /// <summary>
    /// SAP职位对应CRM角色配置
    /// </summary>
    [NPoco.TableName("HrJobTitleRoles")]
    [NPoco.PrimaryKey("Hjtr_Id", AutoIncrement = true)]
    public partial class HrJobTitleRole
    {
        /// <summary>
        /// 主键
        /// </summary>
        public int Hjtr_ID { get; set; }

        /// <summary>
        /// 岗位名称
        /// </summary>
        public string Hjtr_JobTitle { get; set; }

        /// <summary>
        /// 角色列表
        /// </summary>
        public string Hjtr_Roles { get; set; }

        [NPoco.Ignore]
        public List<string> RoleCodes => Hjtr_Roles?.Split('|').ToList() ?? new List<string>();

        /// <summary>
        /// 创建时间
        /// </summary>
        public System.DateTime Hjtr_CreateDate { get; set; }

        /// <summary>
        /// 更新时间
        /// </summary>
        public System.DateTime? Hjtr_UpdateDate { get; set; }

        /// <summary>
        /// 状态
        /// </summary>
        public int Hjtr_Status { get; set; }
    }
}
