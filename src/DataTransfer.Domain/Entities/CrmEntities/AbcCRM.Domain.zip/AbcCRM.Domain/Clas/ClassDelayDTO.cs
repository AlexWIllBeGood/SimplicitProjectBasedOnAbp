﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbcCRM.Domain
{
    /// <summary>
    /// 班级延期
    /// </summary>
    [NPoco.TableName("ClassDelay")]
    [NPoco.PrimaryKey("Clde_ID", AutoIncrement = true)]
    public class ClassDelayDTO
    {
        /// <summary>
        /// 自增主键
        /// </summary>
        public int Clde_ID { get; set; }

        /// <summary>
        /// 班级ID
        /// </summary>
        public int Clde_ClassID { get; set; }

        /// <summary>
        /// 开课时间
        /// </summary>
        public DateTime Clde_ClassDate { get; set; }

        /// <summary>
        /// 申请原因
        /// </summary>
        public string Clde_Reason { get; set; }

        /// <summary>
        /// 类型
        /// </summary>
        public int Clde_Type { get; set; }

        /// <summary>
        /// 状态 0待审核；1审核通过；2审核驳回
        /// </summary>
        public int Clde_Status { get; set; }

        /// <summary>
        /// 工作流ID
        /// </summary>
        public int Clde_WorkflowID { get; set; }

        /// <summary>
        /// 创建时间
        /// </summary>
        public DateTime Clde_CreatedDate { get; set; }

        /// <summary>
        /// 创建人
        /// </summary>
        public int Clde_CreatedBy { get; set; }

        /// <summary>
        /// 更新时间
        /// </summary>
        public DateTime? Clde_UpdatedDate { get; set; }

        /// <summary>
        /// 更新人
        /// </summary>
        public int? Clde_UpdatedBy { get; set; }

        /// <summary>
        /// 删除
        /// </summary>
        public int Clde_Deleted { get; set; }
    }
}
