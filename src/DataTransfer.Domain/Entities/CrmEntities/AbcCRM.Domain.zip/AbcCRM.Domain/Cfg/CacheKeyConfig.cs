﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbcCRM.Domain
{
    /// <summary>
    /// 缓存key值
    /// </summary>
    public class CacheKeyConfig
    {
        /// <summary>
        /// 字典缓存
        /// </summary>
        public const string Captions_CACHE_KEY = "Custom_Captions";

        /// <summary>
        /// 角色人员缓存
        /// </summary>
        public const string UserInRole = "UserInRole";

        //public const string SA_CACHE_KEY = "User_SA";

        //public const string CC_CACHE_KEY = "User_CC";

        //public const string TMK_CACHE_KEY = "User_TMK";

        //public const string Teach_CACHE_KEY = "User_Teach";

        //public const string AllTeach_CACHE_KEY = "AllTeach_CACHE_KEY";

        //public const string TeachFT_CACHE_KEY = "User_TeachFT";

        //public const string MarketCS_CACHE_KEY = "User_MarketCS";

        //public const string Finance_CACHE_KEY = "User_Finance";

        //public const string Management_CACHE_KEY = "User_Management";

        /// <summary>
        /// 部门缓存
        /// </summary>
        public const string Dept_CACHE_KEY = "Dept_CACHE";

        /// <summary>
        /// 渠道缓存
        /// </summary>
        public const string Channel_CACHE_KEY = "Channel_CACHE";

        /// <summary>
        /// 渠道来源
        /// </summary>
        public const string ChannelSource_CACHE_KEY = "ChannelSource_CACHE";

        /// <summary>
        /// 中心/区域
        /// </summary>
        public const string TerriBran_CACHE_KEY = "TerriBran_CACHE";

        /// <summary>
        /// TMK中心/区域
        /// </summary>
        public const string TerriBran_TMK_CACHE_KEY = "TerriBran_TMK_CACHE";

        /// <summary>
        /// 小组
        /// </summary>
        public const string Group_CACHE_KEY = "Group_CACHE";

        /// <summary>
        /// 收款方式
        /// </summary>
        public const string AccountWay_CACHE_KEY = "AccountWay_CACHE";

        /// <summary>
        /// 用户缓存
        /// </summary>
        public const string USER_CACHE_KEY = "User_cache";

        /// <summary>
        /// 产品
        /// </summary>
        public const string Products_CACHE_KEY = "Products_CACHE";

        /// <summary>
        /// 产品大类
        /// </summary>
        public const string ProductType_CACHE_KEY = "ProductType_CACHE";

        /// <summary>
        /// 产品小类
        /// </summary>
        public const string ProductSubType_CACHE_KEY = "ProductSubType_CACHE";

        /// <summary>
        /// 产吕级别
        /// </summary>
        public const string ProductLevel_CACHE_KEY = "ProductLevel_CACHE";

        /// <summary>
        /// 课程
        /// </summary>
        public const string Course_CACHE_KEY = "Course_CACHE";

        /// <summary>
        /// 菜单
        /// </summary>
        public const string Menu_CACHE_KEY = "Menu_CACHE";

        /// <summary>
        /// 电话纪录
        /// </summary>
        public const string CallLog_CACHE = "CallLog_CACHE";

        /// <summary>
        /// EASToken
        /// </summary>
        public const string EASToken_CACHE = "EASToken_CACHE";

        /// <summary>
        /// 系统配置
        /// </summary>
        public const string SyncConfig_CACHE_KEY = "SyncConfig_CACHE";
    }
}
