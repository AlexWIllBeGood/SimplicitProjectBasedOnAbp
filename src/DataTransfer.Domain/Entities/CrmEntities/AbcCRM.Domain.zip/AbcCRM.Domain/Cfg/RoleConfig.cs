﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbcCRM.Domain
{
    /// <summary>
    /// 角色表 
    /// </summary>
    public class RoleConfig
    {
        #region 管理层
        /// <summary>
        /// 区域管理层
        /// </summary>
        public const string DistrictDirector = "DistrictDirector";

        /// <summary>
        /// 区域副总裁
        /// </summary>
        public const string RegionalVP = "RegionalVP";

        /// <summary>
        /// 区域销售总裁
        /// </summary>
        public const string RegionalSP = "RegionalSP";

        /// <summary>
        /// 总部运营
        /// </summary>
        public const string OperationalStaff = "OperationalStaff";
        /// <summary>
        /// 薪酬经理
        /// </summary>
        public const string SalaryM = "SalaryM";
        #endregion 

        #region 客服

        /// <summary>
        /// 客服主管
        /// </summary>
        public const string CSM = "CMS";

        /// <summary>
        /// 客服专员
        /// </summary>
        public const string CS = "CS";

        #endregion

        #region 财务

        /// <summary>
        /// 出纳
        /// </summary>
        public const string Finance = "AADAAB";

        /// <summary>
        /// 财务经理                
        /// </summary>
        public const string FinanceM = "AADA";

        /// <summary>
        /// 财务主管           
        /// </summary>
        public const string FinancePM = "AADAA";

        /// <summary>
        /// 订单收银           
        /// </summary>
        public const string FinancecCashier = "FINANCECCASHIER";

        /// <summary>
        /// 收银审核           
        /// </summary>
        public const string FinanceReview = "FINANCEREVIEW";

        #endregion

        #region IT

        /// <summary>
        /// 系统管理员
        /// </summary>
        public const string ADMIN = "ADMIN";

        /// <summary>
        /// 决策委员会                
        /// </summary>
        public const string BOSS = "BOSS";

        /// <summary>
        /// 区域校长                
        /// </summary>
        public const string AAF = "AAF";

        /// <summary>
        /// 中心主任                
        /// </summary>
        public const string AAFA = "AAFA";

        /// <summary>
        /// 总部管理层               
        /// </summary>        
        public const string A = "A";

        #endregion

        #region 市场部

        /// <summary>
        /// 市场专员
        /// </summary>
        public const string MarketCS = "MARKETCS";

        /// <summary>
        /// 市场主管
        /// </summary>
        public const string MarketM = "MARKETM";

        #endregion

        #region 销售

        /// <summary>
        /// 销售主管-招生主任（招生校长）               
        /// </summary>
        public const string AACAA = "AACAA";

        /// <summary>
        /// 招生组长
        /// </summary>
        public const string CCM = "CCGL";

        /// <summary>
        /// 课程顾问-CC                
        /// </summary>
        public const string CC = "AACAAA";

        #endregion

        #region 教学

        /// <summary>
        /// 老师      
        /// </summary>
        public const string Teach = "AAEAT";

        /// <summary>
        /// 老师--中教      
        /// </summary>
        public const string LT = "AAEALT";

        /// <summary>
        /// 老师--外教      
        /// </summary>
        public const string FT = "AAEAFT";

        /// <summary>
        /// 常规教学服务主管--教学主任            
        /// </summary>
        public const string AAEAA = "AAEAA";

        /// <summary>
        /// 常规学习指导-老师--助教              
        /// </summary>
        public const string SA = "AAEAAA";

        /// <summary>
        /// 总部教务
        /// </summary>
        public const string AAEAB = "AAEAB";

        /// <summary>
        /// 教务专员
        /// </summary>
        public const string AAEABB = "AAEABB";

        /// <summary>
        /// 教学总监
        /// </summary>
        public const string TEACHDIRECTOR = "TEACHDIRECTOR";
        
        #endregion

        #region TMK

        /// <summary>
        /// 电话营销经理--TMK经理              
        /// </summary>
        public const string TMKPM = "AABA";

        /// <summary>
        /// 电话营销主管--TMK主管           
        /// </summary>
        public const string TMKM = "AABAA";

        /// <summary>
        /// 电话营销专员--TMK专员             
        /// </summary>
        public const string TMK = "AABAAA";

        #endregion

        #region 网络角色

        /// <summary>
        /// 网络经理        
        /// </summary>
        public const string COMMONWEBM = "COMMONWEBM";

        /// <summary>
        /// 网络专员      
        /// </summary>
        public const string COMMONWEB = "COMMONWEB";

        /// <summary>
        /// CPS专员        
        /// </summary>
        public const string METENCPS = "METENCPS"; 

        #endregion

        /// <summary>
        /// 立刻说SA        
        /// </summary>
        public const string LKSSA = "LKSSA";

        /// <summary>
        /// 立刻说项目经理        
        /// </summary>
        public const string LKSPM = "LKSPM";
    }
}
