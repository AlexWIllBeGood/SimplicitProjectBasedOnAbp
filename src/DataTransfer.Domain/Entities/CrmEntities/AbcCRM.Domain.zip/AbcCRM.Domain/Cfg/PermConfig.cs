﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbcCRM.Domain
{
    /// <summary>
    /// 权限配置
    /// </summary>
    public class PermConfig
    {
        #region Lead相关权限

        /// <summary>
        /// 操作Lead
        /// </summary>
        public const string LeadOpera = "LeadOpera";

        /// <summary>
        /// Lead覆盖
        /// </summary>
        public const string CoverLeads = "CoverLeads";

        /// <summary>
        /// Lead到访
        /// </summary>
        public const string VisitLead = "VisitLead";

        /// <summary>
        /// Lead编辑
        /// </summary>
        public const string LeadEdit = "LeadEdit";

        /// <summary>
        /// Lead推荐客户
        /// </summary>
        public const string LeadRecommend = "LeadRecommend";

        /// <summary>
        /// Lead添加监护人
        /// </summary>
        public const string LeadAddGuardian = "LeadAddGuardian";

        /// <summary>
        /// Lead添加试听课
        /// </summary>
        public const string LeadAddDemoClass = "LeadAddDemoClass";

        /// <summary>
        /// Lead跟进
        /// </summary>
        public const string LeadCommFollow = "LeadCommFollow";

        /// <summary>
        /// Lead咨询结果
        /// </summary>
        public const string LeadConsult = "LeadConsult";

        /// <summary>
        /// Lead生成订单
        /// </summary>
        public const string LeadCreateOrder = "LeadCreateOrder";

        /// <summary>
        /// Lead添加备注
        /// </summary>
        public const string LeadCreateRemark = "LeadCreateRemark";

        /// <summary>
        /// 申请渠道修改
        /// </summary>
        public const string ApplyChgChannel = "ApplyChgChannel";

        /// <summary>
        /// Lead编辑签署人信息
        /// </summary>
        public const string LeadCreateCA = "LeadCreateCA";


        #endregion

        #region 财务相关权限

        /// <summary>
        /// 业绩导出
        /// </summary>
        public const string ResultExport = "ResultExport";

        /// <summary>
        /// 本月修改业绩(订单启动时间)
        /// </summary>
        public const string UpdateResultMonth = "UpdateResultMonth";

        /// <summary>
        /// 当天修改业绩(订单启动时间)
        /// </summary>
        public const string UpdateResultDay = "UpdateResultDay";

        /// <summary>
        /// 无时间限制修改业绩
        /// </summary>
        public const string UpdateResult = "UpdateResult";

        /// <summary>
        /// 本月修改收退款(订单启动时间)
        /// </summary>
        public const string UpdateAcrdMonth = "UpdateAcrdMonth";

        /// <summary>
        /// 当天修改收退款(订单启动时间)
        /// </summary>
        public const string UpdateAcrdDay = "UpdateAcrdDay";

        /// <summary>
        /// 无时间限制修改收退款
        /// </summary>
        public const string UpdateAccount = "UpdateAccount";

        /// <summary>
        /// 合同导出
        /// </summary>
        public const string ContractExport = "ContractExport";

        /// <summary>
        /// 添加反馈
        /// </summary>
        public const string AddFeedback = "AddFeedback";

        /// <summary>
        /// 修改反馈
        /// </summary>
        public const string EditFeedback = "EditFeedback";
        /// <summary>
        /// 删除反馈
        /// </summary>
        public const string DelFeedback = "DelFeedback";
        /// <summary>
        /// 修改反馈（总部审批）
        /// </summary>
        public const string EditFeedbackHead = "EditFeedbackHead";

        /// <summary>
        /// 修改反馈（次月1日）
        /// </summary>
        public const string EditFeedbackMonth = "EditFeedbackMonth";

        /// <summary>
        /// 导出反馈
        /// </summary>
        public const string ExportFeedback = "ExportFeedback";

        #endregion

        #region 流程相关权限

        /// <summary>
        /// 流程监控
        /// </summary>
        public const string WFMonitor = "WFMonitor";

        /// <summary>
        /// 流程导出
        /// </summary>
        public const string WFExport = "WFExport";

        #endregion

        #region 班级相关权限

        /// <summary>
        /// 新建班级
        /// </summary>
        public const string AddClass = "AddClass";

        /// <summary>
        /// 修改班级
        /// </summary>
        public const string UpdateClass = "UpdateClass";

        /// <summary>
        /// 修改班级老师
        /// </summary>
        public const string UpdateClassTeach = "UpdateClassTeach";

        /// <summary>
        /// 修改班级教室
        /// </summary>
        public const string UpdateClassroom = "UpdateClassroom";

        /// <summary>
        /// 修改班级上课方式（排课规则）
        /// </summary>
        public const string UpdateClassWay = "UpdateClassWay";

        /// <summary>
        /// 班级导出
        /// </summary>
        public const string ClassExport = "ClassExport";

        /// <summary>
        /// 设置已上课
        /// </summary>
        public const string SetClassed = "SetClassed";

        /// <summary>
        /// 新建排课
        /// </summary>
        public const string AddClassed = "AddClassed";

        /// <summary>
        /// 修改排课
        /// </summary>
        public const string EditClassed = "EditClassed";

        /// <summary>
        /// 班级延期
        /// </summary>
        public const string ApplyClassDelay = "ApplyClassDelay";

        /// <summary>
        /// 顺延排课
        /// </summary>
        public const string DelayClassSchedule = "DelayClassSchedule";

        /// <summary>
        /// 生成排课
        /// </summary>
        public const string GenerateClassSchedule = "GenerateClassSchedule";

        /// <summary>
        /// 排课导出
        /// </summary>
        public const string ScheduleExport = "ScheduleExport";

        /// <summary>
        /// 学员班级导出
        /// </summary>
        public const string ClassStuExport = "ClassStuExport";

        /// <summary>
        /// 修改上课记录状态(班课)
        /// </summary>
        public const string EditClassRecord = "EditClassRecord";

        /// <summary>
        /// 修改未上课的上课记录状态(班课)
        /// </summary>
        public const string EditClassRecordWithNoClass = "EditClassRecordWithNoClass";

        /// <summary>
        /// 修改上课记录状态(VIP)
        /// </summary>
        public const string EditVipClassRecord = "EditVipClassRecord";

        /// <summary>
        /// 修改未上课的上课记录状态(VIP)
        /// </summary>
        public const string EditVipClassRecordWithNoClass = "EditVipClassRecordWithNoClass";

        /// <summary>
        /// 返销课(班课)
        /// </summary>
        public const string SetUpClassed = "SetUpClassed";

        /// <summary>
        /// 返销课(VIP)
        /// </summary>
        public const string SetUpVipClassed = "SetUpVipClassed";

        /// <summary>
        /// 调整上课时间（重新生成上课记录）
        /// </summary>
        public const string ChangeClassRecord = "ChangeClassRecord";
        #endregion

        #region 代金券

        /// <summary>
        /// 转赠代金券
        /// </summary>
        public const string TranferVoucher = "TranferVoucher";

        /// <summary>
        /// 导出代金券
        /// </summary>
        public const string ExportVoucher = "ExportVoucher";

        #endregion
    }
}
