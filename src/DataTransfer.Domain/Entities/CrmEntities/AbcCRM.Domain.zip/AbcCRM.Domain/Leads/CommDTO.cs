﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbcCRM.Domain
{
    /// <summary>
    /// 沟通纪录
    /// </summary>
    [NPoco.TableName("Communication")]
    [NPoco.PrimaryKey("Comm_ID", AutoIncrement = true)]
    public class CommDTO
    {
        /// <summary>
        /// 主键
        /// </summary>
        public int Comm_ID { get; set; }

        /// <summary>
        /// 备注
        /// </summary>
        public string Comm_Note { get; set; }

        /// <summary>
        /// 学员
        /// </summary>
        public int Comm_LeadID { get; set; }

        /// <summary>
        /// 下次跟进时间
        /// </summary>
        public DateTime? Comm_NextFollowDate { get; set; }

        /// <summary>
        /// 预约到访时间
        /// </summary>
        public DateTime? Comm_BookingDate { get; set; }

        /// <summary>
        /// 电话结果
        /// </summary>
        public int? Comm_CallResult { get; set; }

        /// <summary>
        /// 电话结果
        /// </summary>
        [NPoco.Ignore]
        public string Comm_CallResult_Name { get; set; }

        /// <summary>
        /// 角色名称
        /// </summary>
        [NPoco.Ignore]
        public string Roles { get; set; }

        /// <summary>
        /// 用户头像
        /// </summary>
        [NPoco.Ignore]
        public string UserAvatar { get; set; }

        /// <summary>
        /// 1跟进记录，2备注记录
        /// </summary>
        public int Comm_Type { get; set; }

        /// <summary>
        /// 1跟进记录，2备注记录
        /// </summary>
        [NPoco.Ignore]
        public string Comm_Type_Name { get; set; }

        /// <summary>
        /// 区域
        /// </summary>
        [NPoco.Ignore]
        public int Comm_BranID { get; set; }

        /// <summary>
        /// 咨询结果
        /// </summary>
        public int? Comm_ConsultResult { get; set; }

        /// <summary>
        /// 咨询结果
        /// </summary>
        [NPoco.Ignore]
        public string Comm_ConsultResult_Name { get;set;}





        public int Comm_CreatedBy { get; set; }

        [NPoco.Ignore]
        public string Comm_CreatedBy_Name { get; set; }

        public DateTime Comm_CreatedDate { get; set; }

        public int? Comm_UpdatedBy { get; set; }

        [NPoco.Ignore]
        public string Comm_UpdatedBy_Name { get; set; }

        public DateTime? Comm_UpdatedDate { get; set; }

        public int Comm_Deleted { get; set; }
    }
}
