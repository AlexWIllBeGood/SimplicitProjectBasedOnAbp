﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbcCRM.Domain
{
    /// <summary>
    /// leads的渠道信息
    /// </summary>
    [NPoco.TableName("LeadChanApply")]
    [NPoco.PrimaryKey("Lcae_ID", AutoIncrement = true)]
    public class LeadChanApplyDTO
    {
        /// <summary>
        /// 自增主键
        /// </summary>
        public int Lcae_ID { get; set; }

        /// <summary>
        /// LeadID
        /// </summary>
        public int Lcae_LeadID { get; set; }

        /// <summary>
        /// Lead渠道
        /// </summary>
        public int Lcae_Channel { get; set; }

        /// <summary>
        /// 二级渠道
        /// </summary>
        public int Lcae_ChannelTwo { get; set; }

        /// <summary>
        /// 推广点
        /// </summary>
        public int Lcae_MChannelID { get; set; }

        /// <summary>
        /// 来源
        /// </summary>
        public int Lcae_Source { get; set; }

        /// <summary>
        /// TMK
        /// </summary>
        public int Lcae_Tmk { get; set; }

        /// <summary>
        /// 市场专员
        /// </summary>
        public int Lcae_MarketCS { get; set; }

        /// <summary>
        /// 报备老师
        /// </summary>
        public int Lcae_ReportedTeacher { get; set; }

        /// <summary>
        /// 报备学员
        /// </summary>
        public int Lcae_RenewBy { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public int Lcae_Branch { get; set; }

        /// <summary>
        /// 申请原因
        /// </summary>
        public string Lcae_Reason { get; set; }

        /// <summary>
        /// 类型
        /// </summary>
        public int Lcae_Type { get; set; }

        /// <summary>
        /// 状态0待审核，1通过，2驳回，3覆盖失败（已签单）
        /// </summary>
        public int Lcae_Status { get; set; }

        /// <summary>
        /// 工作流ID
        /// </summary>
        public int Lcae_WorkflowID { get; set; }

        /// <summary>
        /// 创建时间
        /// </summary>
        public DateTime Lcae_CreatedDate { get; set; }

        /// <summary>
        /// 创建人
        /// </summary>
        public int Lcae_CreatedBy { get; set; }

        /// <summary>
        /// 更新时间
        /// </summary>
        public DateTime? Lcae_UpdatedDate { get; set; }

        /// <summary>
        /// 更新人
        /// </summary>
        public int? Lcae_UpdatedBy { get; set; }

        /// <summary>
        /// 删除
        /// </summary>
        public int Lcae_Deleted { get; set; }
    }
}
