﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbcCRM.Domain
{
    /// <summary>
    /// 到访记录表
    /// </summary>
    [NPoco.TableName("Lead_Visited_Log")]
    [NPoco.PrimaryKey("Levl_ID", AutoIncrement = true)]
    public class Lead_Visited_LogDTO
    {
        /// <summary>
        /// 主键
        /// </summary>
        public int Levl_ID { get; set; }

        /// <summary>
        /// 关联的Lead
        /// </summary>
        public int Levl_LeadID { get; set; }

        /// <summary>
        /// 到访中心
        /// </summary>
        public int Levl_BranID { get; set; }

        [NPoco.Ignore]
        public string Levl_Branch_Name { get; set; }

        /// <summary>
        /// 当前CC
        /// </summary>
        public int? Levl_CC { get; set; }

        [NPoco.Ignore]
        public string Levl_CC_Name { get; set; }

        /// <summary>
        /// 到访时间
        /// </summary>
        public DateTime? Levl_ShowUpdate { get; set; }

        /// <summary>
        /// TMK
        /// </summary>
        public int? Levl_Tmk { get; set; }

        /// <summary>
        /// 跟进端口
        /// </summary>
        public int? Levl_FollowPort { get; set; }

        /// <summary>
        /// 渠道ID
        /// </summary>
        public int? Levl_ChannelID { get; set; }

        public int Levl_CreatedBy { get; set; }

        [NPoco.Ignore]
        public string Levl_CreatedBy_Name { get; set; }

        public DateTime Levl_CreatedDate { get; set; }

        public int? Levl_UpdatedBy { get; set; }

        public DateTime? Levl_UpdatedDate { get; set; }

        public int Levl_Deleted { get; set; }
    }
}
