﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbcCRM.Domain
{
    /// <summary>
    /// VOpportunityLead视图
    /// </summary>
    [NPoco.TableName("VOpportunityLead")]
    [NPoco.PrimaryKey("Lead_LeadID", AutoIncrement = true)]
    public class VOppoLeadDTO : LeadDTO
    {
        #region 属性	 
        /// <summary>
        /// 机会ID
        /// </summary>
        public int Oppo_ID { get; set; }
        /// <summary>
        /// 机会中心
        /// </summary>
        public int Oppo_BranID
        {
            get;
            set;
        }

        /// <summary>
        /// 机会CC
        /// </summary>
        public int? Oppo_CC
        {
            get;
            set;
        }
        #endregion

        [NPoco.Ignore]
        public string Oppo_Branch_Name { get; set; }

        [NPoco.Ignore]
        public string Oppo_CC_Name { get; set; }

        /// <summary>
        /// 咨询结果
        /// </summary>
        public int? Oppo_ConsultResult { get; set; }

        /// <summary>
        /// 咨询结果
        /// </summary>
        [NPoco.Ignore]
        public string Oppo_ConsultResult_Name { get; set; }

        /// <summary>
        /// 是否无效（0有效，1无效）
        /// </summary>
        public int? Oppo_Invalid { get; set; }

        /// <summary>
        /// 下次跟进时间
        /// </summary>
        public DateTime? Oppo_NextFollow { get; set; }

        /// <summary>
        /// 推送次数（企培专用）
        /// </summary>
        public int Oppo_OverflowNum { get; set; }
    }
}
