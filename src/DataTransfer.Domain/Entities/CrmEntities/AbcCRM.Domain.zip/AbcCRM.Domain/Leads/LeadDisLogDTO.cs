﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbcCRM.Domain
{
    /// <summary>
    /// 分配记录表
    /// </summary>
    [NPoco.TableName("LeadDis_Log")]
    [NPoco.PrimaryKey("Disl_ID", AutoIncrement = true)]
    public class LeadDisLogDTO
    {
        #region 属性		
        /// <summary>
        /// 主键
        /// </summary>
        public int Disl_ID
        {
            get;
            set;
        }

        /// <summary>
        /// 记录类型
        /// </summary>
        public int? Disl_Type
        {
            get;
            set;
        }

        /// <summary>
        /// LeadID
        /// </summary>
        public int? Disl_LeadID
        {
            get;
            set;
        }

        /// <summary>
        /// CC用户ID
        /// </summary>
        public int? Disl_CC
        {
            get;
            set;
        }

        /// <summary>
        /// 
        /// </summary>
        public int? Disl_CreatedBy
        {
            get;
            set;
        }

        /// <summary>
        /// 
        /// </summary>
        public DateTime? Disl_CreatedDate
        {
            get;
            set;
        }

        /// <summary>
        /// 
        /// </summary>
        public int? Disl_Deleted
        {
            get;
            set;
        }

        /// <summary>
        /// 中心BranID
        /// </summary>
        public int? Disl_BranID
        {
            get;
            set;
        }

        /// <summary>
        /// 小组ID
        /// </summary>
        public int? Disl_GroupID
        {
            get;
            set;
        }

        #endregion

        [NPoco.Ignore]
        public string Disl_TypeName { get; set; }

        [NPoco.Ignore]
        public string Disl_CCName { get; set; }

        [NPoco.Ignore]
        public string Disl_CreatedByName { get; set; }

        [NPoco.Ignore]
        public string Disl_BranName { get; set; }

        [NPoco.Ignore]
        public string Disl_GroupName { get; set; }
    }

    /// <summary>
    /// 分配记录表
    /// </summary>
    [NPoco.TableName("LeadDisSa_Log")]
    [NPoco.PrimaryKey("Diss_ID", AutoIncrement = true)]
    public class LeadDisSaDTO
    {
        /// <summary>
        /// 主键
        /// </summary>
        public int Diss_ID { get; set; }

        /// <summary>
        /// LeadID
        /// </summary>
        public int? Diss_LeadID { get; set; }

        /// <summary>
        /// SA
        /// </summary>
        public int? Diss_Sa { get; set; }

        [NPoco.Ignore]
        public string Diss_SaName { get; set; }

        public int? Diss_CreatedBy { get; set; }


        [NPoco.Ignore]
        public string Diss_CreatedByName { get; set; }

        public DateTime? Diss_CreatedDate { get; set; }

        public int? Diss_Deleted { get; set; }
    }
}
