﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbcCRM.Domain
{
    [NPoco.TableName("c_CallAgent")]
    [NPoco.PrimaryKey("clat_Id", AutoIncrement = true)]
    public class CallAgentDTO
    {
        [NPoco.Column("clat_Id")]
        public int Id { get; set; }

        /// <summary>
        /// 是否启用
        /// </summary>
        [NPoco.Column("clat_IsEnable")]
        public bool IsEnable { get; set; }

        /// <summary>
        /// 坐席状态  0准备中 ，1：准备就绪，2：用户锁定，3：咨询通话中，4：座席线路忙
        /// </summary>
        [NPoco.Column("clat_AgentState")]
        public int AgentState { get; set; }
        /// <summary>
        /// 坐席名称
        /// </summary>
        [NPoco.Column("clat_Name")]
        public string Name { get; set; }
        /// <summary>
        /// 坐席管理UserID
        /// </summary>
        [NPoco.Column("clat_RefAgentId")]
        public int RefAgentId { get; set; }
        /// <summary>
        /// 坐席分组ID
        /// </summary>
        [NPoco.Column("clat_RefGroupId")]
        public int RefGroupId { get; set; }
        /// <summary>
        /// 坐席分组
        /// </summary>
        [NPoco.Column("clat_GroupName")]
        public string GroupName { get; set; }
        /// <summary>
        /// 坐席名
        /// </summary>
        [NPoco.Column("clat_AgentName")]
        public string AgentName { get; set; }
        /// <summary>
        /// 容联通讯账号
        /// </summary>
        [NPoco.Column("clat_VoipAccount")]
        public string VoipAccount { get; set; }
        /// <summary>
        /// 容联通讯账号密码
        /// </summary>
        [NPoco.Column("clat_VoipPwd")]
        public string VoipPwd { get; set; }
        /// <summary>
        /// 容联子账号ID
        /// </summary>
        [NPoco.Column("clat_SubAccountSid")]
        public string SubAccountSid { get; set; }
        /// <summary>
        /// 容联子账号密码
        /// </summary>
        [NPoco.Column("clat_SubAccountPwd")]
        public string SubAccountPwd { get; set; }
        /// <summary>
        /// 容联-外显号码
        /// </summary>
        [NPoco.Column("clat_Phone")]
        public string Phone { get; set; }
        [NPoco.Column("clat_CreatedBy")]
        public int? CreatedBy { get; set; }
        [NPoco.Ignore]
        public string CreatedByName { get; set; }

        [NPoco.Column("clat_CreatedDate")]
        public DateTime? CreatedDate { get; set; }

        [NPoco.Column("clat_UpdatedBy")]
        public int? UpdatedBy { get; set; }
        [NPoco.Column("clat_UpdatedDate")]
        public DateTime? UpdatedDate { get; set; }
        [NPoco.Ignore]
        public string UpdatedByName { get; set; }

        [NPoco.Column("clat_Deleted")]
        public int Deleted { get; set; }

        [NPoco.Ignore]
        public UserDTO user { get; set; }

        [NPoco.Ignore]
        public CallCenterLog CallLog { get; set; }
    }

    [NPoco.TableName("c_Call_Log")]
    [NPoco.PrimaryKey("calo_Id", AutoIncrement = true)]
    public class CallCenterLog
    {
        [NPoco.Column("calo_Id")]
        public int Id { get; set; }
        /// <summary>
        /// 通话唯一标识符
        /// </summary>
        [NPoco.Column("calo_CallSid")]
        public string CallSid { get; set; }
        [NPoco.Column("calo_AgentId")]
        public int AgentId { get; set; }
        /// <summary>
        /// 外显号码
        /// </summary>
        [NPoco.Column("calo_FromNum")]
        public string FromNum { get; set; }
        /// <summary>
        /// 呼出号码
        /// </summary>
        [NPoco.Column("calo_Number")]
        public string Number { get; set; }
        [NPoco.Column("calo_RefTicketId")]
        public int RefTicketId { get; set; }
        /// <summary>
        /// 通话类型（0为呼出，1为呼入）
        /// </summary>
        [NPoco.Column("calo_CallType")]
        public int CallType { get; set; }
        [NPoco.Column("calo_CreatedBy")]
        public int? CreatedBy { get; set; }
        [NPoco.Column("calo_CreatedDate")]
        public DateTime? CreatedDate { get; set; }
        [NPoco.Column("calo_UpdatedBy")]
        public int? UpdatedBy { get; set; }
        [NPoco.Column("calo_UpdatedDate")]
        public DateTime? UpdatedDate { get; set; }
        [NPoco.Column("calo_Deleted")]
        public int Deleted { get; set; }
        [NPoco.Column("calo_CallStatus")]
        public int CallStatus { get; set; }
        [NPoco.Column("calo_AnswerTime")]
        public DateTime? AnswerTime { get; set; }
        /// <summary>
        /// 录音地址
        /// </summary>
        [NPoco.Column("calo_RecordUrl")]
        public string RecordUrl { get; set; }



        /// <summary>
        /// 录音名称
        /// </summary>
        [NPoco.Column("calo_Mp3Name")]
        public string Mp3Name { get; set; }
        /// <summary>
        /// 外呼响应时间
        /// </summary>
        [NPoco.Column("calo_ReceiveTime")]
        public DateTime? ReceiveTime { get; set; }

        /// <summary>
        /// 主叫结束时间
        /// </summary>
        [NPoco.Column("calo_EndTime")]
        public DateTime? EndTime { get; set; }
        /// <summary>
        /// 主叫结束状态
        /// </summary>
        [NPoco.Column("calo_EndType")]
        public int EndType { get; set; }
        /// <summary>
        /// 呼入区域
        /// </summary>
        [NPoco.Column("calo_Area")]
        public string Area { get; set; }
        [NPoco.Column("calo_ErrorCode")]
        public string ErrorCode { get; set; }
        [NPoco.Ignore]
        public string AgentName { get; set; }
        [NPoco.Ignore]
        public string TalkTime { get; set; }

        /// <summary>
        /// 下载次数
        /// </summary>
        [NPoco.Column("calo_DownTimes")]
        public int DownTimes { get; set; }

        [NPoco.Column("calo_DownStatus")]
        public int DownStatus { get; set; }

    }

    /// <summary>
    /// 
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public class KFApiResult<T>
    {
        public T Data { get; set; }
        public bool IsSuccess { get; set; }
        public string ResultCode { get; set; }
        public string ResultMessage { get; set; }
    }

    public class KFApiResult : KFApiResult<object>
    {

    }
}
