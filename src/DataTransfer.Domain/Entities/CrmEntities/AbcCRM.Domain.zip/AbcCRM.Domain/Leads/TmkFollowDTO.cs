﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbcCRM.Domain
{
    /// <summary>
    /// tmk端口跟进关联Lead
    /// </summary>
    [NPoco.TableName("TmkFollow")]
    [NPoco.PrimaryKey("Tmkf_ID", AutoIncrement = true)]
    public class TmkFollowDTO
    {
        /// <summary>
        /// 自增主键
        /// </summary>
        public int Tmkf_ID { get; set; }

        /// <summary>
        /// 跟进Lead
        /// </summary>
        public int Tmkf_LeadID { get; set; }

        /// <summary>
        /// 预约中心
        /// </summary>
        public int Tmkf_BranID { get; set; }

        /// <summary>
        /// 当前TMK
        /// </summary>
        public int? Tmkf_Tmk { get; set; }

        /// <summary>
        /// 到访时间
        /// </summary>
        public DateTime? Tmkf_ShowUpDate { get; set; }

        /// <summary>
        /// 下次跟进时间
        /// </summary>
        public DateTime? Tmkf_NextFollowDate { get; set; }

        /// <summary>
        /// 跟进次数
        /// </summary>
        public int? Tmkf_FollowNum { get; set; }

        /// <summary>
        /// 电话结果
        /// </summary>
        public int? Tmkf_CallResult { get; set; }

        /// <summary>
        /// 首次拨打跟进时间
        /// </summary>
        public DateTime? Tmkf_FirstCallDate { get; set; }

        /// <summary>
        /// 最后拨打时间
        /// </summary>
        public DateTime? Tmkf_LastCallDate { get; set; }

        /// <summary>
        /// 预约到访时间
        /// </summary>
        public DateTime? Tmkf_BookingDate { get; set; }

        /// <summary>
        /// tmk状态，同Lead_Status_TMK，1TMK待分配，2TMK待跟进，3TMK跟进中，4TMK已预约，5TMK判无效,6到访,-1回收
        /// </summary>
        public int? Tmkf_Status { get; set; }

        /// <summary>
        /// 最后分配时间
        /// </summary>
        public DateTime? Tmkf_DistDate { get; set; }

        /// <summary>
        /// 客户备注
        /// </summary>
        public string Tmkf_Remark { get; set; }

        public int Tmkf_CreatedBy { get; set; }

        public DateTime Tmkf_CreatedDate { get; set; }

        public int? Tmkf_UpdatedBy { get; set; }

        public DateTime? Tmkf_UpdatedDate { get; set; }

        public int Tmkf_Deleted { get; set; }
        /// <summary>
        /// 是否回收
        /// </summary>
        public int Tmkf_Recover { get; set; }
    }


    /// <summary>
    /// tmk端口跟进关联Lead
    /// </summary>
    [NPoco.TableName("VTmkFollowLead")]
    public class VTmkFollowLead : LeadDTO
    {
        /// <summary>
        /// 预约中心
        /// </summary>
        public int Tmkf_BranID { get; set; }

        [NPoco.Ignore]
        public string Tmkf_Bran_Name { get; set; }

        /// <summary>
        /// 当前TMK
        /// </summary>
        public int? Tmkf_Tmk { get; set; }

        [NPoco.Ignore]
        public string Tmkf_Tmk_Name { get; set; }

        /// <summary>
        /// 到访时间
        /// </summary>
        public DateTime? Tmkf_ShowUpDate { get; set; }

        /// <summary>
        /// 下次跟进时间
        /// </summary>
        public DateTime? Tmkf_NextFollowDate { get; set; }

        /// <summary>
        /// 跟进次数
        /// </summary>
        public int? Tmkf_FollowNum { get; set; }

        /// <summary>
        /// 电话结果
        /// </summary>
        public int? Tmkf_CallResult { get; set; }

        [NPoco.Ignore]
        public string Tmkf_CallResult_Name { get; set; }

        /// <summary>
        /// 首次拨打跟进时间
        /// </summary>
        public DateTime? Tmkf_FirstCallDate { get; set; }

        /// <summary>
        /// 最后拨打时间
        /// </summary>
        public DateTime? Tmkf_LastCallDate { get; set; }

        /// <summary>
        /// 预约到访时间
        /// </summary>
        public DateTime? Tmkf_BookingDate { get; set; }

        /// <summary>
        /// tmk状态，同Lead_Status_TMK，1TMK待分配，2TMK待跟进，3TMK跟进中，4TMK已预约，5TMK判无效
        /// </summary>
        public int? Tmkf_Status { get; set; }

        [NPoco.Ignore]
        public string Tmkf_Status_Name { get; set; }

        /// <summary>
        /// 最后分配时间
        /// </summary>
        public DateTime? Tmkf_DistDate { get; set; }

        /// <summary>
        /// 客户备注
        /// </summary>
        public string Tmkf_Remark { get; set; }
        /// <summary>
        /// 是否回收
        /// </summary>
        public int Tmkf_Recover { get; set; }

    }
}
