﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbcCRM.Domain
{
    /// <summary>
    /// 监护人表
    /// </summary>
    [NPoco.TableName("FamilyLead")]
    [NPoco.PrimaryKey("Fami_ID", AutoIncrement = true)]
    public class FamilyLeadDTO
    {
        /// <summary>
        /// 主键
        /// </summary>
        public int Fami_ID { get; set; }

        /// <summary>
        /// 姓名
        /// </summary>
        public string Fami_Name { get; set; }

        /// <summary>
        /// 手机号码
        /// </summary>
        public string Fami_Moblie { get; set; }

        /// <summary>
        /// 证件类型 0、身份证 1、护照 B、港澳居民往来内地通行证 C、台湾居民来往大陆通行证 F、临时居民身份证
        /// </summary>
        public string Fami_IdType { get; set; }

        /// <summary>
        /// 证件类型
        /// </summary>
        [NPoco.Ignore]
        public string Fami_IdType_Name { get; set; }

        /// <summary>
        /// 证件号码
        /// </summary>
        public string Fami_IdCard { get; set; }

        /// <summary>
        /// 工作单位
        /// </summary>
        public string Fami_Company { get; set; }

        /// <summary>
        /// 备注
        /// </summary>
        public string Fami_Remarks { get; set; }

        /// <summary>
        /// 是否使用CA签署过
        /// </summary>
        [NPoco.Ignore]
        public bool Fami_IsUserCA { get; set; }

        public int? Fami_CreatedBy { get; set; }

        [NPoco.Ignore]
        public string Fami_CreatedBy_Name { get; set; }

        public DateTime? Fami_CreatedDate { get; set; }

        public int? Fami_UpdatedBy { get; set; }

        [NPoco.Ignore]
        public string Fami_UpdatedBy_Name { get; set; }

        public DateTime? Fami_UpdatedDate { get; set; }

        public int? Fami_Deleted { get; set; }

    }

    /// <summary>
    /// Lead、监护人关系表
    /// </summary>
    [NPoco.TableName("FamilyLeadRelation")]
    [NPoco.PrimaryKey("Famr_ID", AutoIncrement = true)]
    public class FamilyLeadRelation
    {
        /// <summary>
        /// 主键
        /// </summary>
        public int Famr_ID { get; set; }

        /// <summary>
        /// LeadID
        /// </summary>
        public int Famr_LeadID { get; set; }

        /// <summary>
        /// 监护人ID
        /// </summary>
        public int Famr_FamilyLeadID { get; set; }

        /// <summary>
        /// 身份 1、爸爸 2、妈妈 3、爷爷 4、奶奶 5、外公 6、外婆 7、其他
        /// </summary>
        public int? Famr_Identity { get; set; }

        /// <summary>
        /// 身份
        /// </summary>
        [NPoco.Ignore]
        public string Famr_Identity_Name { get; set; }

        /// <summary>
        /// Lead信息
        /// </summary>
        [NPoco.Ignore]
        public LeadDTO Lead { get; set; }

        /// <summary>
        /// 监护人信息
        /// </summary>
        [NPoco.Ignore]
        public FamilyLeadDTO FamilyLead { get; set; }

        /// <summary>
        /// CA申请状态
        /// </summary>
        [NPoco.Ignore]
        public string CAStatus { get; set; }

        public int? Famr_CreatedBy { get; set; }

        [NPoco.Ignore]
        public string Famr_CreatedBy_Name { get; set; }

        public DateTime? Famr_CreatedDate { get; set; }

        public int? Famr_UpdatedBy { get; set; }

        [NPoco.Ignore]
        public string Famr_UpdatedBy_Name { get; set; }

        public DateTime? Famr_UpdatedDate { get; set; }

        public int? Famr_Deleted { get; set; }

    }
}
