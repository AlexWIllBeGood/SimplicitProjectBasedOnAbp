﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbcCRM.Domain
{
    /// <summary>
    /// 渠道表
    /// </summary>
    [NPoco.TableName("Channel")]
    [NPoco.PrimaryKey("Chan_ID", AutoIncrement = true)]
    public class ChannelDTO
    {
        public int Chan_ID { get; set; }

        /// <summary>
        /// 渠道名称
        /// </summary>
        public string Chan_Name { get; set; }

        /// <summary>
        /// 上级渠道
        /// </summary>
        public int Chan_ParentID { get; set; }

        [NPoco.Ignore]
        public string Chan_ParentName { get; set; }

        /// <summary>
        /// 启用/禁用
        /// </summary>
        public int Chan_Status { get; set; }

        [NPoco.Ignore]
        public string Chan_Status_Name { get; set; }

        /// <summary>
        /// 深度
        /// </summary>
        public int Chan_Depth { get; set; }

        public string Chan_Info { get; set; }

        [NPoco.Ignore]
        public string Chan_Sources { get; set; }

        [NPoco.Ignore]
        public string Chan_SourceIds { get; set; }

        public int? Chan_CreatedBy { get; set; }

        public DateTime? Chan_CreatedDate { get; set; }

        public int? Chan_UpdatedBy { get; set; }

        [NPoco.Ignore]
        public string Chan_CreatedBy_Name { get; set; }

        [NPoco.Ignore]
        public string Chan_UpdatedBy_Name { get; set; }

        public DateTime? Chan_UpdatedDate { get; set; }

        public int Chan_Deleted { get; set; }

        [NPoco.Ignore]
        public string Chan_Title { get; set; }

        [NPoco.Ignore]
        public string Chan_ParentType { get; set; }

        [NPoco.Ignore]
        public string OneChan_Name { get; set; }

        [NPoco.Ignore]
        public string TwoChan_Name { get; set; }

        public string Chan_Role_Code { get; set; }

        [NPoco.Ignore]
        public List<string> RoleCodes => Chan_Role_Code?.Split(',').ToList() ?? new List<string>();

        public string Chan_Branch { get; set; }

        [NPoco.Ignore]
        public List<string> Chan_Branchs => Chan_Branch?.Split(',').ToList() ?? new List<string>();
    }

    [NPoco.TableName("ChannelSource")]
    [NPoco.PrimaryKey("chso_Id", AutoIncrement = true)]
    public class ChannelSourceDTO
    {
        public int Chso_ID { get; set; }

        public int Chso_Channel { get; set; }

        public int Chso_ChannelTwo { get; set; }

        public int Chso_Source { get; set; }

        [NPoco.Ignore]
        public string Chso_Sources { get; set; }

        [NPoco.Ignore]
        public string Chso_Source_Name { get; set; }

        public int Chso_Deleted { get; set; }

        public int? Chso_CreatedBy { get; set; }

        [NPoco.Ignore]
        public string Chso_CreatedBy_Name { get; set; }

        public DateTime? Chso_CreatedDate { get; set; }

        public int? Chso_UpdatedBy { get; set; }

        [NPoco.Ignore]
        public string Chso_UpdatedBy_Name { get; set; }

        public DateTime? Chso_UpdatedDate { get; set; }
    }

    public class MChannelReq
    {
        [Required(ErrorMessage = "推广点名称不能为空")]
        public string Name { get; set; }

        [Required(ErrorMessage = "二级渠道ID不能为空")]
        public int ChannelTwo { get; set; }

        [Required(ErrorMessage = "操作人不能为空")]
        public string Operator { get; set; }
    }
}
