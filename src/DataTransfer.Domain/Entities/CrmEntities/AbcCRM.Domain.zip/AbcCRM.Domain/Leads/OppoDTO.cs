﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbcCRM.Domain
{
    /// <summary>
    /// 机会表
    /// </summary>
    [NPoco.TableName("Opportunity")]
    [NPoco.PrimaryKey("Oppo_ID", AutoIncrement = true)]
    public class OppoDTO
    {
        /// <summary>
        /// 主键
        /// </summary>
        public int Oppo_ID { get; set; }

        /// <summary>
        /// LeadID
        /// </summary>
        public int Oppo_LeadID { get; set; }

        /// <summary>
        /// 到访时间
        /// </summary>
        public DateTime? Oppo_ShowUpDate { get; set; }

        /// <summary>
        /// 下次跟进时间
        /// </summary>
        public DateTime? Oppo_NextFollow { get; set; }

        /// <summary>
        /// 课程顾问
        /// </summary>
        public int Oppo_CC { get; set; }

        /// <summary>
        /// 跟进中心
        /// </summary>
        public int Oppo_BranID { get; set; }

        /// <summary>
        /// 创建时间
        /// </summary>
        public int Oppo_CreatedBy { get; set; }

        /// <summary>
        /// 创建时间
        /// </summary>
        public DateTime Oppo_CreatedDate { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public int? Oppo_UpdatedBy { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public DateTime? Oppo_UpdatedDate { get; set; }

        /// <summary>
        /// 删除标志位s
        /// </summary>
        public int Oppo_Deleted { get; set; }

        /// <summary>
        /// CC
        /// </summary>
        [NPoco.Ignore]
        public string Oppo_CC_Name { get; set; }

        /// <summary>
        /// 中心
        /// </summary>
        [NPoco.Ignore]
        public string Oppo_BranID_Name { get; set; }

        /// <summary>
        /// 创建人
        /// </summary>
        [NPoco.Ignore]
        public string Oppo_CreatedBy_Name { get; set; }

        /// <summary>
        /// 机会状态,同Lead_Status，1CC待分配，2CC跟进中，3已签单
        /// </summary>
        public int? Oppo_Status { get; set; }

        /// <summary>
        /// 是否回收 0未回收，1回收
        /// </summary>
        public int Oppo_Recover { get; set; }

        /// <summary>
        /// 咨询结果
        /// </summary>
        public int? Oppo_ConsultResult { get; set; }

        /// <summary>
        /// 咨询结果
        /// </summary>
        [NPoco.Ignore]
        public string Oppo_ConsultResult_Name { get; set; }

        /// <summary>
        /// 是否无效（0有效，1无效）
        /// </summary>
        public int? Oppo_Invalid { get; set; }

        /// <summary>
        /// 推送次数（企培专用）
        /// </summary>
        public int Oppo_OverflowNum { get; set; }
    }
}
