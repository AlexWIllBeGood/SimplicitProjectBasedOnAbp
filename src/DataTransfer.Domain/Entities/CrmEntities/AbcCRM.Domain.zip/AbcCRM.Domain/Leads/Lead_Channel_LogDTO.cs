﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbcCRM.Domain
{
    /// <summary>
    /// 渠道记录表
    /// </summary>
    [NPoco.TableName("Lead_Channel_Log")]
    [NPoco.PrimaryKey("Lchg_ID", AutoIncrement = true)]
    public class Lead_Channel_LogDTO
    {
        /// <summary>
        /// 主键
        /// </summary>
        public int Lchg_ID { get; set; }

        /// <summary>
        /// 关联的Lead
        /// </summary>
        public int? Lchg_LeadID { get; set; }

        /// <summary>
        /// 一级渠道
        /// </summary>
        public int? Lchg_Channel { get; set; }
        [NPoco.Ignore]
        public string Lchg_Channel_Name { get; set; }

        /// <summary>
        /// 二级渠道
        /// </summary>
        public int? Lchg_ChannelTwo { get; set; }
        [NPoco.Ignore]
        public string Lchg_ChannelTwo_Name { get; set; }
        /// <summary>
        /// 推广点
        /// </summary>
        public int? Lchg_MChannelID { get; set; }
        [NPoco.Ignore]
        public string Lchg_MChannel_Name { get; set; }
        /// <summary>
        /// TMK UserID
        /// </summary>
        public int? Lchg_TmkID { get; set; }
        [NPoco.Ignore]
        public string Lchg_Tmk_Name { get; set; }
        /// <summary>
        /// 市场专员 UserID
        /// </summary>
        public int? Lchg_PromoterID { get; set; }
        [NPoco.Ignore]
        public string Lchg_Promoter_Name { get; set; }
        /// <summary>
        /// 报备人 UserID
        /// </summary>
        public int? Lchg_ReferralID { get; set; }
        [NPoco.Ignore]
        public string Lchg_Referral_Name { get; set; }
        /// <summary>
        /// 老学员
        /// </summary>
        public int? Lchg_RenewBy { get; set; }
        [NPoco.Ignore]
        public string Lchg_RenewBy_Name { get; set; }
        /// <summary>
        /// 报备老师
        /// </summary>
        public int? Lchg_ReportedTeacher { get; set; }
        [NPoco.Ignore]
        public string Lchg_ReportedTeacher_Name { get; set; }
        /// <summary>
        /// 创建人
        /// </summary>
        public int Lchg_CreatedBy { get; set; }
        /// <summary>
        /// 创建人
        /// </summary>
        [NPoco.Ignore]
        public string Lchg_CreatedBy_Name { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public DateTime Lchg_CreatedDate { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public int? Lchg_UpdatedBy { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public DateTime? Lchg_UpdatedDate { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public int Lchg_Deleted { get; set; }
        /// <summary>
        /// 渠道中心
        /// </summary>
        public int Lchg_BranchID { get; set; }
        [NPoco.Ignore]
        public string Lchg_Branch_Name { get; set; }
        /// <summary>
        /// 渠道来源
        /// </summary>
        public int? Lchg_Source { get; set; }
        [NPoco.Ignore]
        public string Lchg_Source_Name { get; set; }
    }
}
