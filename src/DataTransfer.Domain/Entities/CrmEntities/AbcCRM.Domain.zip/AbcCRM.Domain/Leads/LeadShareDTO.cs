﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbcCRM.Domain
{
    /// <summary>
    /// 修改纪录
    /// </summary>
    [NPoco.TableName("LeadShare")]
    [NPoco.PrimaryKey("Lese_ID", AutoIncrement = true)]
    public class LeadShareDTO
    {
        /// <summary>
        /// 主键
        /// </summary>
        public int Lese_ID { get; set; }

        /// <summary>
        /// LeadID
        /// </summary>
        public int Lese_LeadID { get; set; }

        /// <summary>
        /// 工作流ID
        /// </summary>
        public int Lese_WorkflowID { get; set; }

        /// <summary>
        /// 原数据
        /// </summary>
        public int Lese_OldBranch { get; set; }

        /// <summary>
        /// 新数据
        /// </summary>
        public int Lese_NewBranch { get; set; }

        /// <summary>
        /// 类型
        /// </summary>
        public int Lese_Type { get; set; }

        /// <summary>
        /// 状态
        /// </summary>
        public int Lese_Status { get; set; }

        /// <summary>
        /// 原因
        /// </summary>
        public string Lese_Desc { get; set; }

        /// <summary>
        /// 创建人
        /// </summary>
        public int Lese_CreatedBy { get; set; }

        /// <summary>
        /// 创建人
        /// </summary>
        public DateTime Lese_CreatedDate { get; set; }

        /// <summary>
        /// 修改人
        /// </summary>
        public int? Lese_UpdatedBy { get; set; }

        /// <summary>
        /// 修改时间
        /// </summary>
        public DateTime? Lese_UpdatedDate { get; set; }

        /// <summary>
        /// 删除标志
        /// </summary>
        public int Lese_Deleted { get; set; }
    }
}
