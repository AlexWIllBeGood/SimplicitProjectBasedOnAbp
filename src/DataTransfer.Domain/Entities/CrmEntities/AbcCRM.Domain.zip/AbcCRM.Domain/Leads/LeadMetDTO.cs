﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbcCRM.Domain
{
    /// <summary>
    /// lead推送美联成功后的关联表
    /// </summary>
    [NPoco.TableName("LeadMetLog")]
    [NPoco.PrimaryKey("Leam_ID", AutoIncrement = true)]
    public class LeadMetDTO
    {
        public int Leam_ID { get; set; }
        public int Leam_LeadID { get; set; }
        public int Leam_MetLeadID { get; set; }
        public int Leam_MetPersonID { get; set; }
        public DateTime Leam_CreatedDate { get; set; }
    }
}
