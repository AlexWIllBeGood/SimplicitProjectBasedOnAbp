﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbcCRM.Domain
{
    /// <summary>
    /// 修改纪录
    /// </summary>
    [NPoco.TableName("LeadEditLog")]
    [NPoco.PrimaryKey("lelog_Id", AutoIncrement = true)]
    public class LeadEditLogDTO
    {
        public int Lelog_ID { get; set; }

        /// <summary>
        /// LeadID
        /// </summary>
        public int Lelog_LeadID { get; set; }

        /// <summary>
        /// 原数据
        /// </summary>
        public string Lelog_OldLead { get; set; }

        /// <summary>
        /// 新数据
        /// </summary>
        public string Lelog_NewLead { get; set; }

        /// <summary>
        /// 创建人
        /// </summary>
        public int Lelog_CreatedBy { get; set; }

        [NPoco.Ignore]
        public string Lelog_CreatedByName { get; set; }

        /// <summary>
        /// 创建人
        /// </summary>
        public DateTime Lelog_CreatedDate { get; set; }

        /// <summary>
        /// 修改人
        /// </summary>
        public int Lelog_UpdatedBy { get; set; }

        /// <summary>
        /// 修改时间
        /// </summary>
        public DateTime Lelog_UpdatedDate { get; set; }

        /// <summary>
        /// 删除标志
        /// </summary>
        public int Lelog_Deleted { get; set; }
    }
}
