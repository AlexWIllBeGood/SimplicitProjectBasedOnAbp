﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbcCRM.Domain
{
    /// <summary>
    /// CC跟进记录
    /// </summary>
    [NPoco.TableName("Oppo_Follow_Log")]
    [NPoco.PrimaryKey("Opfl_ID", AutoIncrement = true)]
    public class Oppo_Follow_LogDTO
    {
        /// <summary>
        /// 主键
        /// </summary>
        public int Opfl_ID { get; set; }

        /// <summary>
        /// 关联的Lead
        /// </summary>
        public int? Opfl_LeadID { get; set; }

        /// <summary>
        /// 跟进中心
        /// </summary>
        public int? Opfl_BranID { get; set; }

        /// <summary>
        /// 下次跟进时间
        /// </summary>
        public DateTime? Opfl_NextFollow { get; set; }

        /// <summary>
        /// 咨询结果
        /// </summary>
        public int? Opfl_ConsultResult { get; set; }

        /// <summary>
        /// 咨询结果
        /// </summary>
        [NPoco.Ignore]
        public string Opfl_ConsultResult_Name { get; set; }

        /// <summary>
        /// 是否无效（0有效，1无效）
        /// </summary>
        public int? Opfl_Invalid { get; set; }

        /// <summary>
        /// 沟通内容
        /// </summary>
        public string Opfl_Info { get; set; }

        /// <summary>
        /// 当前CC
        /// </summary>
        public int? Opfl_Sales { get; set; }

        /// <summary>
        /// 用户头像
        /// </summary>
        [NPoco.Ignore]
        public string UserAvatar { get; set; }
        
        /// <summary>
        /// 角色
        /// </summary>
        [NPoco.Ignore]
        public string Roles { get; set; }



        public int Opfl_CreatedBy { get; set; }

        [NPoco.Ignore]
        public string Opfl_CreatedBy_Name { get; set; }

        public DateTime Opfl_CreatedDate { get; set; }

        public int? Opfl_UpdatedBy { get; set; }

        [NPoco.Ignore]
        public string Opfl_UpdatedBy_Name { get; set; }

        public DateTime? Opfl_UpdatedDate { get; set; }

        public int Opfl_Deleted { get; set; }

    }
}
