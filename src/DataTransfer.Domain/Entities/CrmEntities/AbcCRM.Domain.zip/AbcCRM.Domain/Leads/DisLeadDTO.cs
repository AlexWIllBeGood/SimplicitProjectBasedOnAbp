﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbcCRM.Domain
{
    /// <summary>
    /// Leads管理
    /// </summary>
    public class DisLeadDTO
    {
        /// <summary>
        /// LeadID
        /// </summary>
        public List<int> Leads { get; set; }

        /// <summary>
        /// Lead_Sales
        /// </summary>
        public int DisCC { get; set; }

        /// <summary>
        /// BranID
        /// </summary>
        public int DisBranID { get; set; }

        /// <summary>
        /// GroupID 
        /// </summary>
        public int DisGroupID { get; set; }
    }

    /// <summary>
    /// 分配SA
    /// </summary>
    public class DisSaDTO
    {
        /// <summary>
        /// LeadID
        /// </summary>
        public List<int> Leads { get; set; }

        /// <summary>
        /// SA
        /// </summary>
        public int DisSa { get; set; }
    }
}
