﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbcCRM.Domain
{
    /// <summary>
    /// 分配记录表
    /// </summary>
    [NPoco.TableName("RecommendLog")]
    [NPoco.PrimaryKey("Recl_ID", AutoIncrement = true)]
    public class RecommendLog
    {
        /// <summary>
        /// 主键
        /// </summary>
        public int Recl_ID { get; set; }

        /// <summary>
        /// LeadID
        /// </summary>
        public int? Recl_LeadID { get; set; }

        /// <summary>
        /// 原中心
        /// </summary>
        public int Recl_BranID { get; set; }

        [NPoco.Ignore]
        public string Recl_BranName { get; set; }

        /// <summary>
        /// 推荐中心
        /// </summary>
        public int Recl_DisBranID { get; set; }

        [NPoco.Ignore]
        public string Recl_DisBranName { get; set; }

        /// <summary>
        /// 当前CC
        /// </summary>
        public int? Recl_CC { get; set; }

        [NPoco.Ignore]
        public string Recl_CCName { get; set; }

        /// <summary>
        /// 备注
        /// </summary>
        public string Recl_Remark { get; set; }

        public int? Recl_CreatedBy { get; set; }

        [NPoco.Ignore]
        public string Recl_CreatedByName { get; set; }

        public DateTime? Recl_CreatedDate { get; set; }

        public int Recl_Deleted { get; set; }
    }
}
