﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//namespace AbcCRM.Domain.Leads
//{
//    [NPoco.TableName("LeadVisit_Log")]
//    [NPoco.PrimaryKey("levl_Id", AutoIncrement = true)]
//    public class LeadVisitLogDTO
//    {
//        public int levl_Id { get; set; }

//        public DateTime? levl_ShowUpDate { get; set; }

//        public int levl_LeadId { get; set; }

//        public int? levl_Channel { get; set; }

//        [NPoco.Ignore]
//        public string levl_Channel_Name { get; set; }

//        public int? levl_ChannelTwo { get; set; }

//        [NPoco.Ignore]
//        public string levl_ChannelTwo_Name { get; set; }

//        public int? levl_MarketCS { get; set; }

//        [NPoco.Ignore]
//        public string levl_MarketCS_Name { get; set; }

//        public int levl_Sales { get; set; }

//        [NPoco.Ignore]
//        public string levl_Sales_Name { get; set; }

//        public int? levl_CreatedBy { get; set; }

//        [NPoco.Ignore]
//        public string levl_CreatedBy_Name { get; set; }

//        public DateTime? levl_CreatedDate { get; set; }

//        public int? levl_UpdatedBy { get; set; }

//        [NPoco.Ignore]
//        public string levl_UpdatedBy_Name { get; set; }

//        public DateTime? levl_UpdatedDate { get; set; }

//        public int levl_Deleted { get; set; }
//    }
//}
